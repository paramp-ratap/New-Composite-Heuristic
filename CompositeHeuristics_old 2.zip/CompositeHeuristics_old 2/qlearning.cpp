#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include "graph.h"
#include "qlearning.h"

extern struct graph_info Gr;
extern struct edge_info *edges;
extern struct virtual_address address;

/* Manhattan distance between two tiles */
static unsigned short hop_dist(unsigned short t1, unsigned short t2)
{
    return (unsigned short)(abs(address.colum[t1] - address.colum[t2])
                          + abs(address.row[t1] - address.row[t2]));
}

/* ------------------------------------------------------------------ */
/*  Lifecycle                                                          */
/* ------------------------------------------------------------------ */

void ql_init(QLearningAgent *agent, double learning_rate, double epsilon)
{
    memset(agent, 0, sizeof(*agent));
    agent->learning_rate = learning_rate;
    agent->epsilon       = epsilon;
    agent->discount      = 1.0;   /* undiscounted episodic */
    agent->episode_len   = 0;
    agent->episodes_trained = 0;

    /* Small random initial weights for symmetry breaking */
    for (int i = 0; i < QL_NUM_FEATURES; i++)
        agent->weights[i] = ((double)rand() / RAND_MAX - 0.5) * 0.01;
}

/* ------------------------------------------------------------------ */
/*  Feature extraction                                                 */
/*  Cost: O(N + E) where N = Gr.nodes, E = Gr.edges                   */
/* ------------------------------------------------------------------ */

void ql_extract_features(double *features,
                         unsigned short *mapping,
                         unsigned short *core_mapping_flag,
                         unsigned short *router_mapping_flag,
                         unsigned short *inv_map,
                         unsigned short node,
                         unsigned short tile_id,
                         float **G,
                         double **powerloss,
                         unsigned short mapping_count)
{
    int N = Gr.nodes;
    int total_tiles = Gr.rows * Gr.colums;

    /* f0: bias */
    features[0] = 1.0;

    /* f1: fraction of nodes mapped (progress) */
    double frac = (double)mapping_count / N;
    features[1] = frac;

    /* f2: fraction mapped squared (non-linear progress term) */
    features[2] = frac * frac;

    /* Scan neighbors of 'node' in the communication graph */
    int total_neighbors = 0;
    int mapped_neighbors = 0;
    double total_comm_weight = 0.0;
    double sum_hop = 0.0;
    double min_hop = 9999.0;
    double max_hop = 0.0;
    double wc_ploss = -9999.0;
    double comm_hop_product = 0.0;
    int hop_n = 0;

    for (int i = 0; i < N; i++) {
        double w = (double)(G[node][i] + G[i][node]);
        if (w > 0.0) {
            total_neighbors++;
            if (core_mapping_flag[i] == 1) {
                mapped_neighbors++;
                total_comm_weight += w;

                unsigned short neighbor_tile = inv_map[i];
                double h = (double)hop_dist(tile_id, neighbor_tile);
                sum_hop += h;
                if (h < min_hop) min_hop = h;
                if (h > max_hop) max_hop = h;
                hop_n++;

                /* Weighted hop distance: heavy edges should be short */
                comm_hop_product += w * h;

                /* Power loss from candidate tile to neighbor's tile */
                double pl = powerloss[tile_id][neighbor_tile];
                if (pl > wc_ploss) wc_ploss = pl;
            }
        }
    }

    /* f3: ratio of mapped neighbors */
    features[3] = total_neighbors > 0
                  ? (double)mapped_neighbors / total_neighbors : 0.0;

    /* f4: total communication weight to mapped neighbors (normalized) */
    features[4] = total_comm_weight / (N * 10.0 + 1.0);

    /* f5: average hop distance to mapped neighbors (normalized) */
    double max_possible_hop = (double)(Gr.rows - 1 + Gr.colums - 1);
    features[5] = (hop_n > 0)
                  ? (sum_hop / hop_n) / (max_possible_hop + 1.0) : 0.5;

    /* f6: minimum hop distance to mapped neighbors (normalized) */
    features[6] = (hop_n > 0)
                  ? min_hop / (max_possible_hop + 1.0) : 0.5;

    /* f7: worst-case power loss to mapped neighbors (normalized) */
    features[7] = (wc_ploss > -9999.0) ? wc_ploss / 100.0 : 0.0;

    /* f8: tile centrality -- distance from mesh center, normalized to [0,1] */
    int row = tile_id / Gr.colums;
    int col = tile_id % Gr.colums;
    double center_r = (Gr.rows  - 1) / 2.0;
    double center_c = (Gr.colums - 1) / 2.0;
    double dist_center = fabs(row - center_r) + fabs(col - center_c);
    features[8] = 1.0 - dist_center / (center_r + center_c + 1.0);

    /* f9: number of free adjacent tiles / 4 (placement flexibility) */
    int free_adj = 0;
    if (row > 0             && router_mapping_flag[(row-1)*Gr.colums + col] == 0) free_adj++;
    if (row < Gr.rows - 1   && router_mapping_flag[(row+1)*Gr.colums + col] == 0) free_adj++;
    if (col > 0             && router_mapping_flag[row*Gr.colums + (col-1)] == 0) free_adj++;
    if (col < Gr.colums - 1 && router_mapping_flag[row*Gr.colums + (col+1)] == 0) free_adj++;
    features[9] = free_adj / 4.0;

    /* f10: communication-weighted hop product (normalized) --
       captures how well this placement minimizes weighted distance */
    features[10] = comm_hop_product / (N * 100.0 + 1.0);

    /* f11: max hop distance to mapped neighbors (spread indicator) */
    features[11] = (hop_n > 0)
                   ? max_hop / (max_possible_hop + 1.0) : 0.5;
}

/* ------------------------------------------------------------------ */
/*  Q-value computation                                                */
/* ------------------------------------------------------------------ */

double ql_compute_q(QLearningAgent *agent, double *features)
{
    double q = 0.0;
    for (int i = 0; i < QL_NUM_FEATURES; i++)
        q += agent->weights[i] * features[i];
    return q;
}

/* ------------------------------------------------------------------ */
/*  Action selection                                                   */
/* ------------------------------------------------------------------ */

unsigned short ql_select_action(QLearningAgent *agent,
                                unsigned short *mapping,
                                unsigned short *core_mapping_flag,
                                unsigned short *router_mapping_flag,
                                unsigned short *inv_map,
                                unsigned short node,
                                unsigned short *pos,
                                unsigned short pos_count,
                                float **G,
                                double **powerloss,
                                unsigned short mapping_count,
                                int training)
{
    double best_q = -1e30;
    unsigned short best_idx = 0;
    double features[QL_NUM_FEATURES];

    /* Epsilon-greedy: with probability epsilon, pick a random action */
    if (training && ((double)rand() / RAND_MAX) < agent->epsilon) {
        unsigned short rand_idx = (unsigned short)(rand() % pos_count);

        /* Still extract features for recording */
        ql_extract_features(features, mapping, core_mapping_flag,
                            router_mapping_flag, inv_map, node,
                            pos[rand_idx], G, powerloss, mapping_count);
        ql_record_step(agent, features);
        return rand_idx;
    }

    /* Greedy: pick action with highest Q-value */
    double best_features[QL_NUM_FEATURES];
    for (unsigned short i = 0; i < pos_count; i++) {
        ql_extract_features(features, mapping, core_mapping_flag,
                            router_mapping_flag, inv_map, node,
                            pos[i], G, powerloss, mapping_count);
        double q = ql_compute_q(agent, features);
        if (q > best_q) {
            best_q = q;
            best_idx = i;
            memcpy(best_features, features, sizeof(features));
        }
    }

    if (training)
        ql_record_step(agent, best_features);

    return best_idx;
}

/* ------------------------------------------------------------------ */
/*  Episode recording & Monte Carlo update                             */
/* ------------------------------------------------------------------ */

void ql_record_step(QLearningAgent *agent, double *features)
{
    if (agent->episode_len < QL_MAX_EPISODE_STEPS) {
        memcpy(agent->episode[agent->episode_len].features,
               features, sizeof(double) * QL_NUM_FEATURES);
        agent->episode_len++;
    }
}

void ql_reset_episode(QLearningAgent *agent)
{
    agent->episode_len = 0;
}

void ql_update_episode(QLearningAgent *agent, double final_snr)
{
    /*
     * Monte Carlo policy gradient / value update:
     * For each step t in the episode:
     *   G_t = final_snr  (undiscounted, reward only at end)
     *   delta = G_t - Q(s_t, a_t)
     *   w += alpha * delta * phi(s_t, a_t)
     *
     * This drives Q(s,a) towards predicting the final SNR of the
     * mapping that results from choosing action a in state s.
     */
    double alpha = agent->learning_rate;

    for (int t = 0; t < agent->episode_len; t++) {
        double q = ql_compute_q(agent, agent->episode[t].features);
        double delta = final_snr - q;

        for (int i = 0; i < QL_NUM_FEATURES; i++)
            agent->weights[i] += alpha * delta * agent->episode[t].features[i];
    }

    agent->episodes_trained++;

    /* Decay epsilon over time: slower exploration as we learn */
    if (agent->epsilon > 0.05)
        agent->epsilon *= 0.995;
}

/* ------------------------------------------------------------------ */
/*  Persistence                                                        */
/* ------------------------------------------------------------------ */

int ql_save_weights(QLearningAgent *agent, const char *filename)
{
    FILE *f = fopen(filename, "w");
    if (!f) return -1;

    fprintf(f, "%d %d\n", QL_NUM_FEATURES, agent->episodes_trained);
    for (int i = 0; i < QL_NUM_FEATURES; i++)
        fprintf(f, "%.15e\n", agent->weights[i]);
    fprintf(f, "%.15e\n", agent->epsilon);

    fclose(f);
    return 0;
}

int ql_load_weights(QLearningAgent *agent, const char *filename)
{
    FILE *f = fopen(filename, "r");
    if (!f) return -1;

    int nf, ep;
    if (fscanf(f, "%d %d", &nf, &ep) != 2 || nf != QL_NUM_FEATURES) {
        fclose(f);
        return -1;
    }
    agent->episodes_trained = ep;

    for (int i = 0; i < QL_NUM_FEATURES; i++) {
        if (fscanf(f, "%le", &agent->weights[i]) != 1) {
            fclose(f);
            return -1;
        }
    }
    if (fscanf(f, "%le", &agent->epsilon) != 1)
        agent->epsilon = 0.05;  /* default for inference */

    fclose(f);
    return 0;
}
