# Q-Learning Optimized SNR-Aware Task-to-Tile Mapping for Optical Networks-on-Chip

## Detailed Technical Documentation

---

## Table of Contents

1. [Introduction and Motivation](#1-introduction-and-motivation)
2. [Reinforcement Learning Formulation](#2-reinforcement-learning-formulation)
3. [State Representation and Feature Engineering](#3-state-representation-and-feature-engineering)
4. [Q-Value Function Approximation](#4-q-value-function-approximation)
5. [Training Algorithm](#5-training-algorithm)
6. [Inference Algorithm](#6-inference-algorithm)
7. [Complexity Analysis](#7-complexity-analysis)
8. [Architecture and Implementation Details](#8-architecture-and-implementation-details)
9. [Usage and Workflow](#9-usage-and-workflow)
10. [Theoretical Foundations and Convergence](#10-theoretical-foundations-and-convergence)
11. [Summary of Contributions](#11-summary-of-contributions)

---

## 1. Introduction and Motivation

### 1.1 Problem Context

Optical Networks-on-Chip (ONoC) architectures route inter-core communication through optical waveguides on a mesh of processing tiles. The **task-to-tile mapping problem** assigns *N* application tasks (IP cores) to *N* physical tiles on an *R x C* mesh such that the **worst-case Signal-to-Noise Ratio (SNR)** across all communication edges is maximized.

Maximizing worst-case SNR is critical because the optical link with the lowest SNR determines the overall reliability of the communication fabric.

The mapping decision must simultaneously account for three competing physical phenomena:

- **Power loss** (*P_loss*): Signal attenuation along the optical path between two tiles, dependent on path length and the number of intermediate optical components (couplers, crossings, bends).
- **Crosstalk** (*X_t*): Electromagnetic interference injected into a signal's waveguide by co-propagating or crossing signals from other communication pairs. Crosstalk is a function of *all* active communication pairs, making it a global property of the mapping.
- **Signal-to-Noise Ratio**: SNR_e = P_loss(e) - X_t(e) (in dB), where *e* is a communication edge. The optimization target is: **max min_{e in E} SNR_e**.

### 1.2 The Computational Bottleneck in the Baseline Algorithm

The baseline composite heuristic (Action 2) employs a constructive greedy algorithm with **predictive lookahead**. At each step *k* (mapping the *k*-th task), when multiple candidate tile positions are equally ranked by the greedy SNR heuristic (`find_min_SNR_pos`), the algorithm invokes a **prediction phase** (`predict_best_pos_SNR`) that:

1. For each of the *P* candidate positions, creates a *complete* temporary copy of the current mapping state.
2. **Greedily completes the remaining *N - k* task placements** using the SNR-aware heuristic.
3. Evaluates the worst-case SNR of each completed mapping via `evaluateSNR`.
4. Selects the candidate whose completed mapping yields the highest worst-case SNR.

This prediction phase is invoked at each of the *N* mapping steps, and the `evaluateSNR` evaluation itself iterates over all *E* edges with their crosstalk interactions.

### 1.3 Complexity Analysis of the Baseline Prediction

Let *N* denote the number of tasks/tiles, *E* the number of communication edges, and *P* the number of candidate positions at a given step (typically P <= N).

| Scope | Complexity |
|-------|-----------|
| Per candidate rollout | O((N - k) * N * E) |
| Per decision step | O(P * (N - k) * N * E) |
| Total across all N steps | O(P * N^3 * E) |
| Across all starting positions | O(P * N^4 * E) |

For a typical 8x8 mesh (N = 64) with E ~ 200 edges and P ~ 5:

**Baseline per mapping ~ 5 x 64^3 x 200 ~ 2.62 x 10^8 operations**

### 1.4 Objective of Q-Learning Optimization

The Q-Learning optimization replaces the expensive predictive lookahead with a **learned value function** that estimates the quality of each candidate tile placement in constant time per candidate (modulo feature extraction). This reduces:

- **Per-decision cost**: from O(P * N^2 * E) to **O(P * N)**
- **Total per-mapping cost**: from O(P * N^3 * E) to **O(P * N^2)**
- **Asymptotic speedup factor**: **O(N * E)**

---

## 2. Reinforcement Learning Formulation

### 2.1 Markov Decision Process (MDP) Definition

The task-to-tile mapping problem is formulated as a finite-horizon, episodic MDP **M = <S, A, T, R, gamma>**:

**State space S**: A state *s_k* at step *k* represents the current partial mapping -- which tasks have been placed on which tiles, along with the communication graph structure and physical layer parameters. The state is not stored explicitly but is encoded via a feature vector **phi(s, a)** (see Section 3).

**Action space A(s_k)**: At state *s_k*, the action set consists of the candidate tile positions {p_1, p_2, ..., p_{P_k}} returned by the SNR-aware greedy heuristic `find_min_SNR_pos`. These are the tiles that locally minimize power loss and crosstalk for the task being mapped. The Q-learning agent selects among these pre-filtered candidates, preserving the domain-specific heuristic as a "candidate generator."

**Transition function T**: Deterministic. Placing task *t* at tile *p* updates the mapping, marking the tile as occupied and the task as mapped, and advances to the next unmapped task (selected by the edge-priority ordering).

**Reward function R**: Sparse, terminal reward only.

```
r_k = 0                    if k < N (non-terminal step)
r_k = SNR_wc               if k = N (episode complete)
```

where SNR_wc = min_{e in E} SNR_e is the worst-case SNR of the complete mapping, computed by `evaluateSNR`.

**Discount factor gamma = 1.0**: Undiscounted, since the episode has a fixed finite horizon (N steps) and we care about the terminal outcome.

### 2.2 Why Q-Learning?

Q-learning is well-suited to this problem for several reasons:

1. **Model-free**: No explicit transition model is needed. The physical layer dynamics (power loss, crosstalk interactions) are complex and captured implicitly through the simulator.
2. **Off-policy**: Q-learning can learn from exploratory actions without requiring the training data to follow the optimal policy, enabling efficient exploration of the candidate space.
3. **Value function approximation**: The state space (all possible partial mappings of N tasks to N tiles) is combinatorially vast (O(N!)). Linear function approximation with domain-informed features provides generalization across unseen states.
4. **Lightweight inference**: Once trained, the Q-function evaluates to a single dot product per candidate -- ideal for the tight inner loop of the mapping algorithm.

---

## 3. State Representation and Feature Engineering

### 3.1 Design Philosophy

Direct tabular representation of the state is infeasible: for N = 64 tasks and tiles, the number of distinct partial mappings is superexponential. Instead, we employ a **feature-based state-action representation** phi(s_k, a) in R^12 that encodes the salient properties of the partial mapping *s_k* and the candidate action *a* (placing task *t* at tile *p*).

The features are designed to capture the key factors that influence final worst-case SNR: communication locality (hop distance), power loss exposure, mapping progress, tile geometry, and placement flexibility. All features are normalized to [0, 1] to ensure stable gradient updates.

### 3.2 Feature Vector Definition

Given state *s_k* (partial mapping with *k* tasks placed) and action *a* (place task *t* at tile *p*), the 12-dimensional feature vector **phi(s_k, a) = [phi_0, phi_1, ..., phi_11]** is defined as follows:

**Notation:**
- *N* = total tasks
- *R* = mesh rows, *C* = mesh columns
- *N(t)* = communication neighbors of task *t*
- *N_m(t)* = {i in N(t) : i is already mapped}
- *d_hop(p, q)* = Manhattan distance between tiles p and q = |r_p - r_q| + |c_p - c_q|
- *tau(i)* = the tile to which task *i* is mapped (i.e., inv_map[i])
- *w_ij* = communication weight from task *i* to task *j* in the application graph G
- *P_loss(p, q)* = optical power loss (in dB) between tiles *p* and *q*
- *r_p, c_p* = row and column coordinates of tile *p* on the mesh

| Index | Name | Formula | Range |
|-------|------|---------|-------|
| phi_0 | **Bias** | 1.0 | {1} |
| phi_1 | **Mapping Progress** | k / N | [0, 1] |
| phi_2 | **Quadratic Progress** | (k / N)^2 | [0, 1] |
| phi_3 | **Mapped Neighbor Ratio** | \|N_m(t)\| / \|N(t)\| | [0, 1] |
| phi_4 | **Communication Weight** | sum_{i in N_m(t)} (w_ti + w_it) / (10N + 1) | [0, 1] |
| phi_5 | **Avg. Hop Distance** | (1/\|N_m(t)\|) * sum_{i in N_m(t)} d_hop(p, tau(i)) / (R + C - 1) | [0, 1] |
| phi_6 | **Min. Hop Distance** | min_{i in N_m(t)} d_hop(p, tau(i)) / (R + C - 1) | [0, 1] |
| phi_7 | **Worst-Case Power Loss** | max_{i in N_m(t)} P_loss(p, tau(i)) / 100 | ~[0, 1] |
| phi_8 | **Tile Centrality** | 1 - (\|r_p - (R-1)/2\| + \|c_p - (C-1)/2\|) / ((R-1)/2 + (C-1)/2 + 1) | [0, 1] |
| phi_9 | **Placement Flexibility** | \|{free adjacent tiles of p}\| / 4 | [0, 1] |
| phi_10 | **Comm-Weighted Hop** | sum_{i in N_m(t)} (w_ti + w_it) * d_hop(p, tau(i)) / (100N + 1) | [0, 1] |
| phi_11 | **Max. Hop Distance** | max_{i in N_m(t)} d_hop(p, tau(i)) / (R + C - 1) | [0, 1] |

### 3.3 Feature Design Rationale

Each feature captures a distinct physical or structural property relevant to SNR optimization:

**phi_0 (Bias)**: Provides a learnable offset, ensuring the Q-function can represent non-zero baseline values independent of state.

**phi_1, phi_2 (Mapping progress, linear and quadratic)**: The importance of each placement decision changes as the mapping progresses. Early decisions have higher downstream impact but less information; late decisions are more constrained. The quadratic term captures this non-linearity: the model can learn different weight regimes for early vs. late mapping stages.

**phi_3 (Mapped neighbor ratio)**: Tasks with more already-mapped neighbors have more constrained and informative placement decisions. A higher ratio means the SNR impact of this placement can be estimated more reliably, as more communication edges become "active" (both endpoints mapped).

**phi_4 (Communication weight to mapped neighbors)**: Captures the total communication bandwidth at stake. Placing a heavily-communicating task far from its partners degrades SNR through increased power loss and crosstalk exposure.

**phi_5, phi_6, phi_11 (Hop distance statistics -- average, minimum, maximum)**: Manhattan distance directly influences optical path length, and hence power loss (P_loss increases with hop count) and crosstalk exposure (longer paths cross more waveguides). The minimum captures best-case proximity to any neighbor; the average captures overall locality; the maximum captures worst-case path length that could dominate the worst-case SNR edge.

**phi_7 (Worst-case power loss)**: Directly measures the physical layer cost of this placement. Since the optimization target is worst-case SNR, a placement that introduces a high power-loss link is likely to degrade the objective.

**phi_8 (Tile centrality)**: Central tiles in the mesh have shorter average path lengths to all other tiles, resulting in lower average power loss and potentially less crosstalk. This captures the geometric advantage of central placement.

**phi_9 (Placement flexibility)**: The number of free adjacent tiles indicates how much freedom remains for future placements. Occupying a tile whose neighbors are all taken may "corner" future tasks into sub-optimal positions.

**phi_10 (Communication-weighted hop product)**: A composite feature that combines communication intensity with distance. It directly approximates the communication cost function sum(w_ij * d_hop), which is a proxy for power loss on weighted edges.

### 3.4 Computational Cost of Feature Extraction

Feature extraction requires a single pass over the N tasks to identify mapped neighbors and compute hop distances, power losses, and communication weights.

**T_features(s_k, a) = O(N)**

This is a key advantage: the features summarize the relevant mapping state in O(N) time, avoiding the O(N^2 * E) cost of a full greedy rollout.

---

## 4. Q-Value Function Approximation

### 4.1 Linear Architecture

We employ a linear function approximation for the Q-value:

```
Q(s, a; w) = w^T * phi(s, a) = sum_{i=0}^{11} w_i * phi_i(s, a)
```

where **w in R^12** is the learned weight vector.

### 4.2 Justification for Linear Approximation

- **Computational efficiency**: Evaluating Q(s, a) requires a single dot product (O(d) where d = 12), making it negligible compared to even the feature extraction cost.
- **Stability**: Linear function approximation with fixed features avoids the convergence issues that plague nonlinear approximators (e.g., neural networks) in Q-learning (Tsitsiklis & Van Roy, 1997). With well-designed features, linear Q-learning is guaranteed to converge under standard conditions.
- **Interpretability**: Each weight w_i directly indicates the importance and direction (positive/negative) of the corresponding feature for SNR optimization. This is valuable for understanding which physical factors most influence mapping quality.
- **Sample efficiency**: With only 12 parameters to learn, the model requires relatively few training episodes to converge, which is important since each training episode involves running the full mapping algorithm.

### 4.3 Weight Initialization

Weights are initialized to small random values drawn uniformly from [-0.005, 0.005]:

```
w_i ~ Uniform(-0.005, 0.005),  i = 0, 1, ..., 11
```

This breaks symmetry while keeping initial Q-values near zero, preventing large initial biases from dominating early exploration.

---

## 5. Training Algorithm

### 5.1 Overview

Training follows an **episodic Monte Carlo Q-learning** approach with linear function approximation and epsilon-greedy exploration. Each training episode corresponds to one complete mapping of all N tasks to tiles, starting from a specific initial tile position.

### 5.2 Episode Structure

An episode proceeds as follows:

1. **Initialization**: Select a starting tile p_0. Map the highest-communication task to p_0.
2. **Sequential placement** (steps k = 1, 2, ..., N-1):
   - (a) Select the next task t_k using edge-priority ordering (the task connected to already-mapped tasks via the highest-weight unmapped edge).
   - (b) Compute candidate tiles {p_1, ..., p_{P_k}} via `find_min_SNR_pos`.
   - (c) If P_k > 1: use epsilon-greedy to select a tile. If P_k = 1: deterministically place at the only candidate.
   - (d) Extract and record the feature vector phi(s_k, a_k) for the chosen state-action pair.
   - (e) Execute the placement and apply local improvement (swapping poorly-performing cores).
3. **Terminal evaluation**: Compute SNR_wc of the complete mapping via `evaluateSNR`.
4. **Weight update**: Apply Monte Carlo update using SNR_wc as the return for all steps.

### 5.3 Exploration Strategy: epsilon-Greedy

At each decision step during training, the agent selects its action according to:

```
a_k = random action from A(s_k)                           with probability epsilon
a_k = argmax_{a in A(s_k)} Q(s_k, a; w)                   with probability 1 - epsilon
```

The exploration rate epsilon decays multiplicatively after each episode:

```
epsilon_{n+1} = max(0.05, 0.995 * epsilon_n)
```

with initial value epsilon_0 = 0.3. This schedule ensures:

- **Sufficient early exploration** (epsilon = 0.3): approximately 30% of decisions explore random candidates.
- **Gradual shift to exploitation**: after ~120 episodes, epsilon reaches 0.16; after ~350 episodes, epsilon decays to the floor of 0.05.
- **Residual exploration** (epsilon_min = 0.05): prevents the policy from becoming completely greedy, allowing continued discovery of better mappings.

### 5.4 Monte Carlo Weight Update

After each episode, the weight vector is updated using the **every-visit Monte Carlo** method with semi-gradient descent. Since the reward is sparse (only at the terminal step) and the discount factor gamma = 1.0, the return for every step *t* in the episode equals the terminal reward:

```
G_t = SNR_wc    for all t in {0, 1, ..., T-1}
```

The weight update rule for each recorded step *t* is:

```
w <- w + alpha * (G_t - Q(s_t, a_t; w)) * grad_w Q(s_t, a_t; w)
```

Since Q is linear, the gradient is simply the feature vector:

```
grad_w Q(s_t, a_t; w) = phi(s_t, a_t)
```

Therefore, the complete update rule is:

```
+------------------------------------------------------------------+
|  w <- w + alpha * (SNR_wc - w^T * phi(s_t, a_t)) * phi(s_t, a_t) |
+------------------------------------------------------------------+
```

This update drives the Q-function to predict the expected final worst-case SNR, given that action a_t is taken in state s_t.

### 5.5 Hyperparameters

| Parameter | Symbol | Value |
|-----------|--------|-------|
| Learning rate | alpha | 0.001 |
| Initial exploration rate | epsilon_0 | 0.3 |
| Exploration decay factor | -- | 0.995 per episode |
| Minimum exploration rate | epsilon_min | 0.05 |
| Discount factor | gamma | 1.0 (undiscounted) |
| Number of features | d | 12 |
| Default training episodes | -- | 5 x R x C |
| Weight initialization | -- | Uniform(-0.005, 0.005) |

### 5.6 Starting Position Curriculum

During training, episodes systematically explore different starting tile positions:

```
p_0^(n) = n                         if n < R x C  (first pass: cover all tiles)
p_0^(n) = random(0, R x C - 1)     otherwise
```

This ensures that the Q-function learns from mappings initiated at every tile position (important since starting position significantly impacts final mapping quality), followed by random sampling for further refinement.

### 5.7 Training Algorithm Pseudocode

```
Algorithm: Q-Learning Training for SNR-Aware Task Mapping
---------------------------------------------------------
Input:  Application graph G = (V, E), mesh R x C, power loss matrix P,
        crosstalk data, number of episodes M
Output: Learned weight vector w

1.  Initialize w ~ Uniform(-0.005, 0.005)^12
2.  epsilon <- 0.3, alpha <- 0.001
3.  FOR episode n = 1 to M:
4.      Select starting tile p_0^(n) (curriculum strategy)
5.      Initialize partial mapping: place highest-comm task at p_0^(n)
6.      buffer <- empty                              // episode experience buffer
7.      FOR k = 1 to N - 1:
8.          Select next task t_k by edge-priority ordering
9.          candidates <- find_min_SNR_pos(t_k)
10.         IF |candidates| > 1:
11.             Draw u ~ Uniform(0, 1)
12.             IF u < epsilon:
13.                 a_k <- random candidate from candidates
14.             ELSE:
15.                 a_k <- argmax_{p in candidates} w^T * phi(s_k, p)
16.             ENDIF
17.             buffer.append(phi(s_k, a_k))
18.         ELSE:
19.             a_k <- candidates[0]                  // only one option
20.         ENDIF
21.         Execute placement: map t_k -> a_k
22.         Apply local improvement (core swap heuristic)
23.     ENDFOR
24.     SNR_wc <- evaluateSNR(complete mapping)
25.     FOR each phi_t in buffer:                     // Monte Carlo update
26.         delta <- SNR_wc - w^T * phi_t
27.         w <- w + alpha * delta * phi_t
28.     ENDFOR
29.     epsilon <- max(0.05, 0.995 * epsilon)
30. ENDFOR
31. Save w to disk
```

---

## 6. Inference Algorithm

### 6.1 Overview

During inference, the trained weight vector **w** is loaded from disk. The mapping algorithm proceeds identically to the baseline (Action 2), except that the expensive `predict_best_pos_SNR` call is replaced by a Q-value comparison:

```
a* = argmax_{p in candidates} Q(s, p; w) = argmax_{p in candidates} w^T * phi(s, p)
```

### 6.2 Inference Algorithm Pseudocode

```
Algorithm: Q-Learning Inference for SNR-Aware Task Mapping
-----------------------------------------------------------
Input:  Application graph G, mesh dimensions, physical layer data, trained weights w
Output: Best mapping M* and its worst-case SNR

1.  Load w from disk
2.  SNR_best <- -infinity
3.  FOR each starting tile p_0 in {0, 1, ..., R*C - 1} IN PARALLEL:
4.      Initialize mapping: place highest-comm task at p_0
5.      FOR k = 1 to N - 1:
6.          Select next task t_k by edge-priority ordering
7.          candidates <- find_min_SNR_pos(t_k)
8.          IF |candidates| > 1:
9.              a_k <- argmax_{p in candidates} w^T * phi(s_k, p)
10.                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
11.                     O(P * N) replaces O(P * N^2 * E)
12.         ELSE:
13.             a_k <- candidates[0]
14.         ENDIF
15.         Execute placement: map t_k -> a_k
16.         Apply local improvement
17.     ENDFOR
18.     SNR_k <- evaluateSNR(complete mapping)
19.     IF SNR_k > SNR_best:
20.         M* <- current mapping, SNR_best <- SNR_k
21.     ENDIF
22. ENDFOR
23. RETURN M*, SNR_best
```

### 6.3 Multi-threaded Parallel Execution

Inference is parallelized identically to the baseline Action 2. The R x C starting tile positions are partitioned into chunks assigned to T worker threads. Each thread holds a **read-only reference** to the shared weight vector **w** -- no synchronization is needed since weights are not modified during inference. The only synchronization is for file output and console logging (mutex-protected).

---

## 7. Complexity Analysis

### 7.1 Time Complexity Comparison

| Operation | Baseline (Action 2) | Q-Learning (Action 4) |
|-----------|---------------------|----------------------|
| Feature extraction per action | -- | O(N) |
| Q-value per action | -- | O(d) = O(1) |
| Prediction per candidate | O(N^2 * E) | -- |
| **Per decision step** | **O(P * N^2 * E)** | **O(P * N)** |
| **Per complete mapping** | **O(P * N^3 * E)** | **O(P * N^2)** |
| **All starting positions** | **O(P * N^4 * E)** | **O(P * N^3)** |
| **Speedup factor** | -- | **O(N * E)** |

### 7.2 Numerical Example (8x8 mesh)

For an 8x8 mesh (N = 64, R = C = 8) with E = 200 edges and average P = 5 candidates:

| Metric | Baseline | Q-Learning | Ratio |
|--------|----------|------------|-------|
| Operations per decision | 5 x 64^2 x 200 = 4,096,000 | 5 x 64 x 12 = 3,840 | 1,067x |
| Operations per mapping | ~2.62 x 10^8 | ~2.46 x 10^5 | 1,065x |
| Operations all start positions | ~1.68 x 10^10 | ~1.57 x 10^7 | 1,070x |
| **Estimated speedup** | -- | -- | **~1,068x** |

### 7.3 Training Cost

Training is a one-time offline cost:

```
T_train = M x O(P * N^2) = O(M * P * N^2)
```

With default M = 5 * N episodes, the total training cost is O(P * N^3) -- comparable to a *single* baseline mapping run across all starting positions. Training can be amortized: once weights are learned for an application graph, inference can be run repeatedly at negligible cost.

### 7.4 Space Complexity

| Component | Baseline | Q-Learning |
|-----------|----------|------------|
| Mapping arrays (per thread) | O(N) | O(N) |
| Temporary prediction arrays | O(N) per candidate | None |
| Q-function weights | None | O(d) = O(1) |
| Episode buffer (training only) | None | O(N * d) |
| Memoization cache | O(2^16) | None needed |

The Q-Learning approach uses slightly less memory during inference (no temporary arrays for prediction rollouts, no memoization cache) while adding only a 12-element weight vector.

---

## 8. Architecture and Implementation Details

### 8.1 Software Architecture

| File | Type | Purpose |
|------|------|---------|
| `qlearning.h` | Header | Agent struct, feature constants (d=12, max episode steps=256), experience buffer struct, function declarations |
| `qlearning.cpp` | Implementation | Feature extraction, Q-value computation, epsilon-greedy action selection, Monte Carlo weight update, weight save/load |
| `predictiveOptical.cpp` | Modified | New function `map_graph_qlearn` (Q-learning mapping variant), `ql_worker` (thread worker for inference), choice 3/4 handlers in `main()` |

### 8.2 Key Data Structures

```cpp
struct QLearningAgent {
    double weights[12];        // Learned weight vector w
    double learning_rate;      // alpha = 0.001
    double epsilon;            // exploration rate (decaying)
    double discount;           // gamma = 1.0
    QLExperience episode[256]; // Episode buffer for MC update
    int episode_len;           // Steps recorded this episode
    int episodes_trained;      // Cumulative training count
};

struct QLExperience {
    double features[12];       // phi(s_t, a_t) snapshot
};
```

### 8.3 Integration with Existing Heuristic Pipeline

The Q-Learning module is integrated as a **drop-in replacement** for the prediction phase, preserving all other components of the baseline algorithm:

1. **Candidate generation** (`find_min_SNR_pos`): **Unchanged.** The SNR-aware heuristic still filters tile candidates based on local power loss and crosstalk evaluation. This domain knowledge is preserved.
2. **Candidate selection**: **Changed.** Instead of `predict_best_pos_SNR` (full rollout), the Q-learning agent evaluates Q(s, a; w) for each candidate.
3. **Local improvement** (`improvement`): **Unchanged.** Core swapping based on worst-case SNR edge still runs on partial mappings.
4. **Task ordering**: **Unchanged.** Tasks are still selected by edge-priority ordering.
5. **Starting position enumeration**: **Unchanged.** All R x C starting positions are evaluated (in parallel during inference).

This design ensures that the Q-Learning optimization *complements* rather than replaces the existing domain-specific heuristics. The heuristic provides a high-quality candidate set; Q-learning learns to pick the best among them.

### 8.4 Thread Safety

- **Training** (choice 3): Single-threaded. The agent's weights and episode buffer are modified sequentially.
- **Inference** (choice 4): Multi-threaded. Each worker thread receives a *read-only pointer* to the shared `QLearningAgent`. Since epsilon = 0 and learning rate = 0 during inference, no writes occur to the agent struct. Feature extraction uses only thread-local arrays and read-only shared data (graph, power loss matrix, mesh structure).

### 8.5 Weight Persistence

Trained weights are saved in a human-readable text format:

```
12 320                     <- num_features, episodes_trained
1.234567890123456e-02      <- w_0 (bias)
-5.678901234567890e-03     <- w_1 (mapping progress)
...                        <- w_2 through w_10
3.456789012345678e-03      <- w_11 (max hop distance)
5.000000000000000e-02      <- final epsilon value
```

This enables:
- **Resumable training**: Loading existing weights and continuing training with additional episodes.
- **Cross-session inference**: Training once, then running fast inference in any subsequent session.
- **Weight inspection**: Direct examination of learned feature importances for interpretability analysis.

---

## 9. Usage and Workflow

### 9.1 Compilation

```bash
g++ -O2 -pthread predictiveOptical.cpp graph.c optical.c qlearning.cpp -lm
```

### 9.2 Two-Phase Workflow

#### Phase 1: Training (Choice 3)

```bash
# Train with default episodes (5 * total_tiles)
./a.out 40 3

# Train with custom number of episodes
./a.out 40 3 500
```

Output: Learned weights saved to `results/qweights_Graph40.txt`.
Training can be resumed by re-running with choice 3; existing weights are loaded and training continues.

#### Phase 2: Inference (Choice 4)

```bash
# Fast inference using learned Q-values (auto-detect threads)
./a.out 40 4

# Inference with custom thread count
./a.out 40 4 8
```

Output: Best mapping and SNR saved to `results/result_Graph40_SNR_QLinfer.txt`.

### 9.3 Comparison with Baseline

```bash
# Baseline: full prediction (slow)
time ./a.out 40 2

# Q-Learning: fast inference
time ./a.out 40 4
```

---

## 10. Theoretical Foundations and Convergence

### 10.1 Convergence of Linear Monte Carlo Q-Learning

Under the following conditions, linear Monte Carlo Q-learning with function approximation converges to a fixed point:

1. The feature vectors phi(s, a) are linearly independent (no redundant features).
2. The learning rate alpha satisfies the Robbins-Monro conditions: sum(alpha_n) = infinity and sum(alpha_n^2) < infinity. A constant alpha = 0.001 provides an approximation to this in practice.
3. All state-action pairs are visited infinitely often under the behavior policy (ensured by epsilon-greedy with epsilon_min > 0).

The fixed point satisfies:

```
w* = argmin_w  sum_{(s,a)} d(s,a) * (Q^pi(s, a) - w^T * phi(s, a))^2
```

where d(s,a) is the state-action visitation distribution under the epsilon-greedy policy and Q^pi is the true action-value function under policy pi.

### 10.2 Approximation Quality vs. Exact Lookahead

The Q-learning approach trades exactness for speed. The baseline prediction phase computes the *exact* greedy completion cost for each candidate, while the Q-function provides an *approximate* estimate. The quality of this approximation depends on:

- **Feature expressiveness**: Whether the 12 features capture the relevant factors for SNR prediction. The features are designed to capture communication locality, physical layer costs, and placement geometry -- the primary drivers of SNR.
- **Training coverage**: Whether the training episodes sufficiently explore the space of partial mappings and candidate decisions.
- **Generalization**: Whether patterns learned on training episodes transfer to unseen starting positions and mapping sequences.

The local improvement phase (`improvement`), which runs *after* each placement, partially compensates for sub-optimal Q-learning decisions by swapping cores to improve worst-case SNR. This provides a "safety net" that bounds the quality degradation.

---

## 11. Summary of Contributions

1. **MDP formulation** of the SNR-aware task-to-tile mapping problem as an episodic reinforcement learning task with sparse terminal reward.

2. **Domain-informed feature engineering**: A 12-dimensional feature vector that captures communication locality, power loss, crosstalk exposure, mesh geometry, and placement flexibility -- all computable in O(N) time.

3. **Linear Q-function approximation** that reduces the per-decision time complexity from O(P * N^2 * E) to O(P * N), yielding an asymptotic speedup of O(N * E) and an estimated ~1000x practical speedup for 64-node meshes.

4. **Hybrid heuristic-RL architecture**: The Q-learning agent operates within the existing heuristic framework, using domain heuristics for candidate generation and local improvement, while learning to make better selection decisions among candidates.

5. **Practical two-phase workflow**: Offline training (one-time cost comparable to a single baseline run) produces a persistent weight file; online inference is multi-threaded and orders of magnitude faster than the baseline.

---

## References

1. C. J. C. H. Watkins and P. Dayan, "Q-Learning," *Machine Learning*, vol. 8, no. 3-4, pp. 279-292, 1992.
2. R. S. Sutton and A. G. Barto, *Reinforcement Learning: An Introduction*, 2nd ed. MIT Press, 2018.
3. J. N. Tsitsiklis and B. Van Roy, "An analysis of temporal-difference learning with function approximation," *IEEE Transactions on Automatic Control*, vol. 42, no. 5, pp. 674-690, 1997.
4. F. S. Melo, "Convergence of Q-learning: A simple proof," *Institute of Systems and Robotics, Tech. Rep.*, 2001.
