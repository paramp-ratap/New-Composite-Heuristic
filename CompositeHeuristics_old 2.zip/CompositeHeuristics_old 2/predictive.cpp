#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <string.h>
#include <math.h>
#include "graph.h"
#include "predictive.h"
using namespace std;
extern	struct graph_info Gr;
extern struct edge_info *edges;
//extern struct virtual_address address;
struct virtual_address address;
//unsigned short cores;

void read_graph(float**G,char* data)
{
    unsigned short nodes,row=0,colum=0;
    char*buff,*arg;
    char*file_name;
    fstream fp;
    buff=new char [5];
    arg=new char [5];
    file_name=new char [50];
    //data=atoi(argument);
    Gr.edges=0;
    //arg=itoa(int(data),arg,10);
    strcpy(file_name,"Graph");
    strcat(file_name,data);
    strcat(file_name,".txt");
    fp.open(file_name,ios::in);
    //Gr.edges=0;
    /*if(data==1)
        fp.open("Graph6.txt",ios::in);
    else if(data==2)
        fp.open("Graph2.txt",ios::in);
    else if(data==3)
        fp.open("Graph3.txt",ios::in);
    else if(data==4)
        fp.open("Graph17.txt",ios::in);*/
        //cout<<"its open"<<endl;
        fp>>nodes;
        
        //cout<<nodes<<endl;
        fp>>buff;
        while(row<Gr.nodes)
        {
            if(strcmp(buff,"INF")==0)
            {
                G[row][colum]=0;
                colum++;
               // cout<<"here";
            }
            else
            {
                G[row][colum]=atof(buff);
                if(row!=colum)
                    Gr.edges++;
                colum++;
            }
            if(colum>=nodes)
            {
                colum=0;
                row++;
            }
            fp>>buff;
        }
   /*for(int index=0;index<Gr.nodes;index++){
        for(int index2=0;index2<Gr.nodes;index2++)
            cout<<G[index][index2]<<",";
        cout<<"\n";
   }*/
    fp.close();
    Gr.edges=Gr.edges/2;
}

void short_edges(void)
{
    unsigned short edge_index,edge_index2;
    struct edge_info temp;
    for(edge_index=0;edge_index<Gr.edges;edge_index++)
    {
        for(edge_index2=edge_index;edge_index2<Gr.edges;edge_index2++)
        {
            if(edges[edge_index2].edge_weight>edges[edge_index].edge_weight)
            {
                temp.source=edges[edge_index2].source;
                temp.destination=edges[edge_index2].destination;
                temp.edge_weight=edges[edge_index2].edge_weight;
                edges[edge_index2].source=edges[edge_index].source;
                edges[edge_index2].destination=edges[edge_index].destination;
                edges[edge_index2].edge_weight=edges[edge_index].edge_weight;
                edges[edge_index].source=temp.source;
                edges[edge_index].destination=temp.destination;
                edges[edge_index].edge_weight=temp.edge_weight;
            }
        }
    }
}
void display_edges(void)
{
    unsigned short edge_index2;
    for(edge_index2=0;edge_index2<Gr.edges;edge_index2++)
    {
        cout<<edges[edge_index2].source<<" ---> "<<edges[edge_index2].destination<<" = "<<edges[edge_index2].edge_weight<<endl;
    }
}
void intialize_array(unsigned short* array)
{
    unsigned short index;
    for(index=0;index<Gr.nodes;index++)
    {
        array[index]=0;
    }
}

float get_communicatio_of_node(unsigned short node,float**G)
{
    unsigned short node_index;
    float comm=0;
    for(node_index=0;node_index<Gr.nodes;node_index++)
    {
        comm=comm+G[node][node_index];
    }
    return comm;
}
unsigned short get_maximum_outgoing_edge_maped_node(unsigned short* core_mapping_flag,struct edge_info edge)
{
    if(core_mapping_flag[edge.source] & core_mapping_flag[edge.destination])
        return 0;
    else if(core_mapping_flag[edge.source])
        return 1;
    else if(core_mapping_flag[edge.destination])
        return 2;
    else
        return 0;


}
unsigned short int hop_count(unsigned short node1,unsigned short node2)
{
    unsigned short no_hops;
    no_hops=abs(address.colum[node1]-address.colum[node2])+abs(address.row[node1]-address.row[node2]);
    return no_hops;
}
void intialize_mapping_var(unsigned short* map)
{
    unsigned short index;
    for(index=0;index<Gr.nodes;index++)
        map[index]=9999;
}
unsigned short find_min_comm_pos(unsigned short *core_mapping_flag,unsigned short node,unsigned short *pos,float**G,unsigned short int*router_mapping_flag,unsigned short *mapping,unsigned short*inv_map)
{
    unsigned short node_indexl,node_index2,count=0,index;
    float *comm_pos,min_comm=99999999, comm=0.0;
    comm_pos=new float [Gr.nodes];
    //intialize_array((unsigned short *)comm_pos);
    for(node_index2=0;node_index2<Gr.nodes;node_index2++)
        comm_pos[node_index2]=99999999;
    for(node_indexl=0;node_indexl<Gr.nodes;node_indexl++)
    {
         comm=0;
        if(router_mapping_flag[node_indexl]==0)
        {
            for(node_index2=0;node_index2<Gr.nodes;node_index2++)
            {
                if(core_mapping_flag[node_index2]==1)
                {
                    //for(index=0;index<Graph.nodes;index++)
                    //{
                     //    if(mapping[index]==node_index2)
                     //       break;
                    //}
					index=inv_map[node_index2];
                    comm=comm+G[node_index2][node]*hop_count(node_indexl,index);
                }
            }
           comm_pos[node_indexl]=comm;
           if(comm<min_comm)
           {
               min_comm=comm;
              // pos[0]=node_indexl;
               //cout<<"min_comm_pos = "<<min_comm<<endl;
           }

        }
    }
     //if(node==2)
        //cout<<"min comm ="<<min_comm<<endl;
    count=0;
    
    for(node_indexl=0;node_indexl<Gr.nodes;node_indexl++)
    {
        if(comm_pos[node_indexl]==min_comm)
        {
            pos[count]=node_indexl;
            count++;
           //cout<<"cost for each positions = "<<comm_pos[node_indexl]<<endl;
        }
    }
    //cout<<"pos[0] = "<<pos[0]<<" count= "<<count<<endl;
    return count;
}

void copy_arrays(unsigned short*source,unsigned short *destination)
{
    unsigned short index=0;
    for(index=0;index<Gr.nodes;index++)
    {
        destination[index]=source[index];
    }
}
float cost(unsigned short*map,float**G)
{
    unsigned short index1,index2;
    float cost=0;
    for(index1=0;index1<Gr.nodes;index1++)
    {
        for(index2=index1+1;index2<Gr.nodes;index2++)
        {
            cost=cost+hop_count(index1,index2)*G[map[index1]][map[index2]];
            //cout<<"COST()= "<<hop_count(index1,index2)<<endl;
        }
    }
    //cout<<"COST()= "<<cost<<endl;
    return cost;
}
unsigned short predict_best_pos(unsigned short *mapping,unsigned short*pos,float**G,unsigned short pos_count,unsigned short node,unsigned short mapping_count,unsigned short* core_mapping_flag,unsigned short*router_mapping_flag,unsigned short*best_map,float*bestcost,unsigned short* inv_map)
{
    unsigned short count=0,temp_map_count=mapping_count,edge_index,find_node=0,temp_node,index;
    unsigned short* temp_pos,*temp_map,*temp_core_map_flag,*temp_router_map_flag,*temp_inv_map;
    float min_cost=999999,comm_cost;
    unsigned short best_pos;
    temp_pos=new unsigned short[Gr.nodes];
    temp_map=new unsigned short[Gr.nodes];
    temp_core_map_flag=new unsigned short[Gr.nodes];
    temp_router_map_flag=new unsigned short [Gr.nodes];
    temp_inv_map=new unsigned short[Gr.nodes];
    intialize_mapping_var(temp_map);
    intialize_mapping_var(temp_inv_map);
    intialize_array(temp_core_map_flag);
    intialize_array(temp_pos);
    intialize_array(temp_router_map_flag);
   // cout<<"intialize done"<<endl;
    while(count<pos_count)
    {
        mapping_count=temp_map_count;
        copy_arrays(mapping,temp_map);
        copy_arrays(core_mapping_flag,temp_core_map_flag);
        copy_arrays(router_mapping_flag,temp_router_map_flag);
		copy_arrays(inv_map,temp_inv_map);
        //cout<<"mappin count "<<mapping_count<<endl;
        temp_map[pos[count]]=node;
        mapping_count++;
        //cout<<"mappin count "<<mapping_count<<endl;
        temp_router_map_flag[pos[count]]=1;
        temp_core_map_flag[node]=1;
        temp_inv_map[node]=pos[count];
        //cout<<" prediction started"<<endl;
        while(mapping_count<Gr.nodes)
        {
            find_node=0;
            edge_index=0;
            while(find_node!=1)
            {
                if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==1)
                {
                    temp_node=edges[edge_index].destination;
                    //break;
                    find_node=1;
                }
                if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==2)
                {
                    temp_node=edges[edge_index].source;
                    //break;
                    find_node=1;
                }

                edge_index++;
                if(edge_index==Gr.edges)
		        {
		        	if(find_node==0)
		        	{
		        		for(index=0;index<Gr.nodes;index++)
		        		{
		        			if(temp_core_map_flag[index]==0)
		        			{
		        				temp_node=index;
		        				find_node=1;
		        				break;
		        			}
		        		}
		        	}
		        }
            }//1st while loop ends here
            
           // cout<<"mapping count "<<mapping_count<<"temp node in prediction = "<<temp_node<<endl;
            intialize_array(temp_pos);
            //cout<<"again intialization done"<<endl;
            //cout<<"Mapping count = "<<mapping_count<<" Graph nodes= " <<Gr.nodes<<endl;
             find_min_comm_pos(temp_core_map_flag,temp_node,temp_pos,G,temp_router_map_flag,temp_map,temp_inv_map);
            
            //cout<<"i know where is proble"<<endl;
            temp_map[temp_pos[0]]=temp_node;
            temp_core_map_flag[temp_node]=1;
            temp_router_map_flag[temp_pos[0]]=1;
            temp_inv_map[temp_node]=temp_pos[0];
            mapping_count++;
        }//2nd while() ends here.
        comm_cost=cost(temp_map,G);
        //cout<<"cost at intermediate stage"<<comm_cost<<endl;
        if(comm_cost<min_cost)
        {
            min_cost=comm_cost;
            best_pos=count;
        }

        if(comm_cost<*bestcost)
        {
            *bestcost=comm_cost;
            copy_arrays(temp_map,best_map);
        }
        count++;
    }//3rd while() ends here
    //cout<<"best position"<<pos[best_pos]<<endl;
    return best_pos;
}

void display_mapping(unsigned short*mapping)
{
    unsigned short row_index,colum_index;
    for(row_index=0;row_index<Gr.rows;row_index++)
    {
        for(colum_index=0;colum_index<Gr.colums;colum_index++)
        {
            cout<<mapping[row_index*Gr.colums+colum_index]<<"\t";
        }
        cout<<endl;
    }
}
void display_min_pos(unsigned short *pos,unsigned short pos_count)
{
    unsigned short index;
    cout<<"positions"<<endl;
    for(index=0;index<pos_count;index++)
       cout <<pos[index]<<"\t";
       cout<<endl;
}
unsigned short * map_graph(float**G,unsigned short router_id)
{
    unsigned short mapping_count=0,edge_index=0,temp_node1,temp_node2,index;
    unsigned short *router_mapping_flag,*core_mapping_flag,find_node=0,pos_count=0;
    unsigned short *mapping,*pos,best_pos=0;
    unsigned short* best_map;
    unsigned short *inv_map;
    unsigned short buff=0;
    float comm_cost=0,*bestcost,bc;
    router_mapping_flag=new unsigned short [Gr.nodes];
    core_mapping_flag=new unsigned short [Gr.nodes];
    pos=new unsigned short [Gr.nodes];
    mapping=new unsigned short [Gr.nodes];
    best_map=new unsigned short [Gr.nodes];
    inv_map=new unsigned short [Gr.nodes];
    bc=999999;
    bestcost=&bc;
    intialize_array(router_mapping_flag);
    intialize_mapping_var(mapping);
    intialize_array(core_mapping_flag);
    
    temp_node1=edges[0].destination;
    temp_node2=edges[0].source;
    //router_id=(floor(Gr.rows/2.0)-1)*Gr.colums+floor(Gr.colums/2.0)-1;
    //cout<<"******* router _id is = "<<router_id<<endl;
    if(get_communicatio_of_node(temp_node1,G)>get_communicatio_of_node(temp_node2,G))
    {
        mapping[router_id]=temp_node1;
        core_mapping_flag[temp_node1]=1;
        inv_map[temp_node1]=router_id;
    }
    else
    {
        mapping[router_id]=temp_node2;
        core_mapping_flag[temp_node2]=1;
        inv_map[temp_node2]=router_id;
    }
    router_mapping_flag[router_id]=1;
    mapping_count++;
    //cout<<"first node mapped"<<endl;
    while(mapping_count<Gr.nodes)
    {
        find_node=0;
        edge_index=0;
        while(find_node!=1)
        {
            if(get_maximum_outgoing_edge_maped_node(core_mapping_flag,edges[edge_index])==1)
            {
                temp_node1=edges[edge_index].destination;
                find_node=1;
            }

            else if(get_maximum_outgoing_edge_maped_node(core_mapping_flag,edges[edge_index])==2)
            {
                temp_node1=edges[edge_index].source;
                find_node=1;
            }
            edge_index++;
            if(edge_index==Gr.edges)
            {
            	if(find_node==0)
            	{
            		for(index=0;index<Gr.nodes;index++)
            		{
            			if(core_mapping_flag[index]==0)
            			{
            				temp_node1=index;
            				find_node=1;
            				break;
            			}
            		}
            	}
            }
        }
        //cout<<"selected nodes = "<<temp_node1<<endl;
        intialize_array(pos);
        pos_count=find_min_comm_pos(core_mapping_flag,temp_node1,pos,G,router_mapping_flag,mapping,inv_map);
        //cout<<"currnt node mapping="<<temp_node1<<endl;
        //cout<<"pos_count = "<<pos_count<<endl;
        buff=0;
        if(pos_count>4)
        {
        //display_min_pos(pos,pos_count);
        //cout<<"currnt node mapping="<<temp_node1<<endl;
        //cout<<"router_id= "<< router_id<<endl;
        //buff=1;
        }
        if(pos_count>1)
        {
            //copy_arrays(mapping,temp_map);
            //copy_arrays(core_mapping_flag,temp_core_map_flag);
            
            best_pos= predict_best_pos(mapping,pos,G,pos_count,temp_node1,mapping_count,core_mapping_flag,router_mapping_flag,best_map,bestcost,inv_map);
            //cout<<"Predict pos > 1\n";
            mapping[pos[best_pos]]=temp_node1;
            core_mapping_flag[temp_node1]=1;
            router_mapping_flag[pos[best_pos]]=1;
            inv_map[temp_node1]=pos[best_pos];
            mapping_count++;
        }
        else
        { //cout<<"temp_node1 = "<<temp_node1<<endl;
            mapping[pos[0]]=temp_node1;
            core_mapping_flag[temp_node1]=1;
            router_mapping_flag[pos[0]]=1;
            inv_map[temp_node1]=pos[0];
            mapping_count++;
        }
        //cout<<"prediction"<<endl;
        //cout<<"mapped core "<<mapping_count<<endl;
        //mapping_count++;
    }
    //cout<<"out of the loop"<<endl;
   // display_mapping(mapping);
   // comm_cost=cost(mapping,G);
    //cout<<"cost of mapping = "<<cost(mapping,G)<<endl;
    //if(buff==1)
    //{
    //cout<<"=================best mapping of all==============="<<endl;
    //display_mapping(best_map);
    //cout<<"cost of best map = "<<cost(best_map,G)<<endl;
    return mapping;
    //}
}

void display_data(float**G)
{
        unsigned short index,index2;
        for(index=0;index<Gr.nodes;index++)
        {
            for(index2=0;index2<Gr.nodes;index2++)
            {
                cout<<G[index][index2]<<"\t";
            }
            cout<<endl;
        }
}
void print_address(unsigned short*map,char*argument)
{
	unsigned short int *inv_map, node_index,index=0;
	fstream fp;
	unsigned short *rout;
	char *out_file_name;
	out_file_name= new char [50];
	unsigned short cores=32;
	rout=(unsigned short*)malloc(32*sizeof(unsigned short));
	inv_map=(unsigned short*)malloc(sizeof(unsigned short)*Gr.nodes);
	for(node_index=0;node_index<Gr.nodes;node_index++)
	{
		
		rout[node_index]=0;
	}
	for(node_index=0;node_index<32;node_index++)
	{
		
		rout[node_index]=0;
	}
	for(node_index=0;node_index<Gr.nodes;node_index++)
	{
		
		inv_map[map[node_index]]=node_index;
	}
	strcpy(out_file_name,"Addresses");
	strcat(out_file_name,argument);
	strcat(out_file_name,"_Mesh_VC_Predict_PSO.txt");
	fp.open(out_file_name,ios::out);
	fp<<"32"<<endl;
	for(node_index=0;node_index<Gr.nodes;node_index++)
	{
		if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==0)
		{
			fp<<"c"<<node_index+1<<" 00000000 0"<<endl;
			rout[0]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==1)
		{
			fp<<"c"<<node_index+1<<" 10000000 1"<<endl;
			rout[1]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==0)
		{
			fp<<"c"<<node_index+1<<" 00001000 2"<<endl;
			rout[2]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==1)
		{
			fp<<"c"<<node_index+1<<" 10001000 3"<<endl;
			rout[3]=1;
		}
		
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==2)
		{
			fp<<"c"<<node_index+1<<" 01000000 4"<<endl;
			rout[4]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==3)
		{
			fp<<"c"<<node_index+1<<" 11000000 5"<<endl;
			rout[5]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==2)
		{
			fp<<"c"<<node_index+1<<" 01001000 6"<<endl;
			rout[6]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==3)
		{
			fp<<"c"<<node_index+1<<" 11001000 7"<<endl;
			rout[7]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==0)
		{
			fp<<"c"<<node_index+1<<" 00000100 8"<<endl;
			rout[8]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==1)
		{
			fp<<"c"<<node_index+1<<" 10000100 9"<<endl;
			rout[9]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==0)
		{
			fp<<"c"<<node_index+1<<" 00001100 10"<<endl;
			rout[10]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==1)
		{
			fp<<"c"<<node_index+1<<" 10001100 11"<<endl;
			rout[11]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==2)
		{
			fp<<"c"<<node_index+1<<" 01000100 12"<<endl;
			rout[12]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==3)
		{
			fp<<"c"<<node_index+1<<" 11000100 13"<<endl;
			rout[13]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==2)
		{
			fp<<"c"<<node_index+1<<" 01001100 14"<<endl;
			rout[14]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==3)
		{
			fp<<"c"<<node_index+1<<" 11001100 15"<<endl;
			rout[15]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==4)
		{
			fp<<"c"<<node_index+1<<" 00100000 16"<<endl;
			rout[16]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==5)
		{	
			fp<<"c"<<node_index+1<<" 10100000 17"<<endl;
			rout[17]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==4)
		{
			fp<<"c"<<node_index+1<<" 00101000 18"<<endl;
			rout[18]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==5)
		{
			fp<<"c"<<node_index+1<<" 10101000 19"<<endl;
			rout[19]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==6)
		{
			fp<<"c"<<node_index+1<<" 01100000 20"<<endl;
			rout[20]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==7)
		{
			fp<<"c"<<node_index+1<<" 11100000 21"<<endl;
			rout[21]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==6)
		{
			fp<<"c"<<node_index+1<<" 01101000 22"<<endl;
			rout[23]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==7)
		{
			fp<<"c"<<node_index+1<<" 11101000 23"<<endl;
			rout[23]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==4)
		{
			fp<<"c"<<node_index+1<<" 00100100 24"<<endl;
			rout[24]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==5)
		{
			fp<<"c"<<node_index+1<<" 10100100 25"<<endl;
			rout[25]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==4)
		{
			fp<<"c"<<node_index+1<<" 00101100 26"<<endl;
			rout[26]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==5)
		{
			fp<<"c"<<node_index+1<<" 10101100 27"<<endl;
			rout[27]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==6)
		{
			fp<<"c"<<node_index+1<<" 01100100 28"<<endl;
			rout[28]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==7)
		{
			fp<<"c"<<node_index+1<<" 11100100 29"<<endl;
			rout[29]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==6)
		{
			fp<<"c"<<node_index+1<<" 01101100 30"<<endl;
			rout[30]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==7)
		{
			fp<<"c"<<node_index+1<<" 11101100 31"<<endl;
			rout[31]=1;
		}
	}
	while(node_index<32)
	{
		while(index<32)
		{
			if(rout[index]==0)
			{
			fp<<"c"<<node_index+1<<" xx "<<index<<endl;
			rout[index]=1;
			break;
			}
			index++;
		}
		node_index++;
	}	
	fp.close();
}

void intialize_virtual_add(void)
{
    unsigned short row_index,colum_index;
    //address=(struct virtual_address*)malloc(sizeof(struct virtual_address)*Gr.nodes);
    address.row=(unsigned short int *)malloc(sizeof(unsigned short int)*Gr.nodes);
    address.colum=(unsigned short int *)malloc(sizeof(unsigned short int)*Gr.nodes);
    for(row_index=0;row_index<Gr.rows;row_index++)
    {
        for(colum_index=0;colum_index<Gr.colums;colum_index++)
        {
            //address[row_index*Gr.colums+colum_index].row_add=row_index;
            //address[row_index*Gr.colums+colum_index].colum_add=colum_index;
            /*address[row_index*Gr.colums+colum_index].row=row_index;
            address[row_index*Gr.colums+colum_index].colum=colum_index;*/
            address.row[row_index*Gr.colums+colum_index]=row_index;
            address.colum[row_index*Gr.colums+colum_index]=colum_index;
            // cout<<"Core No= "<<row_index*Gr.colums+colum_index<<"row = "<<address.row[row_index*Gr.colums+colum_index]<<" Col= "<<address.colum[row_index*Gr.colums+colum_index]<<endl;
            //cout<<address[row_index*Gr.colums+colum_index].row_add<<address[row_index*Gr.colums+colum_index].colum_add<<"\t";
        }
        //cout<<endl;
    }
    //cout<<"intialized ok ok";
}

int main(int argc,char*argv[])
{
    float**G;
    unsigned short index1,index2;
    float best_cost=999999,temp_cost;
    unsigned short* mapping,*best_map;
   
    //intialize_graph_info(argv[1]); //Kanchan
    //cout<<"step 1 done"<<endl;
    
    
    //G=allocate_memory(); // Kanchan
    G = intialize_graph(argv[1], argv[1]);
    intialize_virtual_add(); // Kanchan
    cout<<"step 2 done"<<endl;
    //cout<<"step 3 done"<<endl;
    //intialize_edges(G);
    //cout<<"step 4 done"<<endl;
    //index1=floor(Graph.rows/2);
    //index2=floor(Graph.colums/2);
    best_map=new unsigned short [Gr.nodes];
    mapping=new unsigned short [Gr.nodes];
    for(index1=0;index1<Gr.rows;index1++)
    {
    	//index2=floor(Graph.colums/2);
    	for(index2=0;index2<Gr.colums;index2++)
    	{       cout<<"hre\n";
    	        //for(int i=0;i<Gr.nodes;i++) mapping[i]=-1;
    		mapping=map_graph(G,index1*Gr.colums+index2);
    		display_mapping(mapping);
    		temp_cost=cost(mapping,G);
    		cout<<"Mapping Cost= "<<temp_cost<<endl;
    		if(temp_cost<best_cost)
    		{
    			best_cost=temp_cost;
    			copy_arrays(mapping,best_map);
    		}
    	}
    		//map_graph(G,index1);
    }
   // display_data(G);
   cout<<"************** Final mapping best of all ****************"<<endl;
   cout<<"communication cost (hops*Bandwidth) = "<<best_cost<<endl;
   display_mapping(mapping);
   return 0;
}

