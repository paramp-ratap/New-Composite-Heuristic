#include "graph.h"
#include "optical.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
extern struct graph_info Gr;
extern struct edge_info *edges;
void read_powerloss(double **powerloss, int graph_number)
{
   int i,j;
   FILE *ptr;
   char *arg;
    char *file_name;
    arg=new char [5];
    file_name=new char [150];
    
    sprintf(arg,"%d",graph_number);
    strcpy(file_name,"opticalData/powerloss/cruxrouter/appGraph");
    strcat(file_name,arg);
    strcat(file_name,"_loss.txt");
    printf("%s\n",file_name);
    //fp.open(file_name,ios::in);
    ptr = fopen( file_name,"r");
	if(ptr == NULL)
	{
	   printf("file can't be opened \n");
	  // return 1;
	        
	}
    for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {    
               fscanf(ptr,"%lf\t",&powerloss[i][j]);

           }	
    }
    /*for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {    
               printf("%lf",powerloss[i][j]);
           }	
           printf("\n");
    }*/

    fclose(ptr);
   // printf("sucharita");
}
double evaluatePowerLoss(unsigned short *mapping, double **powerlossmatrix)
{
    double loss_wc = 0;//-9999;//0;
    unsigned short *inv_map = new unsigned short [Gr.nodes];
    for(int i = 0;i<Gr.nodes;i++)
    {
      inv_map[mapping[i]] = i;
    }   
    for(int i = 0;i<Gr.edges;i++)
    {
      int task_i = edges[i].destination ;
      int task_j= edges[i].source ;
      
      int mapp_core_task_i = inv_map[task_i];
      int mapp_core_task_j = inv_map[task_j];
        //printf("sucharita samanta\n");
        //printf("%d\n", mapp_core_task_j);
       // printf("%d\n", mapp_core_task_i);
        /*for(int i = 0; i<Gr.rows*Gr.colums; i++)
         {
            for(int j = 0;j<Gr.rows*Gr.colums; j++)
             {    
               printf("%lf",powerlossmatrix[i][j]);
             }	
           printf("\n");
          }*/

      double loss = powerlossmatrix[mapp_core_task_i][mapp_core_task_j];
            // printf("%lf\n", loss);
                  //problem
     
        if (loss < loss_wc)//(loss < loss_wc)
        {
            loss_wc = loss;
            int sourcetaskwc = mapp_core_task_i ;
            int destinationtaskwc = mapp_core_task_j;             
        }
     }
     return loss_wc;
                
}

void read_validcomm(bool ****validcomm, int graph_number)
{
  int i,j,k,l;
  FILE *ptr;
 
  /*validcomm = (bool****)malloc(ROWS*COLS*sizeof(bool***));
  
   for(int i =0;i<ROWS*COLS ;i++)
    {
      validcomm[i] = (bool***)malloc(ROWS*COLS*sizeof(bool**));
    
      for(int j = 0;j<ROWS*COLS; j++)
        {
          validcomm[i][j] = (bool**)malloc(ROWS*COLS*sizeof(bool*));
        
          for(int k = 0;k<ROWS*COLS; k++)
            {
              validcomm[i][j][k] = (bool*)malloc(ROWS*COLS*sizeof(bool));
            }
        }
    }*/
    char *arg;
    char *file_name;
    arg=new char [5];
    file_name=new char [250];
    
    sprintf(arg,"%d",graph_number);
    strcpy(file_name,"opticalData/crosstalk/cruxrouter/appGraph");
    strcat(file_name,arg);
    strcat(file_name,"_valid.txt");
    printf("%s\n",file_name);
    //fp.open(file_name,ios::in);
    ptr = fopen( file_name,"r");
    if(ptr == NULL)
    {
	      printf("file can't be opened \n");
	      //return 1;
      }

    for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {  
              for(k = 0; k<Gr.rows*Gr.colums; k++)
                {
                for(l= 0;l<Gr.rows*Gr.colums; l++)
                   {
                        fscanf(ptr,"%d\t",&validcomm[i][j][k][l]);
                   }
                }
           }
    }
    fclose(ptr);
    /*for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {    
              for(k = 0; k<Gr.rows*Gr.colums; k++)
              {
                for(l= 0;l<Gr.rows*Gr.colums; l++)
                {
                  printf("%d",validcomm[i][j][k][l]);
                }
                printf("\n");
              }	
           }  
    }*/   
    
}

void read_crosstalk(double ****crosstalk, int graph_number)
{
  int i,j,k,l;
  FILE *ptr;
 
  /*crosstalk = (float****)malloc(ROWS*COLS*sizeof(float***));
  
   for(int i =0;i<ROWS*COLS ;i++)
    {
      crosstalk[i] = (float***)malloc(ROWS*COLS*sizeof(float**));
    
      for(int j = 0;j<ROWS*COLS; j++)
        {
           crosstalk[i][j] = (float**)malloc(ROWS*COLS*sizeof(float*));
        
          for(int k = 0;k<ROWS*COLS; k++)
            {
              crosstalk[i][j][k] = (float*)malloc(ROWS*COLS*sizeof(float));
            }
        }
    }*/

    char *arg;
    char *file_name;
    arg=new char [5];
    file_name=new char [250];
    
    sprintf(arg,"%d",graph_number);
    strcpy(file_name,"opticalData/crosstalk/cruxrouter/appGraph");
    strcat(file_name,arg);
    strcat(file_name,"_crosstalk.txt");
    printf("%s\n",file_name);
    //fp.open(file_name,ios::in);
    ptr = fopen( file_name,"r");
    if(ptr == NULL)
    {
	      printf("file can't be opened \n");
	      //return 1;
      }
	  

    for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {  
              for(k = 0; k<Gr.rows*Gr.colums; k++)
                {
                for(l= 0;l<Gr.rows*Gr.colums; l++)
                   {
                        fscanf(ptr,"%lf\t",&crosstalk[i][j][k][l]);
                   }
                }
           }
    }
    fclose(ptr);
    /*for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {    
              for(k = 0; k<Gr.rows*Gr.colums; k++)
              {
                for(l= 0;l<Gr.rows*Gr.colums; l++)
                {
                  printf("%lf",crosstalk[i][j][k][l]);
                }
                printf("\n");
              }	
           }  
    }  */
    
}
    


void evaluateSNR(unsigned short *mapping, short *mapped_edges, double **powerlossmatrix, bool ****validcomm, double ****crosstalk, double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk/*, struct crosstalkEdge*/)
{  
     
    double snrWC = 9999;
    
    /**SNR = -1.2; 
    *srcTask = 1; 
    *dstTask = 2; 
    *Ploss =  -2.1;
    *Crosstalk = 2.5;    
    return;  
    */
    unsigned short *inv_map = new unsigned short[Gr.rows*Gr.colums];
    
    //crosstalkEdge *Tasklist = new struct crosstalkEdge [Gr.nodes];
    crosstalkEdge *Tasklist = new struct crosstalkEdge [Gr.edges];
    double crosstalkVar, powerloss=0;
    
    for(int i = 0;i<Gr.rows*Gr.colums;i++)
         inv_map[i] = -1;
    
    for(int i = 0;i<(Gr.rows*Gr.colums);i++)
    {//printf("%d \n",mapping[i]);
        if(mapping[i] != (unsigned short) (-1)){
        	inv_map[mapping[i]] = i;
        	//printf("(task, core) (%d-->%d) ",mapping[i], i);
        }       
    }
    //printf("\nNew\n");
    for(int i = 0; i<Gr.edges; i++)
    {
        if (mapped_edges[i] == 1)
        {
		int ref_task_src = edges[i].source;
		int ref_task_dst = edges[i].destination;
		
		/*if( i == 0){
			*srcTask = ref_task_src; 
			*dstTask = ref_task_dst; 
		}*/
		       
		//printf("SNR SRCEdges= %d DSTNEdges= %d\n", edges[i].source,edges[i].destination);
                
		//initialization of noise list
		for(int j=0; j<Gr.edges; j++){
		//for(int j=0; j<Gr.nodes; j++){
			Tasklist[j].src_noise_task = -1;
			Tasklist[j].dst_noise_task = -1;
			Tasklist[j].crosstalk = -1;
		}
		int task_noise_count = -1;
		int src_tile, dst_tile;
		if (inv_map[ref_task_src] != (unsigned short) (-1) && inv_map[ref_task_dst] != (unsigned short) (-1) ){
			src_tile = inv_map[ref_task_src];
			dst_tile = inv_map[ref_task_dst];
		}
		else continue;
		
		//printf("\ntask (%d, %d) \n", ref_task_src, ref_task_dst);
		//printf("tile (%d, %d) \n", src_tile, dst_tile);
		powerloss = powerlossmatrix[src_tile][dst_tile];
		//printf("powerloss= %f\n",powerloss);       
		//seach for edges creates noise
		for(int j = 0; j<Gr.edges; j++){
			if (i != j && mapped_edges[j] == 1){ //diffrent edges
			//printf("diffedges\n");
				 int noise_task_src = edges[j].source;
				 int noise_task_dst = edges[j].destination;
				 int noise_src_tile, noise_dst_tile;
				 if (inv_map[noise_task_src] != (unsigned short) (-1) && inv_map[noise_task_dst] != (unsigned short) (-1) ){
					 noise_src_tile = inv_map[noise_task_src];
				         noise_dst_tile = inv_map[noise_task_dst];
				         //printf("(%d,%d) (%d,%d) \n", src_tile, dst_tile, noise_src_tile, noise_dst_tile);
				         //printf("valComm = %d\n",validcomm[src_tile][dst_tile][noise_src_tile][noise_dst_tile]);
				 }
				 else continue;
		                 
		                 //if (validcomm[src_tile][dst_tile][noise_src_tile][noise_dst_tile] == 1)
		                 if (validcomm[src_tile][dst_tile][noise_src_tile][noise_dst_tile] == 1 && src_tile != noise_src_tile && dst_tile != noise_dst_tile)
		                 {
					
		                      crosstalkVar = crosstalk[src_tile][dst_tile][noise_src_tile][noise_dst_tile];
				     // printf("ref_task_src=%d ref_task_dst=%d noise_task_src= %d noise_task_dst = %d crosstalkVar = %f \n",ref_task_src,ref_task_dst,noise_task_src,noise_task_dst,crosstalkVar);
		                      if(crosstalkVar == -1)
		                      {
		                                    printf("error in NoC Architecture");
		                      }
		                      if(crosstalkVar != 0)
		                      { 
		                                  task_noise_count++;
		                                  Tasklist[task_noise_count].src_noise_task = noise_task_src;
						  Tasklist[task_noise_count].dst_noise_task = noise_task_dst;
						  Tasklist[task_noise_count].crosstalk = crosstalkVar;
						 // printf("noise_task_src= %d noise_task_dst = %d crosstalkVar = %f \n", noise_task_src,noise_task_dst,crosstalkVar);
						                                           
		                      }
		                }
			}        	
		}//1st end for
		
		//search the crosstalk among the already identified edges
		crosstalkVar = 0;
		//printf("task_count = %d \n",task_noise_count);
		if(task_noise_count > -1)
		{
		     sort_Tasklist(Tasklist, task_noise_count+1 );
		     crosstalkVar = Tasklist[0].crosstalk;
		             
		     for (int task_i=1; task_i < task_noise_count+1; task_i++)
		     {
		           if (Tasklist[task_i].src_noise_task != -1 && Tasklist[task_i].dst_noise_task != -1)
		           {                            
				int src_tile_i = inv_map[Tasklist[task_i].src_noise_task];
				int dst_tile_i = inv_map[Tasklist[task_i].dst_noise_task];

				bool remove = false;
				            
				for(int task_j = 0; task_j<task_i; task_j++ )
				{
				     if (Tasklist[task_j].src_noise_task != -1 && Tasklist[task_j].dst_noise_task != -1)
				     {
					int src_tile_j = inv_map[Tasklist[task_j].src_noise_task];
					int dst_tile_j = inv_map[Tasklist[task_j].dst_noise_task];
						        
					if (validcomm[src_tile_i][dst_tile_i][src_tile_j][dst_tile_j] == 0)
					{
					   remove = true;
					}
					if (remove)
					{
					   //Remove task_i
					   Tasklist[task_i].src_noise_task = -1;
				           Tasklist[task_i].dst_noise_task = -1;
					   Tasklist[task_i].crosstalk = -1;
					   //task_i --;//?? we are not deleting the task but we are assigning the '-1'
					}
					else
					{
					   crosstalkVar = sumDB(crosstalkVar, Tasklist[task_i].crosstalk);
					}
				      }
				}
			     }
		       }
		  }
		  
		  if (crosstalkVar == 0){ //No Change
		  delete inv_map;
	  	  delete Tasklist;
		     return;
		  }
		  double snr = calcSNR(powerloss, crosstalkVar);
		  //printf("Powerloss = %f crosstalkVar = %f SNR=%f\n", powerloss, crosstalkVar, snr);
		  //printf("i=%d no edges = %d snrWC = %f SNR = %f\n", i, Gr.edges, snrWC, snr);
	    	  if (snrWC > snr)
		  {
		       snrWC = snr;
		       *SNR = snr; 
		       
		       *srcTask = ref_task_src; 
		       *dstTask = ref_task_dst; 
		       *Ploss =  powerloss;
		       *Crosstalk = crosstalkVar;
		       //printf("ref_task_src= %d, ref_task_dst= %d\n", ref_task_src, ref_task_dst);
		      
		       
		       /*int k=0;
		       for (int i=0; i<task_noise_count+1; i++){
		       	if (Tasklist[i].src_noise_task != -1 && Tasklist[i].dst_noise_task != -1 && Tasklist[i].crosstalk != -1){
		       	  CTtask[k].src_noise_task = Tasklist[i].src_noise_task;
		       	  CTtask[k].dst_noise_task = Tasklist[i].dst_noise_task;
		       	  CTtask[k].crosstalk = Tasklist[i].crosstalk;
		       	  k++;
		       	}
		       }*/
		       
		  }
		}
	  } //2nd end of for  
	  //printf("parallel comm... %f \n", snrWC);
	  delete inv_map;
	  delete Tasklist;
	   
}



void sort_Tasklist(crosstalkEdge *Tasklist, int n)
{
    int i, j;
    crosstalkEdge temp;
    for(i = 0;i<n-1; i++)
    {                    
        for(j=0;j<n-i-1;j++){
        	if (Tasklist[j].crosstalk < Tasklist[j+1].crosstalk)
            	{
		        temp = Tasklist[j];
		        Tasklist[j] = Tasklist[j+1];
		        Tasklist[j+1] = temp;
            	}
        }        
                            
    }
    
}

double calcSNR(double signal_attenuation, double noise_attenuation)
{
    if (noise_attenuation==0)
    {
        return 9999;
    }
    return (signal_attenuation-noise_attenuation);
}

double sumDB (double a, double b)
{
    return valToDb(dbToVal(a) + dbToVal(b));
}

double dbToVal(double db)
{
    return pow(10, (db*0.1));
}

double valToDb(double val)
{
    return 10*log10(val);
}






/*double evaluateSNRforEdge(unsigned short *mapping, unsigned short mapedCore, unsigned short unMapedCore, double **powerlossmatrix, bool ****validcomm, double ****crosstalk, double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk, struct crosstalkEdge *CTtask)
{  
     
    double snrWC = 9999;
    unsigned short *inv_map = new unsigned short[Gr.nodes];
    
    crosstalkEdge *Tasklist = new struct crosstalkEdge [Gr.nodes];
    
    for(int i = 0;i<Gr.rows*Gr.colums;i++)
    {
        if (mapping[i] == -1)
          inv_map[mapping[i]] = -1;
        else
          inv_map[mapping[i]] = i;
    } 
        
        //initialization of noise list
        for(int j=0; j<Gr.nodes; j++){
        	Tasklist[j].src_noise_task = -1;
        	Tasklist[j].dst_noise_task = -1;
        	Tasklist[j].crosstalk = -1;
        }
        int task_noise_count = -1;
        
        int src_tile = mapedCore;
        int dst_tile = unMapedCore;
        double powerloss = powerlossmatrix[src_tile][dst_tile];       
        //seach for edges creates noise
       
        for(int j = 0; j<Gr.rows*Gr.cols; j++)
        {
          if(mapping[j] != -1 && j != mapedCore)
          {
		int noise_src_core = j;
    		int noise_src_task = inv_map[j];
    		//get neighbours tasks of noise_src_task
    		short int *neighTasks = new short int[Gr.nodes]; 
    		for(int i=0; i < Gr.nodes; i++){
    			neighTasks[i] = 0;
    		}
                for(int i = noise_src_task; i < Gr.nodes; i++){
                	neighTasks[i] = G[i][noise_src_task];
                }
                for(int i=0; i<Gr.nodes; i++)
                {
                	if (neighTasks[i] != 0 && inv_map[ neighTasks[i] ] != -1){
                		int noise_dst_core = inv_map[ neighTasks[i] ];
                		 if (validcomm[src_tile][dst_tile][noise_src_core][noise_dst_core] == 1)
		                 {
		                      double crosstalkVar = crosstalk[src_tile][dst_tile][noise_src_tile][noise_dst_tile];

		                      if(crosstalkVar == -1)
		                      {
		                                    printf("error in NoC Architecture");
		                      }
		                      if(crosstalkVar != 0)
		                      { 
		                                  task_noise_count++;
		                                  Tasklist[task_noise_count].src_noise_task = noise_task_src;
						  Tasklist[task_noise_count].dst_noise_task = noise_task_dst;
						  Tasklist[task_noise_count].crosstalk = crosstalkVar;
		                      }
		                  }
                	}
                
                }
        //search the crosstalk among the already identified edges
        double crosstalkVar = 0;
        if(task_noise_count > -1)
        {
             sort_Tasklist(Tasklist, task_noise_count+1 );
             crosstalkVar = Tasklist[0].crosstalk;
                     
             for (int task_i=1; task_i < task_noise_count+1; task_i++)
             {
                   if (Tasklist[task_i].src_noise_task != -1 && Tasklist[task_i].dst_noise_task != -1)
                   {                            
		        int src_tile_i = inv_map[Tasklist[task_i].src_noise_task];
		        int dst_tile_i = inv_map[Tasklist[task_i].dst_noise_task];

		        bool remove = false;
		                    
		        for(int task_j = 0; task_j<task_i; task_j++ )
		        {
		             if (Tasklist[task_j].src_noise_task != -1 && Tasklist[task_j].dst_noise_task != -1)
		             {
			        int src_tile_j = inv_map[Tasklist[task_j].src_noise_task];
			        int dst_tile_j = inv_map[Tasklist[task_j].dst_noise_task];
				                
			        if (validcomm[src_tile_i][dst_tile_i][src_tile_j][dst_tile_j] == 0)
			        {
			           remove = true;
			        }
			        if (remove)
			        {
			           //Remove task_i
			           Tasklist[task_i].src_noise_task = -1;
        		           Tasklist[task_i].dst_noise_task = -1;
        			   Tasklist[task_i].crosstalk = -1;
				   //task_i --;//?? we are not deleting the task but we are assigning the '-1'
			        }
			        else
			        {
			           crosstalkVar = sumDB(crosstalkVar, Tasklist[task_i].crosstalk);
			        }
		              }
		        }
		     }
               }
          }
          double snr = calcSNR(powerloss, crosstalkVar);
    	  if (snrWC > snr)
	  {
	       snrWC = snr;
	       *SNR = snr; 
	       *srcTask = ref_task_src; 
	       *dstTask = ref_task_dst; 
	       *Ploss =  powerloss;
	       *Crosstalk = crosstalkVar;
	       int k=0;
	       for (int i=0; i<task_noise_count+1; i++){
	       	if (Tasklist[i].src_noise_task != -1 && Tasklist[i].dst_noise_task != -1 && Tasklist[i].crosstalk != -1){
	       	  CTtask[k].src_noise_task = Tasklist[i].src_noise_task;
	       	  CTtask[k].dst_noise_task = Tasklist[i].dst_noise_task;
	       	  CTtask[k].crosstalk = Tasklist[i].crosstalk;
	       	  k++;
	       	}
	       }
	       
	  }       
        
  return snr;
}
*/


