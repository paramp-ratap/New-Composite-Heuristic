#ifndef optical_h
#define optical_h

#include <stdint.h>

struct crosstalkEdge{
        int src_noise_task, dst_noise_task;
        double crosstalk;
};

#define MEMO_CAPACITY 65536
#define MEMO_MASK     (MEMO_CAPACITY - 1)

struct MemoEntry {
    uint64_t hash;
    double snr;
    int srcTask, dstTask;
    double ploss, crosstalk_val;
    int valid;
};

struct SNRMemoCache {
    MemoEntry *table;
    uint64_t **zobrist_task_tile;
    int max_tasks;
    int max_tiles;
};

/* §5.1: sparse noise neighbourhood for a tile pair (s,d).
 * For each ordered tile pair we keep the list of (s',d',X) such that
 * validcomm[s][d][s'][d'] == 1 and crosstalk[s][d][s'][d'] is nonzero
 * and not the sentinel -1. Self-pairs, identity pairs, degenerate pairs,
 * and shared-endpoint pairs are pruned during construction. */
struct NoiseEntry {
    short s_prime;
    short d_prime;
    double crosstalk;
};

struct NoisePairList {
    NoiseEntry *entries;
    int count;
    int capacity;
};

struct NoiseAdjList {
    NoisePairList *L;   /* size N*N, indexed by s*N + d */
    int N;
};

void buildNoiseAdjList(NoiseAdjList *nal, bool ****validcomm, double ****crosstalk, int N);
void freeNoiseAdjList(NoiseAdjList *nal);

/* §5: per-call scratch + reverse tile-pair lookup so evaluateSNR_cached
 * does not malloc inside the hot loop. The "cache" name matches the call
 * sites already in predictiveOptical.cpp; the cross-call reuse is handled
 * by SNRMemoCache (Zobrist), this struct is the O(k) walk substrate. */
struct SNRCache {
    int N;                 /* tile count = rows*cols */
    int num_edges;         /* Gr.edges */
    int *tilePairToEdge;   /* size N*N, value = mapped-edge id or -1   */
    crosstalkEdge *Tasklist;  /* scratch, size num_edges               */
    unsigned short *inv_map;  /* scratch, size N                       */
};

void initSNRCache(SNRCache *cache, int num_edges, int N);
void freeSNRCache(SNRCache *cache);

/* Incremental-flavoured evaluator: identical worst-case-SNR result as
 * evaluateSNR(), but the inner "find noise contributors" loop iterates
 * the sparse nal->L[s*N+d] (size k) instead of scanning all m mapped
 * edges. Expected cost O(m * (k log k)) vs baseline O(m^2). */
void evaluateSNR_cached(SNRCache *cache,
                        unsigned short *mapping, short *mapped_edges,
                        double **powerlossmatrix,
                        NoiseAdjList *nal, bool ****validcomm,
                        double *SNR, int *srcTask, int *dstTask,
                        double *Ploss, double *Crosstalk);

void initSNRMemoCache(SNRMemoCache *mc, int max_tasks, int max_tiles);
void freeSNRMemoCache(SNRMemoCache *mc);
int memoLookup(SNRMemoCache *mc, uint64_t hash, double *snr, int *srcTask, int *dstTask,
               double *ploss, double *xt);
void memoStore(SNRMemoCache *mc, uint64_t hash, double snr, int srcTask, int dstTask,
               double ploss, double xt);
uint64_t memoComputeHash(SNRMemoCache *mc, unsigned short *mapping, short *mapped_edges,
                         int map_size, int num_edges);

unsigned short* improvement(unsigned short *map, short* mapped_edges, double **powerlossmatrix, double ****crosstalk, bool ****validcomm, NoiseAdjList *nal, SNRCache *cache);
void read_powerloss(double **powerloss, int graph_number);
double evaluatePowerLoss(unsigned short *mapping, double **powerlossmatrix);

void read_validcomm(bool ****validcomm, int graph_no);
void read_crosstalk(double ****crosstalk, int graph_no);
void evaluateSNR(unsigned short *mapping, short *mapped_edges, double **powerlossmatrix, bool ****validcomm, double ****crosstalk, double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk);
void sort_Tasklist(crosstalkEdge *Tasklist, int n);
double calcSNR(double signal_attenuation, double noise_attenuation);
double sumDB (double a,double b);
double dbToVal(double db);
double valToDb(double val);
#endif
