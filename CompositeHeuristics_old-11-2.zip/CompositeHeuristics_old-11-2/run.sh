#run this: sh run.sh

#compilation
g++ -O2 -pthread predictiveOptical.cpp graph.c optical.c -lm

# for dp
g++ -O2 -pthread predictiveOptical.cpp graph.c optical.c -lm -o a_dp.out

#execution
 time ./a.out 40 2

#for dp
 time ./a_dp.out 40 2
 
