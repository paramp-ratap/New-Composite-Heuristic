#ifndef qlearning_h
#define qlearning_h

#define QL_NUM_FEATURES 12
#define QL_MAX_TRAJECTORY 512

struct QLTransition {
    double features[QL_NUM_FEATURES];
};

struct QLearningAgent {
    double weights[QL_NUM_FEATURES];
    double alpha;
    double gamma;
    double epsilon;
    int trained;
    int training;

    QLTransition trajectory[QL_MAX_TRAJECTORY];
    int trajectory_len;

    int total_episodes;
    double best_snr_seen;
};

void qlInit(QLearningAgent *agent, double alpha, double epsilon);

void qlExtractFeatures(double *features,
                       unsigned short *mapping, unsigned short *core_mapping_flag,
                       unsigned short *router_mapping_flag, unsigned short *inv_map,
                       short *mapped_edges, double **powerloss,
                       unsigned short candidate_tile, unsigned short node,
                       unsigned short mapping_count, float **G);

double qlValue(QLearningAgent *agent, double *features);

int qlSelectAction(QLearningAgent *agent, unsigned short *pos, int pos_count,
                   unsigned short *mapping, unsigned short *core_mapping_flag,
                   unsigned short *router_mapping_flag, unsigned short *inv_map,
                   short *mapped_edges, double **powerloss,
                   unsigned short node, unsigned short mapping_count, float **G);

void qlRecordStep(QLearningAgent *agent, double *features);
void qlUpdateEpisode(QLearningAgent *agent, double terminal_snr);
void qlResetTrajectory(QLearningAgent *agent);
int qlSaveWeights(QLearningAgent *agent, const char *path);
int qlLoadWeights(QLearningAgent *agent, const char *path);

#endif
