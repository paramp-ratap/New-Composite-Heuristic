#run this: sh run.sh

#compilation
g++ -O2 -pthread predictiveOptical.cpp graph.c optical.c qlearning.cpp -lm

#execution choices:
# 0 = Communication-aware
# 1 = Powerloss-aware
# 2 = SNR-aware (uses Q-learning weights if qweights_Graph<N>.bin exists)
# 3 = Q-Learning training (saves weights to qweights_Graph<N>.bin)

# Step 1: Train Q-learning (10 passes over all starting tiles)
 time ./a.out 40 3 10

# Step 2: Run SNR-aware with trained Q-learning weights
 time ./a.out 40 2
