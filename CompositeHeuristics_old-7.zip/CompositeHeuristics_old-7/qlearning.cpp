#include "qlearning.h"
#include "graph.h"
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>

extern struct graph_info Gr;
extern struct edge_info *edges;
extern struct virtual_address address;

void qlInit(QLearningAgent *agent, double alpha, double epsilon)
{
    for (int i = 0; i < QL_NUM_FEATURES; i++)
        agent->weights[i] = 0.0;
    agent->alpha = alpha;
    agent->gamma = 1.0;
    agent->epsilon = epsilon;
    agent->trained = 0;
    agent->training = 0;
    agent->trajectory_len = 0;
    agent->total_episodes = 0;
    agent->best_snr_seen = -9999.0;
}

/*
 * Feature vector (all roughly in [0,1] range):
 *  0: bias term (always 1.0)
 *  1: mapping progress (mapped nodes / total nodes)
 *  2: mapped edge fraction (edges with both endpoints mapped / total edges)
 *  3: free tile fraction (unoccupied tiles / total tiles)
 *  4: candidate distance to centroid of mapped tiles (normalized)
 *  5: worst-case powerloss from candidate to any mapped tile (scaled)
 *  6: mean powerloss from candidate to mapped tiles (scaled)
 *  7: neighbor occupancy (fraction of 4-adjacent tiles occupied)
 *  8: mean hop count from candidate to mapped tiles (normalized)
 *  9: node communication weight fraction (node edge weight / total weight)
 * 10: fraction of node's graph neighbors already mapped
 * 11: candidate spatial position (avg of normalized row and col)
 */
void qlExtractFeatures(double *features,
                       unsigned short *mapping, unsigned short *core_mapping_flag,
                       unsigned short *router_mapping_flag, unsigned short *inv_map,
                       short *mapped_edges, double **powerloss,
                       unsigned short candidate_tile, unsigned short node,
                       unsigned short mapping_count, float **G)
{
    int total_tiles = Gr.rows * Gr.colums;

    features[0] = 1.0;

    features[1] = (double)mapping_count / (double)Gr.nodes;

    int me = 0;
    for (int i = 0; i < Gr.edges; i++)
        if (mapped_edges[i] == 1) me++;
    features[2] = (double)me / (double)Gr.edges;

    int occupied = 0;
    for (int i = 0; i < total_tiles; i++)
        if (router_mapping_flag[i] == 1) occupied++;
    features[3] = (double)(total_tiles - occupied) / (double)total_tiles;

    double centroid_row = 0.0, centroid_col = 0.0;
    int mapped_tile_count = 0;
    for (int i = 0; i < total_tiles; i++) {
        if (router_mapping_flag[i] == 1) {
            centroid_row += address.row[i];
            centroid_col += address.colum[i];
            mapped_tile_count++;
        }
    }
    if (mapped_tile_count > 0) {
        centroid_row /= mapped_tile_count;
        centroid_col /= mapped_tile_count;
    }

    double cand_row = address.row[candidate_tile];
    double cand_col = address.colum[candidate_tile];
    double max_dist = (Gr.rows > 1 ? Gr.rows - 1 : 1) + (Gr.colums > 1 ? Gr.colums - 1 : 1);
    features[4] = (fabs(cand_row - centroid_row) + fabs(cand_col - centroid_col)) / max_dist;

    double wc_ploss = 0.0;
    double sum_ploss = 0.0;
    int ploss_count = 0;
    for (int i = 0; i < Gr.nodes; i++) {
        if (core_mapping_flag[i] == 1) {
            int tile = inv_map[i];
            double pl = powerloss[candidate_tile][tile];
            sum_ploss += pl;
            ploss_count++;
            if (pl < wc_ploss) wc_ploss = pl;
        }
    }
    features[5] = wc_ploss / 50.0;
    features[6] = (ploss_count > 0) ? (sum_ploss / ploss_count) / 50.0 : 0.0;

    int adj_count = 0, adj_occupied = 0;
    int cr = address.row[candidate_tile];
    int cc = address.colum[candidate_tile];
    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};
    for (int d = 0; d < 4; d++) {
        int nr = cr + dr[d];
        int nc = cc + dc[d];
        if (nr >= 0 && nr < Gr.rows && nc >= 0 && nc < Gr.colums) {
            adj_count++;
            int adj_tile = nr * Gr.colums + nc;
            if (router_mapping_flag[adj_tile] == 1)
                adj_occupied++;
        }
    }
    features[7] = (adj_count > 0) ? (double)adj_occupied / adj_count : 0.0;

    double hop_sum = 0.0;
    int hop_cnt = 0;
    int max_hop = (Gr.rows > 1 ? Gr.rows - 1 : 1) + (Gr.colums > 1 ? Gr.colums - 1 : 1);
    for (int i = 0; i < Gr.nodes; i++) {
        if (core_mapping_flag[i] == 1) {
            int tile = inv_map[i];
            int hops = abs(address.row[candidate_tile] - address.row[tile]) +
                       abs(address.colum[candidate_tile] - address.colum[tile]);
            hop_sum += hops;
            hop_cnt++;
        }
    }
    features[8] = (hop_cnt > 0) ? (hop_sum / hop_cnt) / max_hop : 0.0;

    double total_weight = 0.0, node_weight = 0.0;
    for (int i = 0; i < Gr.edges; i++) {
        total_weight += edges[i].edge_weight;
        if (edges[i].source == node || edges[i].destination == node)
            node_weight += edges[i].edge_weight;
    }
    features[9] = (total_weight > 0) ? node_weight / total_weight : 0.0;

    int node_neighbors = 0, node_mapped_neighbors = 0;
    for (int i = 0; i < Gr.edges; i++) {
        if (edges[i].source == node) {
            node_neighbors++;
            if (core_mapping_flag[edges[i].destination] == 1)
                node_mapped_neighbors++;
        }
        if (edges[i].destination == node) {
            node_neighbors++;
            if (core_mapping_flag[edges[i].source] == 1)
                node_mapped_neighbors++;
        }
    }
    features[10] = (node_neighbors > 0) ? (double)node_mapped_neighbors / node_neighbors : 0.0;

    features[11] = ((double)cr / (Gr.rows > 1 ? Gr.rows - 1 : 1) +
                    (double)cc / (Gr.colums > 1 ? Gr.colums - 1 : 1)) / 2.0;
}

double qlValue(QLearningAgent *agent, double *features)
{
    double val = 0.0;
    for (int i = 0; i < QL_NUM_FEATURES; i++)
        val += agent->weights[i] * features[i];
    return val;
}

int qlSelectAction(QLearningAgent *agent, unsigned short *pos, int pos_count,
                   unsigned short *mapping, unsigned short *core_mapping_flag,
                   unsigned short *router_mapping_flag, unsigned short *inv_map,
                   short *mapped_edges, double **powerloss,
                   unsigned short node, unsigned short mapping_count, float **G)
{
    if (agent->training && ((double)rand() / RAND_MAX) < agent->epsilon) {
        int chosen = rand() % pos_count;
        double feat[QL_NUM_FEATURES];
        qlExtractFeatures(feat, mapping, core_mapping_flag, router_mapping_flag,
                          inv_map, mapped_edges, powerloss, pos[chosen], node,
                          mapping_count, G);
        if (agent->trajectory_len < QL_MAX_TRAJECTORY) {
            memcpy(agent->trajectory[agent->trajectory_len].features, feat,
                   sizeof(double) * QL_NUM_FEATURES);
            agent->trajectory_len++;
        }
        return chosen;
    }

    double best_q = -1e30;
    int best_idx = 0;
    double best_feat[QL_NUM_FEATURES];

    for (int i = 0; i < pos_count; i++) {
        double feat[QL_NUM_FEATURES];
        qlExtractFeatures(feat, mapping, core_mapping_flag, router_mapping_flag,
                          inv_map, mapped_edges, powerloss, pos[i], node,
                          mapping_count, G);
        double q = qlValue(agent, feat);
        if (q > best_q) {
            best_q = q;
            best_idx = i;
            memcpy(best_feat, feat, sizeof(double) * QL_NUM_FEATURES);
        }
    }

    if (agent->training && agent->trajectory_len < QL_MAX_TRAJECTORY) {
        memcpy(agent->trajectory[agent->trajectory_len].features, best_feat,
               sizeof(double) * QL_NUM_FEATURES);
        agent->trajectory_len++;
    }

    return best_idx;
}

void qlRecordStep(QLearningAgent *agent, double *features)
{
    if (agent->trajectory_len < QL_MAX_TRAJECTORY) {
        memcpy(agent->trajectory[agent->trajectory_len].features, features,
               QL_NUM_FEATURES * sizeof(double));
        agent->trajectory_len++;
    }
}

void qlUpdateEpisode(QLearningAgent *agent, double terminal_snr)
{
    for (int t = 0; t < agent->trajectory_len; t++) {
        double q = qlValue(agent, agent->trajectory[t].features);
        double error = terminal_snr - q;
        for (int f = 0; f < QL_NUM_FEATURES; f++) {
            agent->weights[f] += agent->alpha * error * agent->trajectory[t].features[f];
        }
    }
    agent->total_episodes++;
    if (terminal_snr > agent->best_snr_seen)
        agent->best_snr_seen = terminal_snr;
}

void qlResetTrajectory(QLearningAgent *agent)
{
    agent->trajectory_len = 0;
}

int qlSaveWeights(QLearningAgent *agent, const char *path)
{
    FILE *fp = fopen(path, "wb");
    if (!fp) return 0;
    fwrite(agent->weights, sizeof(double), QL_NUM_FEATURES, fp);
    fwrite(&agent->total_episodes, sizeof(int), 1, fp);
    fwrite(&agent->best_snr_seen, sizeof(double), 1, fp);
    fclose(fp);
    return 1;
}

int qlLoadWeights(QLearningAgent *agent, const char *path)
{
    FILE *fp = fopen(path, "rb");
    if (!fp) return 0;
    size_t r1 = fread(agent->weights, sizeof(double), QL_NUM_FEATURES, fp);
    size_t r2 = fread(&agent->total_episodes, sizeof(int), 1, fp);
    size_t r3 = fread(&agent->best_snr_seen, sizeof(double), 1, fp);
    fclose(fp);
    if (r1 == QL_NUM_FEATURES && r2 == 1 && r3 == 1) {
        agent->trained = 1;
        return 1;
    }
    return 0;
}
