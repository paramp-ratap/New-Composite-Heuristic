#ifndef optical_h
#define optical_h

#include <stdint.h>
#include <stddef.h>

struct crosstalkEdge{
        int src_noise_task, dst_noise_task;
        double crosstalk;
};

struct NoisePair {
    int src_tile, dst_tile;
    double xt;
};

struct NoiseAdjList {
    NoisePair **adj;
    int *adj_count;
    int num_tile_pairs;
    int N;
};

struct EdgeSNRState {
    int edge_idx;
    int src_tile, dst_tile;
    double powerloss;
    double total_crosstalk_dB;
    double snr;
    int noise_count;
    NoisePair *active_noise;
    int active_noise_cap;
};

struct SNRCache {
    EdgeSNRState *edge_states;
    int num_edges;
    int capacity;
    double worst_case_snr;
    int wc_src_task, wc_dst_task;
    double wc_ploss, wc_crosstalk;

    unsigned short *inv_map;
    int inv_map_size;
};

#define MEMO_MIN_CAPACITY 4096
#define MEMO_MAX_CAPACITY 524288
#define MEMO_LOAD_FACTOR  8

struct MemoEntry {
    uint64_t hash;
    double snr;
    int srcTask, dstTask;
    double ploss, crosstalk_val;
    int valid;
};

struct SNRMemoCache {
    MemoEntry *table;
    uint64_t **zobrist_task_tile;
    int max_tasks;
    int max_tiles;
    size_t capacity;
    uint64_t mask;
};

void buildNoiseAdjList(NoiseAdjList *nal, bool ****validcomm, double ****crosstalk, int N);
void freeNoiseAdjList(NoiseAdjList *nal);

void initSNRCache(SNRCache *cache, int max_edges, int inv_map_size);
void freeSNRCache(SNRCache *cache);
void resetSNRCache(SNRCache *cache);
void snrCacheRebuildInvMap(SNRCache *cache, unsigned short *mapping, int map_size);
void snrCacheAddEdge(SNRCache *cache, int edge_idx, int src_tile, int dst_tile,
                     double **powerlossmatrix, NoiseAdjList *nal,
                     unsigned short *mapping, short *mapped_edges);
void snrCacheRecomputeWorstCase(SNRCache *cache);
void snrCacheFullRebuild(SNRCache *cache, unsigned short *mapping, short *mapped_edges,
                         double **powerlossmatrix, NoiseAdjList *nal, bool ****validcomm);

void initSNRMemoCache(SNRMemoCache *mc, int max_tasks, int max_tiles, int num_edges);
void freeSNRMemoCache(SNRMemoCache *mc);
int memoLookup(SNRMemoCache *mc, uint64_t hash, double *snr, int *srcTask, int *dstTask,
               double *ploss, double *xt);
void memoStore(SNRMemoCache *mc, uint64_t hash, double snr, int srcTask, int dstTask,
               double ploss, double xt);
uint64_t memoComputeHash(SNRMemoCache *mc, unsigned short *mapping, short *mapped_edges,
                         int map_size, int num_edges);

unsigned short* improvement(unsigned short *map, short* mapped_edges, double **powerlossmatrix, double ****crosstalk, bool ****validcomm);
void read_powerloss(double **powerloss, int graph_number);
double evaluatePowerLoss(unsigned short *mapping, double **powerlossmatrix);

void read_validcomm(bool ****validcomm, int graph_no);
void read_crosstalk(double ****crosstalk, int graph_no);
void evaluateSNR(unsigned short *mapping, short *mapped_edges, double **powerlossmatrix, bool ****validcomm, double ****crosstalk, double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk);
void evaluateSNR_cached(SNRCache *cache, unsigned short *mapping, short *mapped_edges,
                        double **powerlossmatrix, NoiseAdjList *nal, bool ****validcomm,
                        double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk);
void sort_Tasklist(crosstalkEdge *Tasklist, int n);
double calcSNR(double signal_attenuation, double noise_attenuation);
double sumDB (double a,double b);
double dbToVal(double db);
double valToDb(double val);
#endif



