#ifndef QLEARNING_H
#define QLEARNING_H

#include <stdint.h>

/*
 * Q-Learning module for SNR-aware task-to-tile mapping.
 *
 * Replaces the expensive predict_best_pos_SNR() lookahead with a learned
 * linear Q-value function:  Q(s,a) = w^T * phi(s,a)
 *
 * State  = current partial mapping
 * Action = place next task at a candidate tile
 *
 * Feature vector phi(s,a) captures mapping progress, communication locality,
 * power loss, hop distance, and tile geometry -- all computable in O(N).
 *
 * Time complexity per decision drops from O(pos_count * N^2 * E) to
 * O(pos_count * N).
 */

#define QL_NUM_FEATURES 12   /* 11 features + 1 bias */

#define QL_MAX_EPISODE_STEPS 256

/* One recorded transition in an episode */
struct QLExperience {
    double features[QL_NUM_FEATURES];
};

struct QLearningAgent {
    double weights[QL_NUM_FEATURES];
    double learning_rate;
    double epsilon;          /* epsilon-greedy exploration rate */
    double discount;         /* gamma (1.0 for undiscounted episodic) */

    /* Episode buffer for Monte Carlo updates */
    QLExperience episode[QL_MAX_EPISODE_STEPS];
    int episode_len;

    /* Training statistics */
    int episodes_trained;

    /* Running baseline and variance for Z-score return normalization.
       target = (return - EMA_mean) / max(sqrt(EMA_var), 1.0)
       keeps the gradient signal on a unit scale regardless of the
       graph's raw SNR range, while preserving argmax ordering. */
    double return_baseline;   /* EMA of returns                      */
    double return_var;        /* EMA of squared deviation (variance) */
    int    baseline_initialized;
};

#ifdef __cplusplus
extern "C" {
#endif

/* Lifecycle */
void ql_init(QLearningAgent *agent, double learning_rate, double epsilon);

/* Feature extraction: fills features[0..QL_NUM_FEATURES-1] for placing
   task 'node' at tile 'tile_id' given the current partial mapping state.
   Cost: O(N) where N = Gr.nodes.  */
void ql_extract_features(double *features,
                         unsigned short *mapping,
                         unsigned short *core_mapping_flag,
                         unsigned short *router_mapping_flag,
                         unsigned short *inv_map,
                         unsigned short node,
                         unsigned short tile_id,
                         float **G,
                         double **powerloss,
                         unsigned short mapping_count);

/* Q(s,a) = w^T * phi(s,a) -- dot product, O(QL_NUM_FEATURES) */
double ql_compute_q(QLearningAgent *agent, double *features);

/* Pick best candidate tile from pos[0..pos_count-1].
   If training=1, uses epsilon-greedy; if training=0, pure greedy.
   Returns index into pos[] array.
   Cost: O(pos_count * N).  */
unsigned short ql_select_action(QLearningAgent *agent,
                                unsigned short *mapping,
                                unsigned short *core_mapping_flag,
                                unsigned short *router_mapping_flag,
                                unsigned short *inv_map,
                                unsigned short node,
                                unsigned short *pos,
                                unsigned short pos_count,
                                float **G,
                                double **powerloss,
                                unsigned short mapping_count,
                                int training);

/* Record the features of the chosen action for this step */
void ql_record_step(QLearningAgent *agent, double *features);

/* After episode ends: Monte Carlo update using final_snr as return.
   Updates weights via semi-gradient descent. */
void ql_update_episode(QLearningAgent *agent, double final_snr);

/* Reset episode buffer for a new episode */
void ql_reset_episode(QLearningAgent *agent);

/* Persistence */
int  ql_save_weights(QLearningAgent *agent, const char *filename);
int  ql_load_weights(QLearningAgent *agent, const char *filename);

/* Pretty-print the weight vector with feature names to stdout */
void ql_print_weights(QLearningAgent *agent, const char *label);

#ifdef __cplusplus
}
#endif

#endif /* QLEARNING_H */
