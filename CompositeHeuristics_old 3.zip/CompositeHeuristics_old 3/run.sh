#run this: sh run.sh

#compilation (now includes qlearning.cpp)
g++ -O2 -pthread predictiveOptical.cpp graph.c optical.c qlearning.cpp -lm

#execution - original SNR-aware (choice 2)
 time ./a.out 40 2

#execution - Q-learning TRAINING (choice 3)
# Trains Q-weights and saves to results/qweights_Graph40.txt
# Optional 3rd arg = number of training episodes (default: total_tiles * 5)
 time ./a.out 40 3 500

#execution - Q-learning INFERENCE (choice 4) -- FAST
# Uses learned Q-weights instead of expensive prediction lookahead
# Optional 3rd arg = number of threads
 time ./a.out 40 4

#execution - Q-learning MULTI-GRAPH TRAINING (choice 5)
# Trains a single Q-weight vector across several graphs.
# argv[1] can be any valid graph id (used only for the pre-alloc slot).
# argv[3] = comma-separated training graph IDs
# argv[4] = episodes per graph (default 100)
# Saves to ./results/qweights_multigraph.txt (override with QL_WEIGHTS_FILE).
 time ./a.out 40 5 "40,42,17" 200

#execution - Q-learning MULTI-GRAPH INFERENCE (choice 6)
# Tests the multi-graph-trained weights on a held-out graph.
# argv[1] = test graph id; optional argv[3] = num threads.
 time ./a.out 50 6

