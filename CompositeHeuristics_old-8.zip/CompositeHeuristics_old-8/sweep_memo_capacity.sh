#!/usr/bin/env bash
# Sweep MEMO cache capacity for the SNR-aware mapping path and emit a CSV
# capturing runtime, hit/collision stats, and final mapping cost.
#
# Usage:
#   ./sweep_memo_capacity.sh <graph_no> [choice=2] [num_threads] [out_csv]
#
# Example:
#   ./sweep_memo_capacity.sh 40 2 8 results/memo_sweep_g40.csv
#
# Edit CAPACITIES below to change the swept range.

set -u

GRAPH_NO="${1:-40}"
CHOICE="${2:-2}"
NUM_THREADS="${3:-}"
OUT_CSV="${4:-results/memo_sweep_g${GRAPH_NO}_c${CHOICE}.csv}"

CAPACITIES=(128 256 512 1024 2048 4096 8192 16384 32768 65536)

BIN=./a.out
if [[ ! -x "$BIN" ]]; then
  echo "Binary $BIN not found. Building..." >&2
  g++ -O2 -pthread predictiveOptical.cpp graph.c optical.c -lm -o a.out || exit 1
fi

mkdir -p "$(dirname "$OUT_CSV")"
mkdir -p sweep_logs

echo "graph,choice,requested_capacity,effective_capacity,wall_seconds,user_seconds,sys_seconds,lookups,hits,hit_rate,stores,collisions,collision_rate,final_snr,bcost_powerloss" > "$OUT_CSV"

for cap in "${CAPACITIES[@]}"; do
  log="sweep_logs/run_g${GRAPH_NO}_c${CHOICE}_cap${cap}.log"
  err="sweep_logs/run_g${GRAPH_NO}_c${CHOICE}_cap${cap}.err"

  # /usr/bin/time -p prints "real / user / sys" on three lines to stderr.
  if [[ -n "$NUM_THREADS" ]]; then
    SNR_MEMO_CAPACITY="$cap" /usr/bin/time -p "$BIN" "$GRAPH_NO" "$CHOICE" "$NUM_THREADS" >"$log" 2>"$err"
  else
    SNR_MEMO_CAPACITY="$cap" /usr/bin/time -p "$BIN" "$GRAPH_NO" "$CHOICE" >"$log" 2>"$err"
  fi
  rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "[WARN] capacity=$cap exited rc=$rc — see $err" >&2
  fi

  real=$(awk '/^real /{print $2}' "$err" | tail -1)
  user=$(awk '/^user /{print $2}' "$err" | tail -1)
  sys=$(awk  '/^sys /{print $2}' "$err"  | tail -1)

  # Aggregated MEMO_STATS line printed by main() at the end of the run.
  stats=$(grep '^\[MEMO_STATS\]' "$err" | tail -1)
  eff_cap=$(echo "$stats" | sed -n 's/.*capacity=\([0-9]*\).*/\1/p')
  lookups=$(echo "$stats" | sed -n 's/.*lookups=\([0-9]*\).*/\1/p')
  hits=$(echo    "$stats" | sed -n 's/.*hits=\([0-9]*\).*/\1/p')
  hit_rate=$(echo "$stats" | sed -n 's/.*hit_rate=\([0-9.]*\).*/\1/p')
  stores=$(echo  "$stats" | sed -n 's/.*stores=\([0-9]*\).*/\1/p')
  collisions=$(echo "$stats" | sed -n 's/.*collisions=\([0-9]*\).*/\1/p')
  coll_rate=$(echo  "$stats" | sed -n 's/.*collision_rate=\([0-9.]*\).*/\1/p')

  # Final SNR is the last "Mapping Cost (SNR)=" emitted by main (after the
  # "Final mapping" banner). Powerloss is printed once at the end too.
  final_snr=$(grep 'Mapping Cost (SNR)=' "$log" | tail -1 | sed 's/.*= *//')
  ploss=$(grep    'Powerloss= '          "$log" | tail -1 | sed 's/.*= *//')

  echo "${GRAPH_NO},${CHOICE},${cap},${eff_cap:-},${real:-},${user:-},${sys:-},${lookups:-},${hits:-},${hit_rate:-},${stores:-},${collisions:-},${coll_rate:-},${final_snr:-},${ploss:-}" >> "$OUT_CSV"
  echo "[OK] cap=$cap real=${real:-?}s hit_rate=${hit_rate:-?} coll_rate=${coll_rate:-?} snr=${final_snr:-?}"
done

echo
echo "Done. CSV: $OUT_CSV"
echo "Per-run logs: sweep_logs/"
