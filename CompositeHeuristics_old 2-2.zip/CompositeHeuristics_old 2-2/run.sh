#run this: sh run.sh

#compilation (now includes qlearning.cpp)
g++ -O2 -pthread predictiveOptical.cpp graph.c optical.c qlearning.cpp -lm

#execution - original SNR-aware (choice 2)
 time ./a.out 40 2

#execution - Q-learning TRAINING (choice 3)
# Trains Q-weights and saves to results/qweights_Graph40.txt
# Optional 3rd arg = number of training episodes (default: total_tiles * 5)
 time ./a.out 40 3 500

#execution - Q-learning INFERENCE (choice 4) -- FAST
# Uses learned Q-weights instead of expensive prediction lookahead
# Optional 3rd arg = number of threads
 time ./a.out 40 4

#execution - Q-learning MULTI-GRAPH TRAIN (choice 5)
# Trains shared Q-weights across a comma-separated list of graphs.
# Weights saved to results/qweights_shared.txt (resumes if present).
# Optional 3rd arg = episodes per graph (default: total_tiles * 5)
# time ./a.out "40,41,42" 5 200

#execution - Q-learning MULTI-GRAPH TEST (choice 6)
# Loads results/qweights_shared.txt and reports best SNR per test graph.
# Per-graph results appended to results/test_results_shared.txt
# time ./a.out "50,51,52" 6

