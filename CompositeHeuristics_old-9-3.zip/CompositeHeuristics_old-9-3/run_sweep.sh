#!/bin/sh
# Sweep MEMO_CAPACITY over a range of values and record HIT / MISS / CPU time.
# Usage: sh run_sweep.sh [graph_no] [choice]
# Defaults match run.sh:  ./a.out 40 2

set -e

cd "$(dirname "$0")"

ARG1="${1:-200}"
ARG2="${2:-2}"

OUT="memo_sweep_results.txt"
BIN="./a_sweep.out"

CAPACITIES="1024 2048 3072 4096 5120 6144 7168 8192 9216 10240 11264 12288 13312 14336 15360 16384 17408"

# Tab-separated header. Columns:
#   rows   : MEMO_CAPACITY (number of slots in memo table)
#   log10  : log10(rows)
#   HIT    : memo lookup hits
#   MISS   : memo lookup misses (forced full SNR evaluation)
#   CPU_MS : (user + sys) CPU time in milliseconds, from getrusage
printf "rows\tlog10\tHIT\tMISS\tCPU_MS\n" > "$OUT"

for CAP in $CAPACITIES; do
    echo ">>> Building with MEMO_CAPACITY=$CAP"
    # Force optical.h to recompile by passing capacity as a macro override.
    g++ -O2 -DMEMO_CAPACITY="$CAP" \
        predictiveOptical.cpp graph.c optical.c -lm -o "$BIN"

    echo ">>> Running with MEMO_CAPACITY=$CAP"
    LOG="run_${CAP}.log"
    "$BIN" "$ARG1" "$ARG2" > "$LOG" 2>&1 || {
        echo "Run failed for CAP=$CAP, see $LOG" >&2
        exit 1
    }

    HIT=$(grep '^HIT='    "$LOG" | tail -1 | cut -d= -f2)
    MISS=$(grep '^MISS='  "$LOG" | tail -1 | cut -d= -f2)
    CPUMS=$(grep '^CPU_MS=' "$LOG" | tail -1 | cut -d= -f2)
    LOG10=$(awk -v r="$CAP" 'BEGIN { printf "%.6f", log(r)/log(10) }')

    if [ -z "$HIT" ] || [ -z "$MISS" ] || [ -z "$CPUMS" ]; then
        echo "Could not parse HIT/MISS/CPU_MS from $LOG" >&2
        exit 1
    fi

    printf "%s\t%s\t%s\t%s\t%s\n" "$CAP" "$LOG10" "$HIT" "$MISS" "$CPUMS" >> "$OUT"
    echo "    rows=$CAP log10=$LOG10 HIT=$HIT MISS=$MISS CPU_MS=$CPUMS"
done

echo
echo "Done. Results written to $OUT"
column -t -s "$(printf '\t')" "$OUT" || cat "$OUT"
