#include "graph.h"
#include "optical.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
extern struct graph_info Gr;
extern struct edge_info *edges;
void read_powerloss(double **powerloss, int graph_number)
{
   int i,j;
   FILE *ptr;
   char *arg;
    char *file_name;
    arg=new char [5];
    file_name=new char [150];
    
    sprintf(arg,"%d",graph_number);
    strcpy(file_name,"opticalData/powerloss/cruxrouter/appGraph");
    strcat(file_name,arg);
    strcat(file_name,"_loss.txt");
    printf("%s\n",file_name);
    ptr = fopen( file_name,"r");
	if(ptr == NULL)
	{
	   printf("file can't be opened \n");
	   return;
	}
    for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {    
               fscanf(ptr,"%lf\t",&powerloss[i][j]);

           }	
    }
    /*for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {    
               printf("%lf",powerloss[i][j]);
           }	
           printf("\n");
    }*/

    fclose(ptr);
   // printf("sucharita");
}
double evaluatePowerLoss(unsigned short *mapping, double **powerlossmatrix)
{
    double loss_wc = 0;//-9999;//0;
    unsigned short *inv_map = new unsigned short [Gr.nodes];
    for(int i = 0;i<Gr.nodes;i++)
    {
      inv_map[mapping[i]] = i;
    }   
    for(int i = 0;i<Gr.edges;i++)
    {
      int task_i = edges[i].destination ;
      int task_j= edges[i].source ;
      
      int mapp_core_task_i = inv_map[task_i];
      int mapp_core_task_j = inv_map[task_j];
        //printf("sucharita samanta\n");
        //printf("%d\n", mapp_core_task_j);
       // printf("%d\n", mapp_core_task_i);
        /*for(int i = 0; i<Gr.rows*Gr.colums; i++)
         {
            for(int j = 0;j<Gr.rows*Gr.colums; j++)
             {    
               printf("%lf",powerlossmatrix[i][j]);
             }	
           printf("\n");
          }*/

      double loss = powerlossmatrix[mapp_core_task_i][mapp_core_task_j];
            // printf("%lf\n", loss);
                  //problem
     
        if (loss < loss_wc)//(loss < loss_wc)
        {
            loss_wc = loss;
            int sourcetaskwc = mapp_core_task_i ;
            int destinationtaskwc = mapp_core_task_j;             
        }
     }
     return loss_wc;
                
}

void read_validcomm(bool ****validcomm, int graph_number)
{
  int i,j,k,l;
  FILE *ptr;
 
  /*validcomm = (bool****)malloc(ROWS*COLS*sizeof(bool***));
  
   for(int i =0;i<ROWS*COLS ;i++)
    {
      validcomm[i] = (bool***)malloc(ROWS*COLS*sizeof(bool**));
    
      for(int j = 0;j<ROWS*COLS; j++)
        {
          validcomm[i][j] = (bool**)malloc(ROWS*COLS*sizeof(bool*));
        
          for(int k = 0;k<ROWS*COLS; k++)
            {
              validcomm[i][j][k] = (bool*)malloc(ROWS*COLS*sizeof(bool));
            }
        }
    }*/
    char *arg;
    char *file_name;
    arg=new char [5];
    file_name=new char [250];
    
    sprintf(arg,"%d",graph_number);
    strcpy(file_name,"opticalData/crosstalk/cruxrouter/appGraph");
    strcat(file_name,arg);
    strcat(file_name,"_valid.txt");
    printf("%s\n",file_name);
    ptr = fopen( file_name,"r");
    if(ptr == NULL)
    {
	      printf("file can't be opened \n");
	      return;
      }

    for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {  
              for(k = 0; k<Gr.rows*Gr.colums; k++)
                {
                for(l= 0;l<Gr.rows*Gr.colums; l++)
                   {
                        int tmp_val;
                        fscanf(ptr,"%d\t",&tmp_val);
                        validcomm[i][j][k][l] = (bool)tmp_val;
                   }
                }
           }
    }
    fclose(ptr);
    /*for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {    
              for(k = 0; k<Gr.rows*Gr.colums; k++)
              {
                for(l= 0;l<Gr.rows*Gr.colums; l++)
                {
                  printf("%d",validcomm[i][j][k][l]);
                }
                printf("\n");
              }	
           }  
    }*/   
    
}

void read_crosstalk(double ****crosstalk, int graph_number)
{
  int i,j,k,l;
  FILE *ptr;
 
  /*crosstalk = (float****)malloc(ROWS*COLS*sizeof(float***));
  
   for(int i =0;i<ROWS*COLS ;i++)
    {
      crosstalk[i] = (float***)malloc(ROWS*COLS*sizeof(float**));
    
      for(int j = 0;j<ROWS*COLS; j++)
        {
           crosstalk[i][j] = (float**)malloc(ROWS*COLS*sizeof(float*));
        
          for(int k = 0;k<ROWS*COLS; k++)
            {
              crosstalk[i][j][k] = (float*)malloc(ROWS*COLS*sizeof(float));
            }
        }
    }*/

    char *arg;
    char *file_name;
    arg=new char [5];
    file_name=new char [250];
    
    sprintf(arg,"%d",graph_number);
    strcpy(file_name,"opticalData/crosstalk/cruxrouter/appGraph");
    strcat(file_name,arg);
    strcat(file_name,"_crosstalk.txt");
    printf("%s\n",file_name);
    ptr = fopen( file_name,"r");
    if(ptr == NULL)
    {
	      printf("file can't be opened \n");
	      return;
      }

    for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {  
              for(k = 0; k<Gr.rows*Gr.colums; k++)
                {
                for(l= 0;l<Gr.rows*Gr.colums; l++)
                   {
                        fscanf(ptr,"%lf\t",&crosstalk[i][j][k][l]);
                   }
                }
           }
    }
    fclose(ptr);
    /*for(i = 0; i<Gr.rows*Gr.colums; i++)
    {
        for(j = 0;j<Gr.rows*Gr.colums; j++)
           {    
              for(k = 0; k<Gr.rows*Gr.colums; k++)
              {
                for(l= 0;l<Gr.rows*Gr.colums; l++)
                {
                  printf("%lf",crosstalk[i][j][k][l]);
                }
                printf("\n");
              }	
           }  
    }  */
    
}
    


void evaluateSNR(unsigned short *mapping, short *mapped_edges, double **powerlossmatrix, bool ****validcomm, double ****crosstalk, double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk/*, struct crosstalkEdge*/)
{  
     
    double snrWC = 9999;
    
    /**SNR = -1.2; 
    *srcTask = 1; 
    *dstTask = 2; 
    *Ploss =  -2.1;
    *Crosstalk = 2.5;    
    return;  
    */
    unsigned short *inv_map = new unsigned short[Gr.rows*Gr.colums];
    
    //crosstalkEdge *Tasklist = new struct crosstalkEdge [Gr.nodes];
    crosstalkEdge *Tasklist = new struct crosstalkEdge [Gr.edges];
    double crosstalkVar, powerloss=0;
    
    for(int i = 0;i<Gr.rows*Gr.colums;i++)
         inv_map[i] = -1;
    
    for(int i = 0;i<(Gr.rows*Gr.colums);i++)
    {//printf("%d \n",mapping[i]);
        if(mapping[i] != (unsigned short) (-1)){
        	inv_map[mapping[i]] = i;
        	//printf("(task, core) (%d-->%d) ",mapping[i], i);
        }       
    }
    //printf("\nNew\n");
    for(int i = 0; i<Gr.edges; i++)
    {
        if (mapped_edges[i] == 1)
        {
		int ref_task_src = edges[i].source;
		int ref_task_dst = edges[i].destination;
		
		/*if( i == 0){
			*srcTask = ref_task_src; 
			*dstTask = ref_task_dst; 
		}*/
		       
		//printf("SNR SRCEdges= %d DSTNEdges= %d\n", edges[i].source,edges[i].destination);
                
		//initialization of noise list
		for(int j=0; j<Gr.edges; j++){
		//for(int j=0; j<Gr.nodes; j++){
			Tasklist[j].src_noise_task = -1;
			Tasklist[j].dst_noise_task = -1;
			Tasklist[j].crosstalk = -1;
		}
		int task_noise_count = -1;
		int src_tile, dst_tile;
		if (inv_map[ref_task_src] != (unsigned short) (-1) && inv_map[ref_task_dst] != (unsigned short) (-1) ){
			src_tile = inv_map[ref_task_src];
			dst_tile = inv_map[ref_task_dst];
		}
		else continue;
		
		//printf("\ntask (%d, %d) \n", ref_task_src, ref_task_dst);
		//printf("tile (%d, %d) \n", src_tile, dst_tile);
		powerloss = powerlossmatrix[src_tile][dst_tile];
		//printf("powerloss= %f\n",powerloss);       
		//seach for edges creates noise
		for(int j = 0; j<Gr.edges; j++){
			if (i != j && mapped_edges[j] == 1){ //diffrent edges
			//printf("diffedges\n");
				 int noise_task_src = edges[j].source;
				 int noise_task_dst = edges[j].destination;
				 int noise_src_tile, noise_dst_tile;
				 if (inv_map[noise_task_src] != (unsigned short) (-1) && inv_map[noise_task_dst] != (unsigned short) (-1) ){
					 noise_src_tile = inv_map[noise_task_src];
				         noise_dst_tile = inv_map[noise_task_dst];
				         //printf("(%d,%d) (%d,%d) \n", src_tile, dst_tile, noise_src_tile, noise_dst_tile);
				         //printf("valComm = %d\n",validcomm[src_tile][dst_tile][noise_src_tile][noise_dst_tile]);
				 }
				 else continue;
		                 
		                 //if (validcomm[src_tile][dst_tile][noise_src_tile][noise_dst_tile] == 1)
		                 if (validcomm[src_tile][dst_tile][noise_src_tile][noise_dst_tile] == 1 && src_tile != noise_src_tile && dst_tile != noise_dst_tile)
		                 {
					
		                      crosstalkVar = crosstalk[src_tile][dst_tile][noise_src_tile][noise_dst_tile];
				     // printf("ref_task_src=%d ref_task_dst=%d noise_task_src= %d noise_task_dst = %d crosstalkVar = %f \n",ref_task_src,ref_task_dst,noise_task_src,noise_task_dst,crosstalkVar);
		                      if(crosstalkVar == -1)
		                      {
		                                    printf("error in NoC Architecture");
		                      }
		                      if(crosstalkVar != 0)
		                      { 
		                                  task_noise_count++;
		                                  Tasklist[task_noise_count].src_noise_task = noise_task_src;
						  Tasklist[task_noise_count].dst_noise_task = noise_task_dst;
						  Tasklist[task_noise_count].crosstalk = crosstalkVar;
						 // printf("noise_task_src= %d noise_task_dst = %d crosstalkVar = %f \n", noise_task_src,noise_task_dst,crosstalkVar);
						                                           
		                      }
		                }
			}        	
		}//1st end for
		
		//search the crosstalk among the already identified edges
		crosstalkVar = 0;
		//printf("task_count = %d \n",task_noise_count);
		if(task_noise_count > -1)
		{
		     sort_Tasklist(Tasklist, task_noise_count+1 );
		     crosstalkVar = Tasklist[0].crosstalk;
		             
		     for (int task_i=1; task_i < task_noise_count+1; task_i++)
		     {
		           if (Tasklist[task_i].src_noise_task != -1 && Tasklist[task_i].dst_noise_task != -1)
		           {                            
				int src_tile_i = inv_map[Tasklist[task_i].src_noise_task];
				int dst_tile_i = inv_map[Tasklist[task_i].dst_noise_task];

				bool remove = false;
				            
				for(int task_j = 0; task_j<task_i; task_j++ )
				{
				     if (Tasklist[task_j].src_noise_task != -1 && Tasklist[task_j].dst_noise_task != -1)
				     {
					int src_tile_j = inv_map[Tasklist[task_j].src_noise_task];
					int dst_tile_j = inv_map[Tasklist[task_j].dst_noise_task];
						        
					if (validcomm[src_tile_i][dst_tile_i][src_tile_j][dst_tile_j] == 0)
					{
					   remove = true;
					}
					if (remove)
					{
					   //Remove task_i
					   Tasklist[task_i].src_noise_task = -1;
				           Tasklist[task_i].dst_noise_task = -1;
					   Tasklist[task_i].crosstalk = -1;
					   //task_i --;//?? we are not deleting the task but we are assigning the '-1'
					}
					else
					{
					   crosstalkVar = sumDB(crosstalkVar, Tasklist[task_i].crosstalk);
					}
				      }
				}
			     }
		       }
		  }
		  
		  if (crosstalkVar == 0){ //No Change
		  delete inv_map;
	  	  delete Tasklist;
		     return;
		  }
		  double snr = calcSNR(powerloss, crosstalkVar);
		  //printf("Powerloss = %f crosstalkVar = %f SNR=%f\n", powerloss, crosstalkVar, snr);
		  //printf("i=%d no edges = %d snrWC = %f SNR = %f\n", i, Gr.edges, snrWC, snr);
	    	  if (snrWC > snr)
		  {
		       snrWC = snr;
		       *SNR = snr; 
		       
		       *srcTask = ref_task_src; 
		       *dstTask = ref_task_dst; 
		       *Ploss =  powerloss;
		       *Crosstalk = crosstalkVar;
		       //printf("ref_task_src= %d, ref_task_dst= %d\n", ref_task_src, ref_task_dst);
		      
		       
		       /*int k=0;
		       for (int i=0; i<task_noise_count+1; i++){
		       	if (Tasklist[i].src_noise_task != -1 && Tasklist[i].dst_noise_task != -1 && Tasklist[i].crosstalk != -1){
		       	  CTtask[k].src_noise_task = Tasklist[i].src_noise_task;
		       	  CTtask[k].dst_noise_task = Tasklist[i].dst_noise_task;
		       	  CTtask[k].crosstalk = Tasklist[i].crosstalk;
		       	  k++;
		       	}
		       }*/
		       
		  }
		}
	  } //2nd end of for  
	  //printf("parallel comm... %f \n", snrWC);
	  delete inv_map;
	  delete Tasklist;
	   
}



void sort_Tasklist(crosstalkEdge *Tasklist, int n)
{
    int i, j;
    crosstalkEdge temp;
    for(i = 0;i<n-1; i++)
    {                    
        for(j=0;j<n-i-1;j++){
        	if (Tasklist[j].crosstalk < Tasklist[j+1].crosstalk)
            	{
		        temp = Tasklist[j];
		        Tasklist[j] = Tasklist[j+1];
		        Tasklist[j+1] = temp;
            	}
        }        
                            
    }
    
}

double calcSNR(double signal_attenuation, double noise_attenuation)
{
    if (noise_attenuation==0)
    {
        return 9999;
    }
    return (signal_attenuation-noise_attenuation);
}

double sumDB (double a, double b)
{
    return valToDb(dbToVal(a) + dbToVal(b));
}

double dbToVal(double db)
{
    return pow(10, (db*0.1));
}

double valToDb(double val)
{
    return 10*log10(val);
}






/* ============================================================
   NoiseAdjList: precomputed noise adjacency per tile pair
   ============================================================ */

void buildNoiseAdjList(NoiseAdjList *nal, bool ****validcomm, double ****crosstalk, int N)
{
    int total_pairs = N * N;
    nal->N = N;
    nal->num_tile_pairs = total_pairs;
    nal->adj = (NoisePair**)malloc(total_pairs * sizeof(NoisePair*));
    nal->adj_count = (int*)calloc(total_pairs, sizeof(int));

    int *caps = (int*)calloc(total_pairs, sizeof(int));
    for (int i = 0; i < total_pairs; i++) {
        caps[i] = 8;
        nal->adj[i] = (NoisePair*)malloc(caps[i] * sizeof(NoisePair));
        nal->adj_count[i] = 0;
    }

    for (int si = 0; si < N; si++) {
        for (int di = 0; di < N; di++) {
            if (si == di) continue;
            int pair_id = si * N + di;
            for (int sj = 0; sj < N; sj++) {
                for (int dj = 0; dj < N; dj++) {
                    if (si == sj && di == dj) continue;
                    if (sj == dj) continue;
                    if (si == sj || di == dj) continue;
                    if (validcomm[si][di][sj][dj] == 1) {
                        double xt = crosstalk[si][di][sj][dj];
                        if (xt != 0 && xt != -1) {
                            int c = nal->adj_count[pair_id];
                            if (c >= caps[pair_id]) {
                                caps[pair_id] *= 2;
                                nal->adj[pair_id] = (NoisePair*)realloc(
                                    nal->adj[pair_id], caps[pair_id] * sizeof(NoisePair));
                            }
                            nal->adj[pair_id][c].src_tile = sj;
                            nal->adj[pair_id][c].dst_tile = dj;
                            nal->adj[pair_id][c].xt = xt;
                            nal->adj_count[pair_id] = c + 1;
                        }
                    }
                }
            }
        }
    }
    free(caps);
}

void freeNoiseAdjList(NoiseAdjList *nal)
{
    if (!nal) return;
    for (int i = 0; i < nal->num_tile_pairs; i++)
        free(nal->adj[i]);
    free(nal->adj);
    free(nal->adj_count);
    nal->adj = NULL;
    nal->adj_count = NULL;
}

/* ============================================================
   SNRCache: incremental per-edge SNR state
   ============================================================ */

void initSNRCache(SNRCache *cache, int max_edges, int inv_map_sz)
{
    cache->capacity = max_edges;
    cache->num_edges = 0;
    cache->edge_states = (EdgeSNRState*)calloc(max_edges, sizeof(EdgeSNRState));
    for (int i = 0; i < max_edges; i++) {
        cache->edge_states[i].active_noise_cap = 16;
        cache->edge_states[i].active_noise = (NoisePair*)malloc(16 * sizeof(NoisePair));
        cache->edge_states[i].noise_count = 0;
        cache->edge_states[i].edge_idx = -1;
    }
    cache->worst_case_snr = 9999;
    cache->wc_src_task = -1;
    cache->wc_dst_task = -1;
    cache->wc_ploss = 0;
    cache->wc_crosstalk = 0;
    cache->inv_map_size = inv_map_sz;
    cache->inv_map = (unsigned short*)malloc(inv_map_sz * sizeof(unsigned short));
    for (int i = 0; i < inv_map_sz; i++)
        cache->inv_map[i] = (unsigned short)(-1);
}

void freeSNRCache(SNRCache *cache)
{
    if (!cache) return;
    for (int i = 0; i < cache->capacity; i++)
        free(cache->edge_states[i].active_noise);
    free(cache->edge_states);
    free(cache->inv_map);
}

void resetSNRCache(SNRCache *cache)
{
    for (int i = 0; i < cache->num_edges; i++) {
        cache->edge_states[i].noise_count = 0;
        cache->edge_states[i].edge_idx = -1;
    }
    cache->num_edges = 0;
    cache->worst_case_snr = 9999;
    cache->wc_src_task = -1;
    cache->wc_dst_task = -1;
    for (int i = 0; i < cache->inv_map_size; i++)
        cache->inv_map[i] = (unsigned short)(-1);
}

void snrCacheRebuildInvMap(SNRCache *cache, unsigned short *mapping, int map_size)
{
    for (int i = 0; i < cache->inv_map_size; i++)
        cache->inv_map[i] = (unsigned short)(-1);
    for (int i = 0; i < map_size; i++) {
        if (mapping[i] != (unsigned short)(-1))
            cache->inv_map[mapping[i]] = i;
    }
}

static void edgeStateAddNoise(EdgeSNRState *es, int src_t, int dst_t, double xt)
{
    if (es->noise_count >= es->active_noise_cap) {
        es->active_noise_cap *= 2;
        es->active_noise = (NoisePair*)realloc(
            es->active_noise, es->active_noise_cap * sizeof(NoisePair));
    }
    es->active_noise[es->noise_count].src_tile = src_t;
    es->active_noise[es->noise_count].dst_tile = dst_t;
    es->active_noise[es->noise_count].xt = xt;
    es->noise_count++;
}

static double computeEdgeSNRFromNoise(EdgeSNRState *es, bool ****validcomm)
{
    if (es->noise_count == 0) return 9999;

    int n = es->noise_count;
    NoisePair *sorted = (NoisePair*)malloc(n * sizeof(NoisePair));
    for (int i = 0; i < n; i++) sorted[i] = es->active_noise[i];

    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (sorted[j].xt < sorted[j+1].xt) {
                NoisePair tmp = sorted[j];
                sorted[j] = sorted[j+1];
                sorted[j+1] = tmp;
            }

    double totalXT = sorted[0].xt;
    int *valid_flags = (int*)calloc(n, sizeof(int));
    valid_flags[0] = 1;

    for (int i = 1; i < n; i++) {
        int remove = 0;
        for (int j = 0; j < i && !remove; j++) {
            if (valid_flags[j]) {
                if (validcomm[sorted[i].src_tile][sorted[i].dst_tile]
                             [sorted[j].src_tile][sorted[j].dst_tile] == 0) {
                    remove = 1;
                }
            }
        }
        if (!remove) {
            totalXT = sumDB(totalXT, sorted[i].xt);
            valid_flags[i] = 1;
        }
    }

    free(sorted);
    free(valid_flags);

    es->total_crosstalk_dB = totalXT;
    es->snr = calcSNR(es->powerloss, totalXT);
    return es->snr;
}

void snrCacheAddEdge(SNRCache *cache, int edge_idx, int src_tile, int dst_tile,
                     double **powerlossmatrix, NoiseAdjList *nal,
                     unsigned short *mapping, short *mapped_edges)
{
    if (cache->num_edges >= cache->capacity) return;

    EdgeSNRState *es = &cache->edge_states[cache->num_edges];
    es->edge_idx = edge_idx;
    es->src_tile = src_tile;
    es->dst_tile = dst_tile;
    es->powerloss = powerlossmatrix[src_tile][dst_tile];
    es->noise_count = 0;

    int pair_id = src_tile * nal->N + dst_tile;
    int nadj = nal->adj_count[pair_id];
    NoisePair *adj = nal->adj[pair_id];

    for (int a = 0; a < nadj; a++) {
        int nsrc = adj[a].src_tile;
        int ndst = adj[a].dst_tile;

        int noise_mapped = 0;
        for (int e = 0; e < Gr.edges; e++) {
            if (mapped_edges[e] == 1 && e != edge_idx) {
                int ts = edges[e].source;
                int td = edges[e].destination;
                if (cache->inv_map[ts] != (unsigned short)(-1) &&
                    cache->inv_map[td] != (unsigned short)(-1)) {
                    int st = cache->inv_map[ts];
                    int dt = cache->inv_map[td];
                    if (st == nsrc && dt == ndst) {
                        noise_mapped = 1;
                        break;
                    }
                }
            }
        }
        if (noise_mapped)
            edgeStateAddNoise(es, nsrc, ndst, adj[a].xt);
    }

    cache->num_edges++;
}

void snrCacheRecomputeWorstCase(SNRCache *cache)
{
    cache->worst_case_snr = 9999;
    cache->wc_src_task = -1;
    cache->wc_dst_task = -1;

    for (int i = 0; i < cache->num_edges; i++) {
        EdgeSNRState *es = &cache->edge_states[i];
        if (es->edge_idx < 0) continue;
        double snr = es->snr;
        if (snr < cache->worst_case_snr) {
            cache->worst_case_snr = snr;
            cache->wc_src_task = edges[es->edge_idx].source;
            cache->wc_dst_task = edges[es->edge_idx].destination;
            cache->wc_ploss = es->powerloss;
            cache->wc_crosstalk = es->total_crosstalk_dB;
        }
    }
}

void snrCacheFullRebuild(SNRCache *cache, unsigned short *mapping, short *mapped_edges,
                         double **powerlossmatrix, NoiseAdjList *nal, bool ****validcomm)
{
    resetSNRCache(cache);
    snrCacheRebuildInvMap(cache, mapping, Gr.rows * Gr.colums);

    for (int i = 0; i < Gr.edges; i++) {
        if (mapped_edges[i] == 1) {
            int ts = edges[i].source;
            int td = edges[i].destination;
            if (cache->inv_map[ts] != (unsigned short)(-1) &&
                cache->inv_map[td] != (unsigned short)(-1)) {
                int src_tile = cache->inv_map[ts];
                int dst_tile = cache->inv_map[td];
                snrCacheAddEdge(cache, i, src_tile, dst_tile,
                               powerlossmatrix, nal, mapping, mapped_edges);
            }
        }
    }

    for (int i = 0; i < cache->num_edges; i++) {
        EdgeSNRState *es = &cache->edge_states[i];
        if (es->edge_idx >= 0)
            computeEdgeSNRFromNoise(es, validcomm);
    }
}

void evaluateSNR_cached(SNRCache *cache, unsigned short *mapping, short *mapped_edges,
                        double **powerlossmatrix, NoiseAdjList *nal, bool ****validcomm,
                        double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk)
{
    resetSNRCache(cache);
    snrCacheRebuildInvMap(cache, mapping, Gr.rows * Gr.colums);

    double snrWC = 9999;

    for (int i = 0; i < Gr.edges; i++) {
        if (mapped_edges[i] != 1) continue;

        int ref_src = edges[i].source;
        int ref_dst = edges[i].destination;
        if (cache->inv_map[ref_src] == (unsigned short)(-1) ||
            cache->inv_map[ref_dst] == (unsigned short)(-1))
            continue;

        int src_tile = cache->inv_map[ref_src];
        int dst_tile = cache->inv_map[ref_dst];
        double pl = powerlossmatrix[src_tile][dst_tile];

        int pair_id = src_tile * nal->N + dst_tile;
        int nadj = nal->adj_count[pair_id];
        NoisePair *adj = nal->adj[pair_id];

        int noise_count = 0;
        NoisePair *noise_list = (NoisePair*)malloc((nadj > 0 ? nadj : 1) * sizeof(NoisePair));

        for (int a = 0; a < nadj; a++) {
            int nsrc = adj[a].src_tile;
            int ndst = adj[a].dst_tile;

            for (int e = 0; e < Gr.edges; e++) {
                if (e == i || mapped_edges[e] != 1) continue;
                int ts = edges[e].source;
                int td = edges[e].destination;
                if (cache->inv_map[ts] == (unsigned short)(-1) ||
                    cache->inv_map[td] == (unsigned short)(-1)) continue;
                if ((int)cache->inv_map[ts] == nsrc && (int)cache->inv_map[td] == ndst) {
                    noise_list[noise_count].src_tile = nsrc;
                    noise_list[noise_count].dst_tile = ndst;
                    noise_list[noise_count].xt = adj[a].xt;
                    noise_count++;
                    break;
                }
            }
        }

        double xtVar = 0;
        if (noise_count > 0) {
            for (int x = 0; x < noise_count - 1; x++)
                for (int y = 0; y < noise_count - x - 1; y++)
                    if (noise_list[y].xt < noise_list[y+1].xt) {
                        NoisePair tmp = noise_list[y];
                        noise_list[y] = noise_list[y+1];
                        noise_list[y+1] = tmp;
                    }

            xtVar = noise_list[0].xt;
            for (int ti = 1; ti < noise_count; ti++) {
                int rm = 0;
                for (int tj = 0; tj < ti && !rm; tj++) {
                    if (validcomm[noise_list[ti].src_tile][noise_list[ti].dst_tile]
                                 [noise_list[tj].src_tile][noise_list[tj].dst_tile] == 0)
                        rm = 1;
                }
                if (!rm)
                    xtVar = sumDB(xtVar, noise_list[ti].xt);
            }
        }

        free(noise_list);

        if (xtVar == 0) continue;
        double snr = calcSNR(pl, xtVar);
        if (snr < snrWC) {
            snrWC = snr;
            *SNR = snr;
            *srcTask = ref_src;
            *dstTask = ref_dst;
            *Ploss = pl;
            *Crosstalk = xtVar;
        }
    }
}

/* ============================================================
   SNRMemoCache: Zobrist-hashed memoization
   ============================================================ */

void initSNRMemoCache(SNRMemoCache *mc, int max_tasks, int max_tiles)
{
    mc->max_tasks = max_tasks;
    mc->max_tiles = max_tiles;
    mc->table = (MemoEntry*)calloc(MEMO_CAPACITY, sizeof(MemoEntry));

    mc->zobrist_task_tile = (uint64_t**)malloc(max_tasks * sizeof(uint64_t*));
    unsigned int seed = (unsigned int)time(NULL);
    for (int t = 0; t < max_tasks; t++) {
        mc->zobrist_task_tile[t] = (uint64_t*)malloc(max_tiles * sizeof(uint64_t));
        for (int p = 0; p < max_tiles; p++) {
            seed = seed * 1103515245 + 12345;
            uint64_t hi = (uint64_t)seed;
            seed = seed * 1103515245 + 12345;
            uint64_t lo = (uint64_t)seed;
            mc->zobrist_task_tile[t][p] = (hi << 32) | lo;
        }
    }
}

void freeSNRMemoCache(SNRMemoCache *mc)
{
    if (!mc) return;
    free(mc->table);
    for (int t = 0; t < mc->max_tasks; t++)
        free(mc->zobrist_task_tile[t]);
    free(mc->zobrist_task_tile);
}

uint64_t memoComputeHash(SNRMemoCache *mc, unsigned short *mapping, short *mapped_edges,
                         int map_size, int num_edges)
{
    uint64_t h = 0;
    for (int i = 0; i < map_size; i++) {
        if (mapping[i] != (unsigned short)(-1)) {
            int task = mapping[i];
            int tile = i;
            if (task < mc->max_tasks && tile < mc->max_tiles)
                h ^= mc->zobrist_task_tile[task][tile];
        }
    }
    for (int e = 0; e < num_edges; e++) {
        if (mapped_edges[e] == 1)
            h ^= ((uint64_t)e * 0x9E3779B97F4A7C15ULL);
    }
    return h;
}

int memoLookup(SNRMemoCache *mc, uint64_t hash, double *snr, int *srcTask, int *dstTask,
               double *ploss, double *xt)
{
    int idx = (int)(hash % (uint64_t)MEMO_CAPACITY);
    MemoEntry *e = &mc->table[idx];
    if (e->valid && e->hash == hash) {
        *snr = e->snr;
        *srcTask = e->srcTask;
        *dstTask = e->dstTask;
        *ploss = e->ploss;
        *xt = e->crosstalk_val;
        return 1;
    }
    return 0;
}

void memoStore(SNRMemoCache *mc, uint64_t hash, double snr, int srcTask, int dstTask,
               double ploss, double xt)
{
    int idx = (int)(hash % (uint64_t)MEMO_CAPACITY);
    MemoEntry *e = &mc->table[idx];
    e->hash = hash;
    e->snr = snr;
    e->srcTask = srcTask;
    e->dstTask = dstTask;
    e->ploss = ploss;
    e->crosstalk_val = xt;
    e->valid = 1;
}

/*double evaluateSNRforEdge(unsigned short *mapping, unsigned short mapedCore, unsigned short unMapedCore, double **powerlossmatrix, bool ****validcomm, double ****crosstalk, double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk, struct crosstalkEdge *CTtask)
{  
     
    double snrWC = 9999;
    unsigned short *inv_map = new unsigned short[Gr.nodes];
    
    crosstalkEdge *Tasklist = new struct crosstalkEdge [Gr.nodes];
    
    for(int i = 0;i<Gr.rows*Gr.colums;i++)
    {
        if (mapping[i] == -1)
          inv_map[mapping[i]] = -1;
        else
          inv_map[mapping[i]] = i;
    } 
        
        //initialization of noise list
        for(int j=0; j<Gr.nodes; j++){
        	Tasklist[j].src_noise_task = -1;
        	Tasklist[j].dst_noise_task = -1;
        	Tasklist[j].crosstalk = -1;
        }
        int task_noise_count = -1;
        
        int src_tile = mapedCore;
        int dst_tile = unMapedCore;
        double powerloss = powerlossmatrix[src_tile][dst_tile];       
        //seach for edges creates noise
       
        for(int j = 0; j<Gr.rows*Gr.cols; j++)
        {
          if(mapping[j] != -1 && j != mapedCore)
          {
		int noise_src_core = j;
    		int noise_src_task = inv_map[j];
    		//get neighbours tasks of noise_src_task
    		short int *neighTasks = new short int[Gr.nodes]; 
    		for(int i=0; i < Gr.nodes; i++){
    			neighTasks[i] = 0;
    		}
                for(int i = noise_src_task; i < Gr.nodes; i++){
                	neighTasks[i] = G[i][noise_src_task];
                }
                for(int i=0; i<Gr.nodes; i++)
                {
                	if (neighTasks[i] != 0 && inv_map[ neighTasks[i] ] != -1){
                		int noise_dst_core = inv_map[ neighTasks[i] ];
                		 if (validcomm[src_tile][dst_tile][noise_src_core][noise_dst_core] == 1)
		                 {
		                      double crosstalkVar = crosstalk[src_tile][dst_tile][noise_src_tile][noise_dst_tile];

		                      if(crosstalkVar == -1)
		                      {
		                                    printf("error in NoC Architecture");
		                      }
		                      if(crosstalkVar != 0)
		                      { 
		                                  task_noise_count++;
		                                  Tasklist[task_noise_count].src_noise_task = noise_task_src;
						  Tasklist[task_noise_count].dst_noise_task = noise_task_dst;
						  Tasklist[task_noise_count].crosstalk = crosstalkVar;
		                      }
		                  }
                	}
                
                }
        //search the crosstalk among the already identified edges
        double crosstalkVar = 0;
        if(task_noise_count > -1)
        {
             sort_Tasklist(Tasklist, task_noise_count+1 );
             crosstalkVar = Tasklist[0].crosstalk;
                     
             for (int task_i=1; task_i < task_noise_count+1; task_i++)
             {
                   if (Tasklist[task_i].src_noise_task != -1 && Tasklist[task_i].dst_noise_task != -1)
                   {                            
		        int src_tile_i = inv_map[Tasklist[task_i].src_noise_task];
		        int dst_tile_i = inv_map[Tasklist[task_i].dst_noise_task];

		        bool remove = false;
		                    
		        for(int task_j = 0; task_j<task_i; task_j++ )
		        {
		             if (Tasklist[task_j].src_noise_task != -1 && Tasklist[task_j].dst_noise_task != -1)
		             {
			        int src_tile_j = inv_map[Tasklist[task_j].src_noise_task];
			        int dst_tile_j = inv_map[Tasklist[task_j].dst_noise_task];
				                
			        if (validcomm[src_tile_i][dst_tile_i][src_tile_j][dst_tile_j] == 0)
			        {
			           remove = true;
			        }
			        if (remove)
			        {
			           //Remove task_i
			           Tasklist[task_i].src_noise_task = -1;
        		           Tasklist[task_i].dst_noise_task = -1;
        			   Tasklist[task_i].crosstalk = -1;
				   //task_i --;//?? we are not deleting the task but we are assigning the '-1'
			        }
			        else
			        {
			           crosstalkVar = sumDB(crosstalkVar, Tasklist[task_i].crosstalk);
			        }
		              }
		        }
		     }
               }
          }
          double snr = calcSNR(powerloss, crosstalkVar);
    	  if (snrWC > snr)
	  {
	       snrWC = snr;
	       *SNR = snr; 
	       *srcTask = ref_task_src; 
	       *dstTask = ref_task_dst; 
	       *Ploss =  powerloss;
	       *Crosstalk = crosstalkVar;
	       int k=0;
	       for (int i=0; i<task_noise_count+1; i++){
	       	if (Tasklist[i].src_noise_task != -1 && Tasklist[i].dst_noise_task != -1 && Tasklist[i].crosstalk != -1){
	       	  CTtask[k].src_noise_task = Tasklist[i].src_noise_task;
	       	  CTtask[k].dst_noise_task = Tasklist[i].dst_noise_task;
	       	  CTtask[k].crosstalk = Tasklist[i].crosstalk;
	       	  k++;
	       	}
	       }
	       
	  }       
        
  return snr;
}
*/


