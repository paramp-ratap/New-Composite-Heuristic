#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <string.h>
#include <math.h>
#include "graph.h"
#include "predictive.h"
#include "optical.h"

using namespace std;
extern	struct graph_info Gr;
extern struct edge_info *edges;

//extern struct virtual_address address;
struct virtual_address address;
//unsigned short cores;

void read_graph(float**G,char* data)
{
    unsigned short nodes,row=0,colum=0;
    char*buff,*arg;
    char*file_name;
    fstream fp;
    buff=new char [500];
    arg=new char [5];
    file_name=new char [100];
    //data=atoi(argument);
    Gr.edges=0;
    //arg=itoa(int(data),arg,10);
    strcpy(file_name,"App/Graph");
    strcat(file_name,data);
    strcat(file_name,".txt");
    fp.open(file_name,ios::in);
    //Gr.edges=0;
    /*if(data==1)
        fp.open("Graph6.txt",ios::in);
    else if(data==2)
        fp.open("Graph2.txt",ios::in);
    else if(data==3)
        fp.open("Graph3.txt",ios::in);
    else if(data==4)
        fp.open("Graph17.txt",ios::in);*/
        //cout<<"its open"<<endl;
        fp>>nodes;
        
        //cout<<nodes<<endl;
        fp>>buff;
        while(row<Gr.nodes)
        {
            if(strcmp(buff,"INF")==0)
            {
                G[row][colum]=0;
                colum++;
               // cout<<"here";
            }
            else
            {
                G[row][colum]=atof(buff);
                if(row!=colum)
                    Gr.edges++;
                colum++;
            }
            if(colum>=nodes)
            {
                colum=0;
                row++;
            }
            fp>>buff;
        }
   /*for(int index=0;index<Gr.nodes;index++){
        for(int index2=0;index2<Gr.nodes;index2++)
            cout<<G[index][index2]<<",";
        cout<<"\n";
   }*/
    fp.close();
    Gr.edges=Gr.edges/2;
}

void short_edges(void)
{
    unsigned short edge_index,edge_index2;
    struct edge_info temp;
    for(edge_index=0;edge_index<Gr.edges;edge_index++)
    {
        for(edge_index2=edge_index;edge_index2<Gr.edges;edge_index2++)
        {
            if(edges[edge_index2].edge_weight>edges[edge_index].edge_weight)
            {
                temp.source=edges[edge_index2].source;
                temp.destination=edges[edge_index2].destination;
                temp.edge_weight=edges[edge_index2].edge_weight;
                edges[edge_index2].source=edges[edge_index].source;
                edges[edge_index2].destination=edges[edge_index].destination;
                edges[edge_index2].edge_weight=edges[edge_index].edge_weight;
                edges[edge_index].source=temp.source;
                edges[edge_index].destination=temp.destination;
                edges[edge_index].edge_weight=temp.edge_weight;
            }
        }
    }
}
void display_edges(void)
{
    unsigned short edge_index2;
    for(edge_index2=0;edge_index2<Gr.edges;edge_index2++)
    {
        cout<<edges[edge_index2].source<<" ---> "<<edges[edge_index2].destination<<" = "<<edges[edge_index2].edge_weight<<endl;
    }
}
void intialize_array(unsigned short* array)
{
    unsigned short index;
    for(index=0;index<Gr.nodes;index++)
    {
        array[index]=0;//-1;
    }
}

float get_communicatio_of_node(unsigned short node,float**G)
{
    unsigned short node_index;
    float comm=0;
    for(node_index=0;node_index<Gr.nodes;node_index++)
    {
        comm=comm+G[node][node_index];
    }
    return comm;
}
unsigned short get_maximum_outgoing_edge_maped_node(unsigned short* core_mapping_flag,struct edge_info edge)
{
    if(core_mapping_flag[edge.source] & core_mapping_flag[edge.destination])
        return 0;
    else if(core_mapping_flag[edge.source])
        return 1;
    else if(core_mapping_flag[edge.destination])
        return 2;
    else
        //return 0;
        return 3; // for SNR


}
unsigned short int hop_count(unsigned short node1,unsigned short node2)
{
    unsigned short no_hops;
    no_hops=abs(address.colum[node1]-address.colum[node2])+abs(address.row[node1]-address.row[node2]);
    return no_hops;
}
void intialize_mapping_var(unsigned short* map)
{
    unsigned short index;
    for(index=0;index<Gr.nodes;index++)
        map[index]=-1;//9999;
}
unsigned short find_min_comm_pos(unsigned short *core_mapping_flag,unsigned short node,unsigned short *pos,float**G,unsigned short int*router_mapping_flag,unsigned short *mapping,unsigned short*inv_map)
{
    unsigned short node_indexl,node_index2,count=0,index;
    float *comm_pos,min_comm=99999999, comm=0.0;
    comm_pos=new float [Gr.nodes];
    //intialize_array((unsigned short *)comm_pos);
    for(node_index2=0;node_index2<Gr.nodes;node_index2++)
        comm_pos[node_index2]=99999999;
    for(node_indexl=0;node_indexl<Gr.nodes;node_indexl++)
    {
         comm=0;
        if(router_mapping_flag[node_indexl]==0)
        {
            for(node_index2=0;node_index2<Gr.nodes;node_index2++)
            {
                if(core_mapping_flag[node_index2]==1)
                {
                    //for(index=0;index<Graph.nodes;index++)
                    //{
                     //    if(mapping[index]==node_index2)
                     //       break;
                    //}
					index=inv_map[node_index2];
                    comm=comm+G[node_index2][node]*hop_count(node_indexl,index);
                }
            }
           comm_pos[node_indexl]=comm;
           if(comm<min_comm)
           {
               min_comm=comm;
              // pos[0]=node_indexl;
               //cout<<"min_comm_pos = "<<min_comm<<endl;
           }

        }
    }
     //if(node==2)
        //cout<<"min comm ="<<min_comm<<endl;
    count=0;
    
    for(node_indexl=0;node_indexl<Gr.nodes;node_indexl++)
    {
        if(comm_pos[node_indexl]==min_comm)
        {
            pos[count]=node_indexl;
            count++;
           //cout<<"cost for each positions = "<<comm_pos[node_indexl]<<endl;
        }
    }
    //cout<<"pos[0] = "<<pos[0]<<" count= "<<count<<endl;
    return count;
}


unsigned short find_min_powerloss_pos(unsigned short *core_mapping_flag,unsigned short node,unsigned short *pos,float**G,unsigned short int*router_mapping_flag,unsigned short *mapping,unsigned short*inv_map,double **powerloss)
{
    unsigned short node_indexl,node_index2,count=0,index;
    float *powloss_pos,min_loss=-99999999, loss_wc=0.0;
    //variables for ONoC
    //unsigned short minpowerloss=9999,powerloss=0.0;

    //-----
    powloss_pos=new float [Gr.nodes];
    //intialize_array((unsigned short *)powloss_pos);
    for(node_index2=0;node_index2<Gr.nodes;node_index2++)
        powloss_pos[node_index2]=99999999;
    
    for(node_indexl=0;node_indexl<Gr.nodes;node_indexl++)
    {
        loss_wc = -999;
        if(router_mapping_flag[node_indexl]==0)
        {
            for(node_index2=0;node_index2<Gr.nodes;node_index2++)
            {
                if(core_mapping_flag[node_index2]==1)
                {
                    //for(index=0;index<Graph.nodes;index++)
                    //{
                     //    if(mapping[index]==node_index2)
                     //       break;
                    //}
		    index=inv_map[node_index2];                  
                    float loss = powerloss[index][node_indexl]; //node_index1 indictes unmapped core , node_index2 indicates mapped core
                    
                    if (loss > loss_wc){
                        loss_wc = loss;  
                    }
                }
            }
           powloss_pos[node_indexl] = loss_wc;
           
           if(loss_wc > min_loss)
           {
               min_loss = loss_wc;
              // pos[0]=node_indexl;
               //cout<<"min_powloss_pos = "<<min_comm<<endl;
           }

        }
    }
     //if(node==2)
        //cout<<"min comm ="<<min_comm<<endl;
    count=0;
    
    for(node_indexl=0;node_indexl<Gr.nodes;node_indexl++)
    {
        if(powloss_pos[node_indexl]==min_loss)
        {
            pos[count]=node_indexl;
            count++;
           //cout<<"cost for each positions = "<<powloss_pos[node_indexl]<<endl;
        }
    }
    //cout<<"pos[0] = "<<pos[0]<<" count= "<<count<<endl;
    return count;
}

unsigned short find_min_SNR_pos(unsigned short *core_mapping_flag,unsigned short node,unsigned short *pos,float**G,unsigned short int*router_mapping_flag, unsigned short *mapping, unsigned short*inv_map, short *mapped_edges, double **powerloss,  bool ****validcomm, double ****crosstalk)
{
    unsigned short node_indexl,node_index2,node_index3,node_index4,count=0,index;
    double *snr_pos, min_snr = -99999999, snr=0.0, snr_wc=-999999;
   // double *snr;
    double Crosstalk;
    double Ploss;
    int srcTask, dstTask;
    int destn_flag = 0;
    //variables for ONoC
    //unsigned short minpowerloss=9999,powerloss=0.0;

    //-----
    snr_pos=new double [Gr.nodes];
    //intialize_array((unsigned short *)powloss_pos);
    for(node_index2=0;node_index2<Gr.nodes;node_index2++)
       snr_pos[node_index2]=99999999;
       
    unsigned short *temp_mapping = new  unsigned short [Gr.rows*Gr.colums];
    short *temp_mapped_edges = new  short [Gr.edges];
    
    for(node_index2=0;node_index2<(Gr.rows*Gr.colums);node_index2++)
       temp_mapping [ node_index2 ] = mapping[ node_index2 ];
    
    for(node_index2=0;node_index2<(Gr.edges);node_index2++)
       temp_mapped_edges [ node_index2 ] = mapped_edges[ node_index2 ];
       
     for(int e=0; e<Gr.edges; e++){
         if (edges[e].destination == node && inv_map[ edges[e].source] != -1){
            temp_mapped_edges[e] = 1;
            destn_flag = 1;
            break;
          }
     }   
    for(node_indexl=0;node_indexl<Gr.nodes ;node_indexl++)
    {
       snr_wc = 0;
        if(router_mapping_flag[node_indexl]==0)
        {   
            if(destn_flag == 0){ //source node
            	pos[0] = node_indexl; //we can map the task any postition if it is not a destination
            	break;
            }
            
            for(node_index2=0;node_index2<Gr.nodes && destn_flag;node_index2++)
            {
                if(core_mapping_flag[node_index2]==1)
                {
                    //for(index=0;index<Graph.nodes;index++)
                    //{
                     //    if(mapping[index]==node_index2)
                     //       break;
                    //}
					index=inv_map[node_index2];
                  
                    //snr = evaluateSNRforEdge(mapping,powerlossmatrix,validcomm,crosstalk,snr,node_indexl,node_index2,Ploss,Crosstalk,CTtask); //node_index1 indictes unmapped core , node_index2 indicates mapped core
                    //modify the mapping temporarily also mapped_edge...
                    
                    temp_mapping[node_indexl] = node;
                    if (destn_flag == 1){
                       //cout<<"node="<<node<<" before evaluateSNR...\n"<<endl;
                       evaluateSNR(temp_mapping, temp_mapped_edges, powerloss, validcomm, crosstalk, &snr, &srcTask, &dstTask, &Ploss, &Crosstalk/*, struct crosstalkEdge *CTtask*/);
                       //cout<<"after evaluateSNR...\n"<<endl;
                    	 
                    }                   

                                        
                    if (snr > snr_wc && destn_flag){
                        snr_wc = snr;  
                    }
                }
            }
           snr_pos[node_indexl]=snr_wc;
           if(snr_wc>min_snr && destn_flag)
           {
               min_snr=snr_wc;
              // pos[0]=node_indexl;
               //cout<<"min_powloss_pos = "<<min_comm<<endl;
           }

        }
    }
     //if(node==2)
        //cout<<"min comm ="<<min_comm<<endl;
    count=0;
    
    for(node_indexl=0;(node_indexl<Gr.nodes) && destn_flag;node_indexl++)
    {
        if(snr_pos[node_indexl]==min_snr && destn_flag)
        {
            pos[count]=node_indexl;
            count++;
           //cout<<"cost for each positions = "<<powloss_pos[node_indexl]<<endl;
        }
    }
    //cout<<"pos[0] = "<<pos[0]<<" Gr.nodes= "<<Gr.nodes<<" count= "<<count<<endl;
    delete temp_mapping;
    delete temp_mapped_edges;
    
    if(destn_flag==0){     
      return 1;
    }
    else
      return count;
}





void copy_arrays(unsigned short*source,unsigned short *destination)
{
    unsigned short index=0;
    for(index=0;index<Gr.nodes;index++)
    {
        destination[index]=source[index];
    }
}
float cost(unsigned short*map,float**G)
{
    unsigned short index1,index2;
    float cost=0;
    for(index1=0;index1<Gr.nodes;index1++)
    {
        for(index2=index1+1;index2<Gr.nodes;index2++)
        {
            cost=cost+hop_count(index1,index2)*G[map[index1]][map[index2]];
            //cout<<"COST()= "<<hop_count(index1,index2)<<endl;
        }
    }
    //cout<<"COST()= "<<cost<<endl;
    return cost;
}
//for communication-aware
unsigned short predict_best_pos_comm(unsigned short *mapping,unsigned short*pos,float**G,unsigned short pos_count,unsigned short node,unsigned short mapping_count,unsigned short* core_mapping_flag,unsigned short*router_mapping_flag,unsigned short*best_map,float*bestcost,unsigned short* inv_map)
{
    unsigned short count=0,temp_map_count=mapping_count,edge_index,find_node=0,temp_node,index;
    unsigned short* temp_pos,*temp_map,*temp_core_map_flag,*temp_router_map_flag,*temp_inv_map;
    float min_cost=999999,comm_cost;
    unsigned short best_pos;
    temp_pos=new unsigned short[Gr.nodes];
    temp_map=new unsigned short[Gr.nodes];
    temp_core_map_flag=new unsigned short[Gr.nodes];
    temp_router_map_flag=new unsigned short [Gr.nodes];
    temp_inv_map=new unsigned short[Gr.nodes];
    intialize_mapping_var(temp_map);
    intialize_mapping_var(temp_inv_map);
    intialize_array(temp_core_map_flag);
    intialize_array(temp_pos);
    intialize_array(temp_router_map_flag);
   // cout<<"intialize done"<<endl;
    while(count<pos_count)
    {
        mapping_count=temp_map_count;
        copy_arrays(mapping,temp_map);
        copy_arrays(core_mapping_flag,temp_core_map_flag);
        copy_arrays(router_mapping_flag,temp_router_map_flag);
		copy_arrays(inv_map,temp_inv_map);
        //cout<<"mappin count "<<mapping_count<<endl;
        temp_map[pos[count]]=node;
        mapping_count++;
        //cout<<"mappin count "<<mapping_count<<endl;
        temp_router_map_flag[pos[count]]=1;
        temp_core_map_flag[node]=1;
        temp_inv_map[node]=pos[count];
        //cout<<" prediction started"<<endl;
        while(mapping_count<Gr.nodes)
        {
            find_node=0;
            edge_index=0;
            while(find_node!=1)
            {
                if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==1)
                {
                    temp_node=edges[edge_index].destination;
                    //break;
                    find_node=1;
                }
                if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==2)
                {
                    temp_node=edges[edge_index].source;
                    //break;
                    find_node=1;
                }

                edge_index++;
                
                if(edge_index==Gr.edges)
		        {
		        	if(find_node==0)
		        	{
		        		for(index=0;index<Gr.nodes;index++)
		        		{
		        			if(temp_core_map_flag[index]==0)
		        			{
		        				temp_node=index;
		        				find_node=1;
		        				break;
		        			}
		        		}
		        	}
		        }
            }//1st while loop ends here
            
           // cout<<"mapping count "<<mapping_count<<"temp node in prediction = "<<temp_node<<endl;
            intialize_array(temp_pos);
            //cout<<"again intialization done"<<endl;
            //cout<<"Mapping count = "<<mapping_count<<" Graph nodes= " <<Gr.nodes<<endl;
             find_min_comm_pos(temp_core_map_flag,temp_node,temp_pos,G,temp_router_map_flag,temp_map,temp_inv_map);
            
            //cout<<"i know where is proble"<<endl;
            temp_map[temp_pos[0]]=temp_node;
            temp_core_map_flag[temp_node]=1;
            temp_router_map_flag[temp_pos[0]]=1;
            temp_inv_map[temp_node]=temp_pos[0];
            mapping_count++;
        }//2nd while() ends here.
        comm_cost=cost(temp_map,G);
        //cout<<"cost at intermediate stage"<<comm_cost<<endl;
        if(comm_cost<min_cost)
        {
            min_cost=comm_cost;
            best_pos=count;
        }

        if(comm_cost<*bestcost)
        {
            *bestcost=comm_cost;
            copy_arrays(temp_map,best_map);
        }
        count++;
    }//3rd while() ends here
    //cout<<"best position"<<pos[best_pos]<<endl;
    return best_pos;
}
//for power-loss-aware
unsigned short predict_best_pos_PwrLoss(unsigned short *mapping,unsigned short*pos,float**G,unsigned short pos_count,unsigned short node,unsigned short mapping_count,unsigned short* core_mapping_flag,unsigned short*router_mapping_flag,unsigned short*best_map,float*bestcost,unsigned short* inv_map,double **powerloss)
{
    unsigned short count=0,temp_map_count=mapping_count,edge_index,find_node=0,temp_node,index;
    unsigned short* temp_pos,*temp_map,*temp_core_map_flag,*temp_router_map_flag,*temp_inv_map;
    float min_loss=-999999,loss;
    float min_snr = 999999,snr;   
    unsigned short best_pos;
    temp_pos=new unsigned short[Gr.nodes];
    temp_map=new unsigned short[Gr.nodes];
    temp_core_map_flag=new unsigned short[Gr.nodes];
    temp_router_map_flag=new unsigned short [Gr.nodes];
    temp_inv_map=new unsigned short[Gr.nodes];
    intialize_mapping_var(temp_map);
    intialize_mapping_var(temp_inv_map);
    intialize_array(temp_core_map_flag);
    intialize_array(temp_pos);
    intialize_array(temp_router_map_flag);
   // cout<<"intialize done"<<endl;

    while(count<pos_count)
    {
        
        mapping_count=temp_map_count;
        copy_arrays(mapping,temp_map);
        copy_arrays(core_mapping_flag,temp_core_map_flag);
        copy_arrays(router_mapping_flag,temp_router_map_flag);
	copy_arrays(inv_map,temp_inv_map);
        //cout<<"mappin count "<<mapping_count<<endl;
        temp_map[pos[count]]=node;
        mapping_count++;
        //cout<<"mappin count "<<mapping_count<<endl;
        temp_router_map_flag[pos[count]]=1;
        temp_core_map_flag[node]=1;
        temp_inv_map[node]=pos[count];
        //cout<<" prediction started"<<endl;
        while(mapping_count<Gr.nodes)
        {
            find_node=0;
            edge_index=0;
            while(find_node!=1)
            {
                if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==1)
                {
                    temp_node=edges[edge_index].destination;
                    //break;
                    find_node=1;
                }
                if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==2)
                {
                    temp_node=edges[edge_index].source;
                    //break;
                    find_node=1;
                }

                edge_index++;
                if(edge_index==Gr.edges)
		        {
		        	if(find_node==0)
		        	{
		        		for(index=0;index<Gr.nodes;index++)
		        		{
		        			if(temp_core_map_flag[index]==0)
		        			{
		        				temp_node=index;
		        				find_node=1;
		        				break;
		        			}
		        		}
		        	}
		        }
            }//1st while loop ends here
            
           // cout<<"mapping count "<<mapping_count<<"temp node in prediction = "<<temp_node<<endl;
            intialize_array(temp_pos);
            //cout<<"again intialization done"<<endl;
            //cout<<"Mapping count = "<<mapping_count<<" Graph nodes= " <<Gr.nodes<<endl;
             
            
             find_min_powerloss_pos(temp_core_map_flag,temp_node,temp_pos,G,temp_router_map_flag,temp_map,temp_inv_map,powerloss);
             
             
            //cout<<"i know where is proble"<<endl;
            temp_map[temp_pos[0]]=temp_node;
            temp_core_map_flag[temp_node]=1;
            temp_router_map_flag[temp_pos[0]]=1;
            temp_inv_map[temp_node]=temp_pos[0];
            mapping_count++;
        }//2nd while() ends here.
        //comm_cost=cost(temp_map,G);
            
        loss=evaluatePowerLoss(temp_map,powerloss);
        

                //cout<<"cost at intermediate stage"<<comm_cost<<endl;
        if(loss>min_loss)
        {
             min_loss=loss;
             best_pos=count;
        }

        if(loss>*bestcost)
        {
             *bestcost=loss;
             copy_arrays(temp_map,best_map);
        }
                count++;
   }
    return best_pos;

}
//Predict-best position having minimum SNR

unsigned short predict_best_pos_SNR(unsigned short *mapping,unsigned short*pos,float**G,unsigned short pos_count,unsigned short node,unsigned short mapping_count,unsigned short* core_mapping_flag,unsigned short*router_mapping_flag,unsigned short*best_map,float*bestcost,unsigned short* inv_map,double **powerloss, bool ****validcomm, double ****crosstalk)
{
    unsigned short count=0,temp_map_count=mapping_count,edge_index,find_node=0,temp_node,index;
    unsigned short* temp_pos,*temp_map,*temp_core_map_flag,*temp_router_map_flag,*temp_inv_map;
    float min_loss=999999,loss;
    double min_snr = -99999;   
    unsigned short best_pos;
    temp_pos=new unsigned short[Gr.nodes];
    temp_map=new unsigned short[Gr.nodes];
    temp_core_map_flag=new unsigned short[Gr.nodes];
    temp_router_map_flag=new unsigned short [Gr.nodes];
    temp_inv_map=new unsigned short[Gr.nodes];
    short *mapped_edges = new short [Gr.edges]; 
    for(int i=0;i<Gr.edges;i++){
    	mapped_edges[i] = -1;
    }
    for(int i=0;i<(Gr.rows*Gr.colums);i++){
    	temp_map[i] = temp_inv_map [i] = temp_core_map_flag [i] = temp_router_map_flag [i] = -1;
    }
    intialize_mapping_var(temp_map);
    intialize_mapping_var(temp_inv_map);
    intialize_array(temp_core_map_flag);
    intialize_array(temp_pos);
    intialize_array(temp_router_map_flag);
   // cout<<"intialize done"<<endl;

    while(count<pos_count)
    {
        
        mapping_count=temp_map_count;
        copy_arrays(mapping,temp_map);
        copy_arrays(core_mapping_flag,temp_core_map_flag);
        copy_arrays(router_mapping_flag,temp_router_map_flag);
	copy_arrays(inv_map,temp_inv_map);
        //cout<<"mappin count "<<mapping_count<<endl;
        temp_map[pos[count]]=node;
        mapping_count++;
        //cout<<"mappin count "<<mapping_count<<endl;
        temp_router_map_flag[pos[count]]=1;
        temp_core_map_flag[node]=1;
        temp_inv_map[node]=pos[count];
        //cout<<" prediction started"<<endl;
        while(mapping_count<Gr.nodes)
        {
            find_node=0;
            edge_index=0;
            while(find_node!=1)
            {
                if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==1)
                {
                    temp_node=edges[edge_index].destination;
                    //break;
                    find_node=1;
                }
                if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==2)
                {
                    temp_node=edges[edge_index].source;
                    //break;
                    find_node=1;
                }
                else if(get_maximum_outgoing_edge_maped_node(temp_core_map_flag,edges[edge_index])==0) //for SNR calculation
            	{
            		mapped_edges[edge_index] = 1; //checking which egdes are mapped.
            	}

                edge_index++;
                if(edge_index==Gr.edges)
		        {
		        	if(find_node==0)
		        	{
		        		for(index=0;index<Gr.nodes;index++)
		        		{
		        			if(temp_core_map_flag[index]==0)
		        			{
		        				temp_node=index;
		        				find_node=1;
		        				break;
		        			}
		        		}
		        	}
		        }
            }//1st while loop ends here
            
           // cout<<"mapping count "<<mapping_count<<"temp node in prediction = "<<temp_node<<endl;
            intialize_array(temp_pos);
            //cout<<"again intialization done"<<endl;
            //cout<<"Mapping count = "<<mapping_count<<" Graph nodes= " <<Gr.nodes<<endl;
             
            
             //find_min_powerloss_pos(temp_core_map_flag,temp_node,temp_pos,G,temp_router_map_flag,temp_map,temp_inv_map,powerloss);
             
             find_min_SNR_pos(temp_core_map_flag, temp_node, temp_pos, G, temp_router_map_flag, temp_map,temp_inv_map, mapped_edges, powerloss, validcomm, crosstalk);
             //cout<<"temp_pos = "<<temp_pos[0]<<endl;
            //cout<<"i know where is proble"<<endl;
            temp_map[temp_pos[0]]=temp_node;
            temp_core_map_flag[temp_node]=1;
            temp_router_map_flag[temp_pos[0]]=1;
            temp_inv_map[temp_node]=temp_pos[0];
            mapping_count++;
        }//2nd while() ends here.
        //comm_cost=cost(temp_map,G);
            
        //loss=evaluatePowerLoss(temp_map,powerloss);
        
        double snr, Ploss, Crosstalk;
        int srcTask, dstTask;
        evaluateSNR(temp_map, mapped_edges, powerloss, validcomm, crosstalk, &snr, &srcTask, &dstTask, &Ploss, &Crosstalk/*, struct crosstalkEdge *CTtask*/);

                //cout<<"cost at intermediate stage"<<comm_cost<<endl;
        if(snr > min_snr)
        {
             min_snr = snr;
             best_pos = count;
             copy_arrays(temp_map,best_map);
             *bestcost = snr;
        }

        /*if(loss<*bestcost)
        {
             *bestcost=loss;
             copy_arrays(temp_map,best_map);
        }*/
                count++;
   }
   delete mapped_edges; delete temp_inv_map; delete temp_router_map_flag; delete temp_core_map_flag; delete temp_map; delete temp_pos;
    
   return best_pos;

} 
void display_mapping(unsigned short*mapping)
{
    unsigned short row_index,colum_index;
    for(row_index=0;row_index<Gr.rows;row_index++)
    {
        for(colum_index=0;colum_index<Gr.colums;colum_index++)
        {
            cout<<mapping[row_index*Gr.colums+colum_index]<<"\t";
        }
        cout<<endl;
    }
}
void display_min_pos(unsigned short *pos,unsigned short pos_count)
{
    unsigned short index;
    cout<<"positions"<<endl;
    for(index=0;index<pos_count;index++)
       cout <<pos[index]<<"\t";
       cout<<endl;
}

unsigned short * map_graph(int choice, float**G,unsigned short router_id,double **powerloss,  bool ****validcomm, double ****crosstalk)
{
    unsigned short mapping_count=0,edge_index=0,temp_node1,temp_node2,index;
    unsigned short *router_mapping_flag,*core_mapping_flag,find_node=0,pos_count=0;
    unsigned short *mapping,*pos,best_pos=0;
    unsigned short* best_map;
    unsigned short *inv_map;
    unsigned short buff=0;
    float comm_cost=0,*bestcost,bc;
    //variables for ONoC
    unsigned short minpowerloss = 9999;
    //---------------

    router_mapping_flag=new unsigned short [(Gr.rows*Gr.colums)];
    core_mapping_flag=new unsigned short [Gr.nodes];
    short *mapped_edges = new short [Gr.edges];
    pos=new unsigned short [Gr.nodes];
    mapping=new unsigned short [(Gr.rows*Gr.colums)];
    best_map=new unsigned short [(Gr.rows*Gr.colums)];
    inv_map=new unsigned short [(Gr.rows*Gr.colums)];
    switch(choice){
        	case 0: //Communication-aware
        		bc=999999;
    			bestcost=&bc;
        		break;
        		
        	case 1: //Powerloss-aware
        		bc=-999999;
    			bestcost=&bc;
        		break;
        	case 2: //SNR
        		bc=-999999;
    			bestcost=&bc;
        		break;
            }
    
    intialize_array(router_mapping_flag);
    intialize_mapping_var(mapping);
    intialize_array(core_mapping_flag);
    
    temp_node1=edges[0].destination;
    temp_node2=edges[0].source;
    for (int i=0;i<(Gr.rows*Gr.colums);i++){
    	inv_map[i] = mapping[i] = -1;
    }
   /* for (int i=0;i<(Gr.rows*Gr.colums);i++){
    			cout<< mapping[i] <<" ";
    }*/
    for(int i=0;i<Gr.edges;i++){
    	mapped_edges[i] = -1;
    }
    
    //router_id=(floor(Gr.rows/2.0)-1)*Gr.colums+floor(Gr.colums/2.0)-1;
    //cout<<"******* router _id is = "<<router_id<<endl;
    if(get_communicatio_of_node(temp_node1,G)>get_communicatio_of_node(temp_node2,G))
    {
        mapping[router_id]=temp_node1;
        core_mapping_flag[temp_node1]=1;
        inv_map[temp_node1]=router_id;
    }
    else
    {
        mapping[router_id]=temp_node2;
        core_mapping_flag[temp_node2]=1;
        inv_map[temp_node2]=router_id;
    }
    router_mapping_flag[router_id]=1;
    mapping_count++;
    //cout<<"first node mapped"<<endl;
    while(mapping_count<Gr.nodes)
    {
        find_node=0;
        edge_index=0;
        while(find_node!=1)
        {
            if(get_maximum_outgoing_edge_maped_node(core_mapping_flag,edges[edge_index])==1) //source node has been mapped
            {
                temp_node1=edges[edge_index].destination;
                find_node=1;
            }

            else if(get_maximum_outgoing_edge_maped_node(core_mapping_flag,edges[edge_index])==2) //destn node has been mapped
            {
                temp_node1=edges[edge_index].source;
                find_node=1;
            }
            else if(get_maximum_outgoing_edge_maped_node(core_mapping_flag,edges[edge_index])==0) //for SNR calculation
            {
            	mapped_edges[edge_index] = 1; //checking which egdes are mapped.
            	
            }
            edge_index++;
            if(edge_index==Gr.edges)
            {
            	if(find_node==0)
            	{
            		for(index=0;index<Gr.nodes;index++)
            		{
            			if(core_mapping_flag[index]==0)
            			{
            				temp_node1=index;
            				find_node=1;
            				break;
            			}
            		}
            	}
            }
        }
        //cout<<"selected nodes = "<<temp_node1<<endl;
        intialize_array(pos);
        switch(choice){
        	case 0: //Communication-aware
        		pos_count = find_min_comm_pos(core_mapping_flag,temp_node1,pos,G,router_mapping_flag,mapping,inv_map);
        		
        		break;
        		
        	case 1: //Powerloss
        		//cout<<"\nFrom Powerloss find\n";
        		pos_count = find_min_powerloss_pos(core_mapping_flag,temp_node1,pos,G,router_mapping_flag,mapping,inv_map,powerloss);
        		//cout<<"\nFrom Powerloss find...\n";
        		break;
        	case 2: //SNR
        	/*cout<<"\n map=";
        	for (int i=0;i<(Gr.rows*Gr.colums);i++){
    			if (mapping[i] != (unsigned short) (-1))
    			cout<< mapping[i] <<" ";
    		}
        	cout<<"\nFrom SNR find\n";*/
        pos_count = find_min_SNR_pos(core_mapping_flag, temp_node1, pos, G, router_mapping_flag, mapping,inv_map, mapped_edges, powerloss, validcomm, crosstalk);
        	//cout<<"From SNR find... "<<pos_count<<"\n";
        		break;
        }

        buff=0;

        
        if(pos_count>1)
        {
            //copy_arrays(mapping,temp_map);
            //copy_arrays(core_mapping_flag,temp_core_map_flag);
            switch(choice){
        	case 0: //Communication-aware
        		best_pos= predict_best_pos_comm(mapping,pos,G,pos_count,temp_node1,mapping_count,core_mapping_flag,router_mapping_flag,best_map,bestcost,inv_map);
        		
        		break;
        		
        	case 1: //Powerloss-aware
        		best_pos= predict_best_pos_PwrLoss(mapping,pos,G,pos_count,temp_node1,mapping_count,core_mapping_flag,router_mapping_flag,best_map,bestcost,inv_map,powerloss);
        		break;
        	case 2: //SNR
        	//cout<<"before SNR Predict best\n";
        		best_pos = predict_best_pos_SNR(mapping, pos, G, pos_count, temp_node1, mapping_count, core_mapping_flag, router_mapping_flag, best_map, bestcost, inv_map, powerloss, validcomm, crosstalk);
        		//cout<<"after SNR Predict best\n";
        		break;
            }
            
            //cout<<"Predict pos > 1\n";
            mapping[pos[best_pos]]=temp_node1;
            core_mapping_flag[temp_node1]=1;
            router_mapping_flag[pos[best_pos]]=1;
            inv_map[temp_node1]=pos[best_pos];
            mapping_count++;
        }
        else
        { //cout<<"temp_node1 = "<<temp_node1<<endl;
            mapping[pos[0]]=temp_node1;
            core_mapping_flag[temp_node1]=1;
            router_mapping_flag[pos[0]]=1;
            inv_map[temp_node1]=pos[0];
            mapping_count++;
        }
        //Updated: 29 May 2024: Local improvement on the partial mapping set
        //Find WC SNR edge and swap/move such an edge with already (partially) mapped edges
        //Do it when number of partially mapped edge count is more than 2.
        int mappedEDG=0;
        for(int e=0; e<Gr.edges;e++)
        if(mapped_edges[e]==1)
            mappedEDG +=mapped_edges[e];
            
        //if ( mapping_count > (Gr.nodes*0.75)){
        //if ( mapping_count > 2){
        if ( mappedEDG > 2){
                //Improvement on partial mapping solution ....
        	cout<<"Imaprovement at router no = "<<router_id<<endl;
        	mapping = improvement(mapping, mapped_edges, powerloss, crosstalk, validcomm);
        	
        }
    }
    //Improvement after complete mapping solution ....
    //mapping = improvement(mapping, mapped_edges, powerloss, crosstalk, validcomm);
    
    return mapping;
} 
//Iterative improvement on the partially mapped IP cores or edges

///////////////////////////////////////////////////////////////////////

unsigned short* improvement(unsigned short *map, short* mapped_edges, double **powerlossmatrix, double ****crosstalk, bool ****validcomm)
{
	
	
    double map_best_loss = -9999;
    double map_temp_loss;
    double map_best_snr = -9999;
    double map_temp_snr;
    double SNR, Ploss, Crosstalk;
    int srcTaskWc=-1, dstTaskWc=-1;
    int srcTask,dstTask;
	
        
    
    
    double SNR_temp, SNR_best, SNR_map;
    unsigned short* tile_to_move = new unsigned short [Gr.rows*Gr.colums];
    unsigned short* map_tmp  = new unsigned short [Gr.rows*Gr.colums];
    unsigned short* map_return = new unsigned short [Gr.rows*Gr.colums];
    unsigned short* map_best = new unsigned short [Gr.rows*Gr.colums];
    unsigned short* inv_map = new unsigned short [Gr.rows*Gr.colums];
         
    copy_arrays(map, map_return);
    copy_arrays(map, map_best);
    
    //Find the worst-case SNR edge or IP-Cores
   /* for(int i=0;i<Gr.edges;i++)
    cout<<mapped_edges[i]<<"  ";
    
    cout<<endl;
    for(int i=0;i<Gr.edges;i++)
    if (mapped_edges[i] == 1){
    cout<<"SRCEdges= "<<edges[i].source<<"DSTNEdges= "<<edges[i].destination;
    cout<<endl;
    }
    */
    srcTaskWc = dstTaskWc = -1;
    
    evaluateSNR(map, mapped_edges, powerlossmatrix, validcomm, crosstalk, &SNR, &srcTaskWc, &dstTaskWc, &Ploss, &Crosstalk);
    
    //cout <<"srcTaskWc= "<<srcTaskWc<<" dstTaskWc="<<dstTaskWc<<endl;
    
    for(int i=0; i<Gr.rows*Gr.colums; i++){
    	
    	 inv_map [ i ] = -1;
    	
    }
    for(int i=0; i<Gr.rows*Gr.colums; i++){
    	if (map[i] != (unsigned short)(-1)) //as partial mapping
    	 inv_map [ map[i] ] = i;
    	
    }
    
   bool stop = false; 
  // cout<<"Improvement phase\n"; 
   //cout<<"In...\n";
   
   while(!stop )
   {
   	//cout<<"In...a loop stop="<<stop<<endl;
          stop = true;
          
          for(int i=0;i<Gr.rows*Gr.colums;i++)
           {
                if (map[i] != (unsigned short)(-1)) //as partial mapping
                   tile_to_move[i] = 0;
                else
                    tile_to_move[i] = 1;
           }
               
           //cout<<"Improvement phase 22\n";
           //cout <<"srcTaskWc= "<<srcTaskWc<<" dstTaskWc="<<dstTaskWc<<endl;
           
          // cout <<"router= "<<inv_map[srcTaskWc]<<" router="<<inv_map[dstTaskWc]<<endl;
           
           if(srcTaskWc == -1 || dstTaskWc == -1){ //No Change: Crosstalk is 0 and SNR is highest
           	//cout<<" Error in WC-EDGE-SNR\n";
           	//exit(0);
           	//cout <<"srcTaskWc= "<<srcTaskWc<<" dstTaskWc="<<dstTaskWc<<endl;
           	
           	delete tile_to_move;
    		delete map_tmp;
    		delete inv_map;
    		delete map_best;
           	return (map_return);
           }
           
           tile_to_move[inv_map[srcTaskWc]] = 1;
           tile_to_move[inv_map[dstTaskWc]] = 1;
           
           int src_or_dst = 1;
          
              copy_arrays(map, map_tmp);
              // cout<<"Map=\n";
               //         display_mapping(map);
               int temp_task;
               for(int tileid=0; tileid<Gr.rows*Gr.colums; tileid++)
                {   
                    if(tile_to_move[tileid] == 0)
                    {
                       if (src_or_dst == 1){
                       //copy_arrays(map, map_tmp);
                       temp_task = map_tmp[tileid];
                       map_tmp[tileid] = srcTaskWc;
                       //tile_to_move[inv_map[srcTaskWc]] =  temp_task;
                       map_tmp[inv_map[srcTaskWc]] = temp_task;
                       src_or_dst = 2; 
                       continue;
                        }
                       if (src_or_dst == 2){
                       temp_task = map_tmp[tileid];
                       map_tmp[tileid] = dstTaskWc;
                       //tile_to_move[inv_map[dstTaskWc]] =  temp_task;
                       map_tmp[inv_map[dstTaskWc]] = temp_task;
                       src_or_dst = 1;
                        }
                        
                        evaluateSNR(map_tmp, mapped_edges, powerlossmatrix, validcomm, crosstalk, &SNR_temp, &srcTask, &dstTask, &Ploss, &Crosstalk) ;
                        evaluateSNR(map_best, mapped_edges, powerlossmatrix, validcomm, crosstalk, &SNR_best, &srcTask, &dstTask, &Ploss, &Crosstalk);
                      //  printf("SNR_temp = %f  SNR_best = %f %f \n", SNR_temp, SNR_best,  SNR_temp-SNR_best);
                      if(SNR_temp > SNR_best)
                      //if(fabs(SNR_best - SNR_temp)>0.0001)
                     {
                        copy_arrays(map_tmp, map_best);
                        //cout<<"Best=\n";
                        //display_mapping(map_best);
                        copy_arrays(map_best, map_return);
                     }
                     //unsigned short*  map_tmp  = new unsigned short [Gr.rows*Gr.colums];
                     copy_arrays(map, map_tmp);
                    }
                     
                }
                     evaluateSNR(map, mapped_edges, powerlossmatrix, validcomm, crosstalk, &SNR_map, &srcTask, &dstTask, &Ploss, &Crosstalk) ;
                     evaluateSNR(map_best, mapped_edges, powerlossmatrix, validcomm, crosstalk, &SNR_best, &srcTask, &dstTask, &Ploss, &Crosstalk);   
                     
                   //printf("SNR_best = %f  SNR_map = %f %f \n", SNR_best, SNR_map, SNR_best-SNR_map);
                   if(fabs(SNR_best - SNR_map)>0.1)
                    {
                        copy_arrays(map_best, map);
                        copy_arrays(map_best, map_return);
                        evaluateSNR(map_best, mapped_edges, powerlossmatrix, validcomm, crosstalk, &SNR_best, &srcTaskWc, &dstTaskWc, &Ploss, &Crosstalk);   
                        
                        stop = false;
                        //printf("FASE SNR_best = %f  SNR_map = %f \n", SNR_best, SNR_map);
                    }
                    
                    

        }  
        
    delete tile_to_move;
    delete map_tmp;
    delete inv_map;
    delete map_best;
    //cout<<"out\n";
    return map_return;
    
}
///////////////////////////////////////////////////////////////////////    


void display_data(float**G)
{
        unsigned short index,index2;
        for(index=0;index<Gr.nodes;index++)
        {
            for(index2=0;index2<Gr.nodes;index2++)
            {
                cout<<G[index][index2]<<"\t";
            }
            cout<<endl;
        }
}
void print_address(unsigned short*map,char*argument)
{
	unsigned short int *inv_map, node_index,index=0;
	fstream fp;
	unsigned short *rout;
	char *out_file_name;
	out_file_name= new char [50];
	unsigned short cores=32;
	rout=(unsigned short*)malloc(32*sizeof(unsigned short));
	inv_map=(unsigned short*)malloc(sizeof(unsigned short)*Gr.nodes);
	for(node_index=0;node_index<Gr.nodes;node_index++)
	{
		
		rout[node_index]=0;
	}
	for(node_index=0;node_index<32;node_index++)
	{
		
		rout[node_index]=0;
	}
	for(node_index=0;node_index<Gr.nodes;node_index++)
	{
		
		inv_map[map[node_index]]=node_index;
	}
	strcpy(out_file_name,"Addresses");
	strcat(out_file_name,argument);
	strcat(out_file_name,"_Mesh_VC_Predict_PSO.txt");
	fp.open(out_file_name,ios::out);
	fp<<"32"<<endl;
	for(node_index=0;node_index<Gr.nodes;node_index++)
	{
		if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==0)
		{
			fp<<"c"<<node_index+1<<" 00000000 0"<<endl;
			rout[0]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==1)
		{
			fp<<"c"<<node_index+1<<" 10000000 1"<<endl;
			rout[1]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==0)
		{
			fp<<"c"<<node_index+1<<" 00001000 2"<<endl;
			rout[2]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==1)
		{
			fp<<"c"<<node_index+1<<" 10001000 3"<<endl;
			rout[3]=1;
		}
		
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==2)
		{
			fp<<"c"<<node_index+1<<" 01000000 4"<<endl;
			rout[4]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==3)
		{
			fp<<"c"<<node_index+1<<" 11000000 5"<<endl;
			rout[5]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==2)
		{
			fp<<"c"<<node_index+1<<" 01001000 6"<<endl;
			rout[6]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==3)
		{
			fp<<"c"<<node_index+1<<" 11001000 7"<<endl;
			rout[7]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==0)
		{
			fp<<"c"<<node_index+1<<" 00000100 8"<<endl;
			rout[8]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==1)
		{
			fp<<"c"<<node_index+1<<" 10000100 9"<<endl;
			rout[9]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==0)
		{
			fp<<"c"<<node_index+1<<" 00001100 10"<<endl;
			rout[10]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==1)
		{
			fp<<"c"<<node_index+1<<" 10001100 11"<<endl;
			rout[11]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==2)
		{
			fp<<"c"<<node_index+1<<" 01000100 12"<<endl;
			rout[12]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==3)
		{
			fp<<"c"<<node_index+1<<" 11000100 13"<<endl;
			rout[13]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==2)
		{
			fp<<"c"<<node_index+1<<" 01001100 14"<<endl;
			rout[14]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==3)
		{
			fp<<"c"<<node_index+1<<" 11001100 15"<<endl;
			rout[15]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==4)
		{
			fp<<"c"<<node_index+1<<" 00100000 16"<<endl;
			rout[16]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==5)
		{	
			fp<<"c"<<node_index+1<<" 10100000 17"<<endl;
			rout[17]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==4)
		{
			fp<<"c"<<node_index+1<<" 00101000 18"<<endl;
			rout[18]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==5)
		{
			fp<<"c"<<node_index+1<<" 10101000 19"<<endl;
			rout[19]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==6)
		{
			fp<<"c"<<node_index+1<<" 01100000 20"<<endl;
			rout[20]=1;
		}
		else if(address.row[inv_map[node_index]]==0 && address.colum[inv_map[node_index]]==7)
		{
			fp<<"c"<<node_index+1<<" 11100000 21"<<endl;
			rout[21]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==6)
		{
			fp<<"c"<<node_index+1<<" 01101000 22"<<endl;
			rout[23]=1;
		}
		else if(address.row[inv_map[node_index]]==1 && address.colum[inv_map[node_index]]==7)
		{
			fp<<"c"<<node_index+1<<" 11101000 23"<<endl;
			rout[23]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==4)
		{
			fp<<"c"<<node_index+1<<" 00100100 24"<<endl;
			rout[24]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==5)
		{
			fp<<"c"<<node_index+1<<" 10100100 25"<<endl;
			rout[25]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==4)
		{
			fp<<"c"<<node_index+1<<" 00101100 26"<<endl;
			rout[26]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==5)
		{
			fp<<"c"<<node_index+1<<" 10101100 27"<<endl;
			rout[27]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==6)
		{
			fp<<"c"<<node_index+1<<" 01100100 28"<<endl;
			rout[28]=1;
		}
		else if(address.row[inv_map[node_index]]==2 && address.colum[inv_map[node_index]]==7)
		{
			fp<<"c"<<node_index+1<<" 11100100 29"<<endl;
			rout[29]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==6)
		{
			fp<<"c"<<node_index+1<<" 01101100 30"<<endl;
			rout[30]=1;
		}
		else if(address.row[inv_map[node_index]]==3 && address.colum[inv_map[node_index]]==7)
		{
			fp<<"c"<<node_index+1<<" 11101100 31"<<endl;
			rout[31]=1;
		}
	}
	while(node_index<32)
	{
		while(index<32)
		{
			if(rout[index]==0)
			{
			fp<<"c"<<node_index+1<<" xx "<<index<<endl;
			rout[index]=1;
			break;
			}
			index++;
		}
		node_index++;
	}	
	fp.close();
}

void intialize_virtual_add(void)
{
    unsigned short row_index,colum_index;
    //address=(struct virtual_address*)malloc(sizeof(struct virtual_address)*Gr.nodes);
    address.row=(unsigned short int *)malloc(sizeof(unsigned short int)*Gr.nodes);
    address.colum=(unsigned short int *)malloc(sizeof(unsigned short int)*Gr.nodes);
    for(row_index=0;row_index<Gr.rows;row_index++)
    {
        for(colum_index=0;colum_index<Gr.colums;colum_index++)
        {
            //address[row_index*Gr.colums+colum_index].row_add=row_index;
            //address[row_index*Gr.colums+colum_index].colum_add=colum_index;
            /*address[row_index*Gr.colums+colum_index].row=row_index;
            address[row_index*Gr.colums+colum_index].colum=colum_index;*/
            address.row[row_index*Gr.colums+colum_index]=row_index;
            address.colum[row_index*Gr.colums+colum_index]=colum_index;
            // cout<<"Core No= "<<row_index*Gr.colums+colum_index<<"row = "<<address.row[row_index*Gr.colums+colum_index]<<" Col= "<<address.colum[row_index*Gr.colums+colum_index]<<endl;
            //cout<<address[row_index*Gr.colums+colum_index].row_add<<address[row_index*Gr.colums+colum_index].colum_add<<"\t";
        }
        //cout<<endl;
    }
    //cout<<"intialized ok ok";
}

/*
HOW TO COMPILE: g++ predictiveOptical.cpp graph.h graph.c predictive.h optical.h optical.c -lm
HOW TO RUN: ./a.out <GRAPH_NO> <CHOICE_NO>
CHOISE_NO:
0: COMMUNICATION-AWARE
1: POWERLOSS-AWARE
2: CROSSTALK/SNR-AWARE

GRAPH_NO:
FOR APPLICATION Graph1.txt GRAPH_NO is 1
*/

int main(int argc,char*argv[])
{
    float**G;
    unsigned short index1,index2;
    float best_cost=999999,temp_cost,best_cost_powerloss,comcost_best_powerloss;
    unsigned short* mapping,*best_map,*best_map_powerloss;
    double **powerloss;
   
    //intialize_graph_info(argv[1]); //Kanchan
    //cout<<"step 1 done"<<endl;
    
    
    //G=allocate_memory(); // Kanchan
    G = intialize_graph(argv[1], argv[1]);
  
    intialize_virtual_add(); // Kanchan
    cout<<"step 2 done"<<endl;
    best_map=new unsigned short [Gr.nodes];
    best_map_powerloss=new unsigned short [Gr.nodes];
    unsigned short *best_map_crosstalk=new unsigned short [Gr.nodes];
    short *mapped_edges = new short [Gr.edges];
    mapping=new unsigned short [Gr.nodes];
    double bcSNR = -999;
    double rSNR, wcSNR_Ploss, comcost_best_snr;
    
    struct crosstalkEdge *CTtask = new struct crosstalkEdge[Gr.nodes]; 
    powerloss = (double**)malloc(Gr.rows*Gr.colums*sizeof(double*));
    for(int i =0;i<Gr.rows*Gr.colums ;i++)
        {
        powerloss[i] = (double*)malloc(Gr.rows*Gr.colums *sizeof(double));
        }
     read_powerloss(powerloss,atoi(argv[1]));
    double loss=-9999;
    
    
    //read validComm matrix    
    bool ****validcomm = (bool****)malloc(Gr.rows*Gr.colums*sizeof(bool***));
  
   for(int i =0;i<Gr.rows*Gr.colums ;i++)
    {
      validcomm[i] = (bool***)malloc(Gr.rows*Gr.colums*sizeof(bool**));
    
      for(int j = 0;j<Gr.rows*Gr.colums; j++)
        {
          validcomm[i][j] = (bool**)malloc(Gr.rows*Gr.colums*sizeof(bool*));
        
          for(int k = 0;k<Gr.rows*Gr.colums; k++)
            {
              validcomm[i][j][k] = (bool*)malloc(Gr.rows*Gr.colums*sizeof(bool));
            }
        }
     }
     read_validcomm(validcomm, atoi(argv[1]));
//read crosstalk matrix
    double ****crosstalk = (double****)malloc(Gr.rows*Gr.colums*sizeof(double***));
  
   for(int i =0;i<Gr.rows*Gr.colums ;i++)
    {
      crosstalk[i] = (double***)malloc(Gr.rows*Gr.colums*sizeof(double**));
    
      for(int j = 0;j<Gr.rows*Gr.colums; j++)
        {
           crosstalk[i][j] = (double**)malloc(Gr.rows*Gr.colums*sizeof(double*));
        
          for(int k = 0;k<Gr.rows*Gr.colums; k++)
            {
              crosstalk[i][j][k] = (double*)malloc(Gr.rows*Gr.colums*sizeof(double));
            }
        }
    }
    read_crosstalk(crosstalk, atoi(argv[1]));
     
    ofstream outfile_all_mapings;
    char filename [500];
    
    strcpy(filename, "./results/allMapSols_Graph");
    strcat(filename, argv[1]);
    strcat(filename, ".txt");
    outfile_all_mapings.open(filename, ios::out);
    double wcP_loss = 0;
    double SNR, Crosstalk, Ploss;
    int srcTask, dstTask;
    for(index1=0;index1<Gr.rows;index1++)
    {
               

    	//index2=floor(Graph.colums/2);
    	for(index2=0;index2<Gr.colums;index2++)
    	{       //cout<<"hre\n";
    	        //for(int i=0;i<Gr.nodes;i++) mapping[i]=-1;
              cout<<"step 1 done"<<endl;
    		mapping = map_graph(atoi(argv[2]), G,index1*Gr.colums+index2, powerloss, validcomm, crosstalk);
             
    		display_mapping(mapping);
             
    		switch(atoi(argv[2])){
    		     case 0://Communication-aware
    		     	   temp_cost=cost(mapping,G);
    		     	   cout<<"Mapping Cost= "<<temp_cost<<endl;
    		     	   if(temp_cost<best_cost)
    			   {
    				best_cost=temp_cost;
                		best_cost_powerloss=wcP_loss;
    				copy_arrays(mapping,best_map);
    			   }
    		           break;
    		     case 1://Powerloss-aware
    		     	   
    		     	   loss = evaluatePowerLoss(mapping, powerloss);
    		     	   if(wcP_loss > loss)
                    	   {
                        	wcP_loss = loss;
                        	comcost_best_powerloss = temp_cost;
                        	copy_arrays(mapping,best_map);
                    	   }
    		     	   cout<<"Mapping Cost (powerloss)= "<<wcP_loss <<endl;
    		           break;
    		     case 2://SNR-aware
    		     	   for(int i=0;i<Gr.edges;i++){
    				mapped_edges[i] = 1;
    			   }
    			   
    		     	   
    		     	   evaluateSNR(mapping, mapped_edges, powerloss, validcomm, crosstalk, &SNR, &srcTask, &dstTask, &Ploss, &Crosstalk);
    		     	   
    		     	   for(int i=0; i<Gr.rows*Gr.colums; i++){
    		     	   	outfile_all_mapings << mapping[i] <<", ";
    		     	   }
    		     	   outfile_all_mapings <<endl;
    		     	   if(bcSNR < SNR)
                    	   {
                        	bcSNR = SNR;
                        	wcP_loss = Ploss;
                        	copy_arrays(mapping, best_map);
                    	   }
    		     	   cout<<"Mapping Cost (SNR)= "<< SNR <<endl;
    		           break;
    		}
                
    	}
    		//map_graph(G,index1);
    }
    cout<<"\n\n************** Final mapping ****************"<<endl;
    display_mapping(best_map);
    cout<<"Mapping Cost (SNR)= "<< bcSNR<<endl;
    outfile_all_mapings.close();
    ofstream outfile;
    //char filename [100];
    strcpy(filename, "./results/result_Graph");
    strcat(filename, argv[1]);
    switch(atoi(argv[2])){
          case 0:
          	 strcat(filename,"_Comm.txt");
                 break;
           case 1:
          	 strcat(filename,"_PWRLoss.txt");
                 break;
            case 2:
          	 strcat(filename,"_SNR.txt");
                 break;
    }
    outfile.open(filename, ios::out | ios::app);
    
    switch(atoi(argv[2])){
    		     case 0://Communication-aware    		     	   
    		     	   temp_cost=cost(best_map,G);    		     	   
    		     	   //cout<<"Mapping Cost (Comm)= "<<temp_cost<<endl;
    		     	   outfile<<"Mapping Cost (Comm)= "<<temp_cost<<endl;
    		     	   loss = evaluatePowerLoss(best_map, powerloss);    		     	   
    		     	   //cout<<"powerloss= "<<loss <<endl;
    		     	   outfile<<"powerloss= "<<loss <<endl;
    		     	   for(int i=0;i<Gr.edges;i++){
    				mapped_edges[i] = 1;
    			   }
    		     	   evaluateSNR(best_map, mapped_edges, powerloss, validcomm, crosstalk, &SNR, &srcTask, &dstTask, &Ploss, &Crosstalk/*, struct crosstalkEdge*/);
    		     	   
    		     	   //cout<<"SNR= "<< SNR <<endl;
    		     	   outfile<<"SNR= "<< SNR <<endl;
    		           break;
    		     case 1://Powerloss-aware    		     	   
    		     	   loss = evaluatePowerLoss(best_map, powerloss);    		     	   
    		     	   //cout<<"Mapping Cost (powerloss)= "<<loss <<endl;
    		     	   outfile<<"Mapping Cost (powerloss)= "<<loss <<endl;
    		     	   for(int i=0;i<Gr.edges;i++){
    				mapped_edges[i] = 1;
    			   }
    		     	   evaluateSNR(best_map, mapped_edges, powerloss, validcomm, crosstalk, &SNR, &srcTask, &dstTask, &Ploss, &Crosstalk/*, struct crosstalkEdge*/);
    		     	   
    		     	   //cout<<"SNR= "<< SNR <<endl;
    		     	   outfile<<"SNR= "<< SNR <<endl;
    		           break;
    		     case 2://SNR-aware
    		     	   for(int i=0;i<Gr.edges;i++){
    				mapped_edges[i] = 1;
    			   }
    			   
    		     	   
    		     	   evaluateSNR(best_map, mapped_edges, powerloss, validcomm, crosstalk, &SNR, &srcTask, &dstTask, &Ploss, &Crosstalk/*, struct crosstalkEdge*/);
    		     	   
    		     	   //cout<<"Mapping Cost (SNR)= "<< SNR <<endl;
    		     	   outfile<<"Mapping Cost (SNR)= "<< SNR <<endl;
    		     	   //cout<<"Powerloss= "<< Ploss <<endl;
    		     	   outfile<<"Powerloss= "<< Ploss <<endl;
                      
    		           break;
   }
   outfile.close();
   
   return 0;
}



