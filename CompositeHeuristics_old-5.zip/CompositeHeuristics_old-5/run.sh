#run this: sh run.sh

#compilation
g++ predictiveOptical.cpp graph.h graph.c predictive.h optical.h optical.c -lm

#execution




 time ./a.out 40 2
 
