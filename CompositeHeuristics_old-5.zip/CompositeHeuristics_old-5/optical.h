#ifndef optical_h
#define optical_h
struct crosstalkEdge{
        int src_noise_task, dst_noise_task;
        double crosstalk;
};
unsigned short* improvement(unsigned short *map, short* mapped_edges, double **powerlossmatrix, double ****crosstalk, bool ****validcomm);
void read_powerloss(double **powerloss, int graph_number);
double evaluatePowerLoss(unsigned short *mapping, double **powerlossmatrix);

void read_validcomm(bool ****validcomm, int graph_no);
void read_crosstalk(double ****crosstalk, int graph_no);
void evaluateSNR(unsigned short *mapping, short *mapped_edges, double **powerlossmatrix, bool ****validcomm, double ****crosstalk, double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk/*, struct crosstalkEdge*/);
//void evaluateSNR(unsigned short *mapping, double **powerlossmatrix, bool ****validcomm, double ****crosstalk, double *SNR, int *srcTask, int *dstTask, double *Ploss, double *Crosstalk/*, struct crosstalkEdge *CTtask*/);
void sort_Tasklist(crosstalkEdge *Tasklist, int n);
double calcSNR(double signal_attenuation, double noise_attenuation);
double sumDB (double a,double b);
double dbToVal(double db);
double valToDb(double val);
#endif



