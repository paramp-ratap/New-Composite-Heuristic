#include <stdlib.h>
#include <stdio.h>
#include "graph.h"
#include "predictive.h" // Assuming predictive.h has the read_graph declaration

// --- Global Variable Definitions ---
struct graph_info Gr;
struct edge_info *edges = NULL;

// --- Function Implementations ---

void intialize_graph_info(unsigned short int no_nodes, unsigned short int no_rows, unsigned short int no_colums, unsigned short int no_edges)
{
    Gr.nodes = no_nodes;
    Gr.rows = no_rows;
    Gr.colums = no_colums;
    Gr.edges = no_edges;
}

float** allocate_memory(unsigned short int no_nodes)
{
    if (no_nodes == 0) return NULL;
    float** graph = (float **)malloc(no_nodes * sizeof(float*));
    if (!graph) {
        fprintf(stderr, "Error allocating graph rows.\n");
        return NULL;
    }
    for(unsigned short i=0; i<no_nodes; i++) {
        graph[i] = (float*)malloc(no_nodes * sizeof(float));
        if (!graph[i]) {
            fprintf(stderr, "Error allocating graph cols for row %d.\n", i);
            for (unsigned short j = 0; j < no_nodes; ++j) free(graph[j]);
            free(graph);
            return NULL;
        }
        // Initialize memory to zero
        for(unsigned short j=0; j<no_nodes; ++j) graph[i][j] = 0.0f;
    }
    return graph;
}

unsigned short int find_edges(float** graph, unsigned short int no_nodes)
{
    unsigned short int no_edges = 0;
    for(unsigned short i=0; i<no_nodes; i++)
    {
        for(unsigned short j=0; j<no_nodes; j++)
        {
            if (graph[i][j] != 0)
            {
                no_edges++;
            }
        }
     }
    return no_edges;
}

void intialize_edges(float** graph)
{
    if (!graph || !edges) return;
    // CRITICAL BUG FIX: edge_index was uninitialized, causing segfaults.
    unsigned short int edge_index = 0;
    for(unsigned short i=0; i<Gr.nodes; i++) {
        for(unsigned short j=0; j<Gr.nodes; j++) {
            if (graph[i][j] != 0)
            {
                if (edge_index < Gr.edges) { // Safety check
                    edges[edge_index].source = i;
                    edges[edge_index].destination = j;
                    edges[edge_index].edge_weight = graph[i][j];
                    edge_index++;
                } else {
                    fprintf(stderr, "Warning: More edges found than allocated space.\n");
                    return;
                }
            }
        }
    }
}

float** intialize_graph(char* arg, char* name)
{
    float **graph = NULL;
    unsigned short int no_nodes = 0, no_rows = 0, no_colums = 0, no_edges = 0;
    unsigned short devider = 2;
    unsigned short choice = atoi(arg);

    // BUGFIX: This is the COMPLETE list of graph choices from your newer code.
    // This will fix the "Unknown graph choice" error.
    if(choice==3) { no_nodes=8; no_rows=2; no_colums=4; }
    else if(choice==1 || choice==15) { no_nodes=16; no_rows=4; no_colums=4; }
    else if(choice==2 || choice==5 || choice==6 || choice==7 || choice==9 || choice==10 || choice==14) { no_nodes=12; no_rows=4; no_colums=3; }
    else if(choice==8) { no_nodes=16; no_rows=4; no_colums=4; }
    else if(choice==4) { no_nodes=32; no_rows=4; no_colums=8; }
    else if(choice==12) { no_nodes=24; no_rows=4; no_colums=6; }
    else if(choice==13) { no_nodes=30; no_rows=5; no_colums=6; }
    else if(choice==17 || choice==19 || choice==20 || choice==21 || choice==22 || choice==23 || choice==62 || choice==100 || choice==104 || choice==116 || choice==102 || choice==103 || choice==105 || choice==106 || choice==107 || choice==108) { no_nodes=64; no_rows=8; no_colums=8; }
    else if(choice==40 || choice ==41 || choice==42) { no_nodes=72; no_rows=8; no_colums=9; }
    else if(choice==50 || choice ==51 || choice==52) { no_nodes=81; no_rows=9; no_colums=9; }
    else if(choice>=25 && choice<=30) { no_nodes=128; no_rows=8; no_colums=16; }
    else {
        fprintf(stderr, "Error: Unknown graph choice '%s'.\n", arg);
        return NULL; // Exit gracefully if graph is not defined
    }

    graph = allocate_memory(no_nodes);
    if (!graph) return NULL;

    intialize_graph_info(no_nodes, no_rows, no_colums, 0);
    read_graph(graph, arg);

    // // // Make the graph undirected
    // for(unsigned short i=0; i<no_nodes; i++)
    // {
    //    for(unsigned short j=i+1; j<no_nodes; j++)
    //    {
    //       graph[i][j] = (graph[i][j] + graph[j][i]) / devider;
    //       graph[j][i] = graph[i][j];
    //    }
    // }

    no_edges = find_edges(graph, no_nodes);
    intialize_graph_info(no_nodes, no_rows, no_colums, no_edges);
    
    // Free old memory before reallocating
    if (edges) free(edges);
    edges = (struct edge_info*)malloc(no_edges * sizeof(struct edge_info));
    if (!edges) {
        fprintf(stderr, "Error: Failed to allocate memory for edges.\n");
        // Free partially allocated graph
        for(unsigned short i=0; i<no_nodes; ++i) free(graph[i]);
        free(graph);
        return NULL;
    }
    
    intialize_edges(graph);
    
    return graph;
}