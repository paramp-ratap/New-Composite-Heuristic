#run this: sh run.sh

#compilation
g++ -O2 predictiveOptical.cpp graph.c optical.c -lm

#execution
 time ./a.out 40 2
 
