#!/bin/sh
# Sweep the SNR memo cache size and record HIT / MISS / CPU time.
# Output: memo_benchmark.txt  (tab-separated, ready to plot)
#
#   col1: rows                   (memo cache capacity)
#   col2: log10(rows)
#   col3: HIT  count
#   col4: MISS count
#   col5: CPU time (high-resolution, milliseconds) measured inside ./a.out
#
# Each row of the output corresponds to one MEMO_CAP value, so the capacity
# is changed for every row of a given graph run.
#
# Usage:  sh run_memo_benchmark.sh        # uses default args (graph 40, choice 2)
#         sh run_memo_benchmark.sh 40 2   # override graph / choice

set -e

GRAPH_ARG="${1:-40}"
CHOICE_ARG="${2:-2}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

OUT_FILE="memo_benchmark.txt"
TMP_STDOUT="$(mktemp -t memo_stdout.XXXXXX)"
TMP_STDERR="$(mktemp -t memo_stderr.XXXXXX)"
TMP_TIME="$(mktemp -t memo_time.XXXXXX)"
trap 'rm -f "$TMP_STDOUT" "$TMP_STDERR" "$TMP_TIME"' EXIT

# --- Compile once --------------------------------------------------------
# /usr/bin/time -p has only 0.01 s resolution on macOS, which collapses to
# 0 for short runs, so timing is now produced inside a.out via std::chrono
# and emitted on the MEMO_CPU_MS: line.  Zobrist seeding inside a.out is
# also deterministic (controlled by MEMO_SEED) so capacity is the only
# thing varying across rows.
echo "Compiling..."
g++ -O2 predictiveOptical.cpp graph.c optical.c -lm -o a.out

# --- Header --------------------------------------------------------------
printf "rows\tlog10_rows\tHIT\tMISS\tcpu_ms\n" > "$OUT_FILE"

# --- Sizes to sweep ------------------------------------------------------
SIZES="1024 2048 3072 4096 5120 6144 7168 8192 9216 10240 11264 12288 13312 14336 15360 16384 17408"

# Fixed Zobrist seed for the whole sweep so the only thing that changes
# between rows is the cache capacity.
export MEMO_SEED=0xC0FFEE

for N in $SIZES; do
    echo "=== rows=$N ==="
    { time MEMO_CAP="$N" ./a.out "$GRAPH_ARG" "$CHOICE_ARG" \
        >"$TMP_STDOUT" 2>"$TMP_STDERR"; } 2>"$TMP_TIME"

    # Sanity-check the binary picked up the requested capacity.
    REPORTED_CAP=$(grep '^MEMO_ROWS:' "$TMP_STDOUT" | tail -1 | cut -d: -f2)
    if [ "$REPORTED_CAP" != "$N" ]; then
        echo "ERROR: requested MEMO_CAP=$N but a.out reported MEMO_ROWS=$REPORTED_CAP" >&2
        exit 1
    fi

    HIT=$(grep '^MEMO_HITS:'    "$TMP_STDOUT" | tail -1 | cut -d: -f2)
    MISS=$(grep '^MEMO_MISSES:' "$TMP_STDOUT" | tail -1 | cut -d: -f2)
    # Parse user CPU time from shell 'time' output (format: "user  0m0.456s")
    CPU_MS=$(awk '/^user/{split($2,a,"m"); gsub("s","",a[2]); printf "%.3f\n",(a[1]*60+a[2])*1000}' "$TMP_TIME")
    if [ -z "$HIT" ] || [ -z "$MISS" ]; then
        echo "ERROR: a.out did not emit MEMO_HITS/MEMO_MISSES for rows=$N." >&2
        echo "       stderr was:" >&2
        sed 's/^/         /' "$TMP_STDERR" >&2
        exit 1
    fi

    ROW=$(awk -v n="$N" -v h="$HIT" -v m="$MISS" -v t="$CPU_MS" \
        'BEGIN { printf "%d\t%.6f\t%s\t%s\t%.3f\n", n, log(n)/log(10), h, m, t }')

    echo "$ROW" | tee -a "$OUT_FILE"
done

echo
echo "Done. Results written to $OUT_FILE"
